UPDATE db_version SET revision = 52, changeset = 77 WHERE db_name LIKE 'WhyDB';
DELETE FROM creature_spawns where id = 1401746;
DELETE FROM creature_spawns where id = 1381796;
DELETE FROM creature_spawns where entry = 29238;




REPLACE INTO `loot_items` VALUES (6789, 45875, 45624, 100, 0, 5, 5, 0 );
REPLACE INTO `loot_items` VALUES (6790, 45875, 45087, 100, 0, 1, 1, 0 );
UPDATE vendors SET max_amount = -1 WHERE entry = 31864;
UPDATE vendors SET max_amount = -1 WHERE entry = 31863;
UPDATE vendors SET max_amount = -1 WHERE entry = 31865;
UPDATE vendors SET max_amount = -1 WHERE entry = 31582;
UPDATE vendors SET max_amount = -1 WHERE entry = 31581;
UPDATE vendors SET max_amount = -1 WHERE entry = 31031;
UPDATE vendors SET max_amount = -1 WHERE entry = 32419;
UPDATE vendors SET max_amount = -1 WHERE entry = 28997;
UPDATE vendors SET max_amount = -1 WHERE entry = 32515;
UPDATE vendors SET max_amount = -1 WHERE entry = 32514;
UPDATE vendors SET max_amount = -1 WHERE entry = 29478;
UPDATE vendors SET max_amount = -1 WHERE entry = 29716;
UPDATE vendors SET max_amount = -1 WHERE entry = 29491;
UPDATE vendors SET max_amount = -1 WHERE entry = 31580;
UPDATE vendors SET max_amount = -1 WHERE entry = 31579;
UPDATE vendors SET max_amount = -1 WHERE entry = 31032;
UPDATE vendors SET max_amount = -1 WHERE entry = 29523;
UPDATE vendors SET max_amount = -1 WHERE entry = 28992;
UPDATE vendors SET max_amount = -1 WHERE entry = 29535;
UPDATE vendors SET max_amount = -1 WHERE entry = 21643;


UPDATE creature_names SET male_displayid = 21505 WHERE entry = 23434;
UPDATE creature_spawns SET displayid = 21505 WHERE entry = 23434;

UPDATE creature_names SET male_displayid = 24892 WHERE entry = 30014;
UPDATE creature_spawns SET displayid = 24892 WHERE entry = 30014;

UPDATE creature_names SET male_displayid = 19745 WHERE entry = 20520;
UPDATE creature_spawns SET displayid = 19745 WHERE entry = 20520;

UPDATE creature_names SET male_displayid = 25896 WHERE entry = 29074;
UPDATE creature_spawns SET displayid = 25896 WHERE entry = 29074;

UPDATE creature_names SET male_displayid = 25893 WHERE entry = 29071;
UPDATE creature_spawns SET displayid = 25893 WHERE entry = 29071;

UPDATE creature_names SET male_displayid = 25894 WHERE entry = 29072;
UPDATE creature_spawns SET displayid = 25894 WHERE entry = 29072;

UPDATE creature_names SET male_displayid = 25895 WHERE entry = 29073;
UPDATE creature_spawns SET displayid = 25895 WHERE entry = 29073;

UPDATE creature_names SET male_displayid = 11686 WHERE entry = 34363;
UPDATE creature_spawns SET displayid = 11686 WHERE entry = 34363;

UPDATE creature_names SET male_displayid = 6271 WHERE entry = 34362;
UPDATE creature_spawns SET displayid = 6271 WHERE entry = 34362;

UPDATE creature_names SET male_displayid = 6271 WHERE entry = 34362;
UPDATE creature_spawns SET displayid = 6271 WHERE entry = 34362;
UPDATE creature_names SET male_displayid = 6271 WHERE entry = 34362;
UPDATE creature_spawns SET displayid = 6271 WHERE entry = 34362;
UPDATE creature_names SET male_displayid = 6271 WHERE entry = 34362;
UPDATE creature_spawns SET displayid = 6271 WHERE entry = 34362;


-- Credit to maestro
UPDATE creature_names SET male_displayid = 23231, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25659;
UPDATE creature_spawns SET displayid = 23231 WHERE entry = 25659;

UPDATE creature_names SET male_displayid = 24961, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25709;
UPDATE creature_spawns SET displayid = 24961 WHERE entry = 25709;

UPDATE creature_names SET male_displayid = 23329, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25711;
UPDATE creature_spawns SET displayid = 23329 WHERE entry = 25711;

UPDATE creature_names SET male_displayid = 25195, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25717;
UPDATE creature_spawns SET displayid = 25195 WHERE entry = 25717;

UPDATE creature_names SET male_displayid = 24906, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25718;
UPDATE creature_spawns SET displayid = 24906 WHERE entry = 25718;


UPDATE creature_names SET male_displayid = 23332, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25719;
UPDATE creature_spawns SET displayid = 23332 WHERE entry = 25719;

UPDATE creature_names SET male_displayid = 23331, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25720;
UPDATE creature_spawns SET displayid = 23331 WHERE entry = 25720;

UPDATE creature_names SET male_displayid = 23331, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25720;
UPDATE creature_spawns SET displayid = 23331 WHERE entry = 25720;

UPDATE creature_names SET male_displayid = 23181, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25618;
UPDATE creature_spawns SET displayid = 23181 WHERE entry = 25618;

UPDATE creature_names SET male_displayid = 25194, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25203;
UPDATE creature_spawns SET displayid = 25194 WHERE entry = 25203;

UPDATE creature_names SET male_displayid = 22989, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25209;
UPDATE creature_spawns SET displayid = 22989 WHERE entry = 25209;

UPDATE creature_names SET male_displayid = 22995, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25224;
UPDATE creature_spawns SET displayid = 22995 WHERE entry = 25224;


UPDATE creature_names SET male_displayid = 24388, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25233;
UPDATE creature_spawns SET displayid = 24388 WHERE entry = 25233;

UPDATE creature_names SET male_displayid = 23105, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25318;
UPDATE creature_spawns SET displayid = 23105 WHERE entry = 25318;

UPDATE creature_names SET male_displayid = 25979, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25398;
UPDATE creature_spawns SET displayid = 23105 WHERE entry = 25398;

UPDATE creature_names SET male_displayid = 23212, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25461;
UPDATE creature_spawns SET displayid = 23212 WHERE entry = 25461;

UPDATE creature_names SET male_displayid = 23221, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25474;
UPDATE creature_spawns SET displayid = 23221 WHERE entry = 25474;

UPDATE creature_names SET male_displayid = 23230, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25497;
UPDATE creature_spawns SET displayid = 23230 WHERE entry = 25497;

UPDATE creature_names SET male_displayid = 22181, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25625;
UPDATE creature_spawns SET displayid = 22181 WHERE entry = 25625;

UPDATE creature_names SET male_displayid = 23278, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 25656;
UPDATE creature_spawns SET displayid = 23278 WHERE entry = 25656;

UPDATE creature_names SET male_displayid = 24472, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 27258;
UPDATE creature_spawns SET displayid = 24472 WHERE entry = 27258;

UPDATE creature_names SET male_displayid = 28008, female_displayid = 0, male_displayid2 = 0, female_displayid2 = 0 WHERE entry = 28401;
UPDATE creature_spawns SET displayid = 28008 WHERE entry = 28401;

UPDATE creature_proto set npcflags = 2 where entry = 28401;
UPDATE creature_spawns set flags = 2 where entry = 28401;

UPDATE creature_proto set minlevel = 71, maxlevel = 71, minhealth = 11614, maxhealth = 11614 where entry = 25768;













#Plate Mail fix - Warrior
DELETE FROM trainer_spells WHERE learn_spell = '750';
INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16771, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (914, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4594, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4087, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4595, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17120, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5114, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (8141, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4593, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (7315, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3353, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5480, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17504, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1901, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5113, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3043, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (985, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3042, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4089, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3354, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3169, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3041, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5479, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3408, 0, 750, 100, 0, 0, 0, 40, 0, 0);


#- Paladin
INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5491, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1232, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16761, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5148, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5149, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (8140, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (927, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16681, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (20406, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16680, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17509, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5492, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17121, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (928, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (23128, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16275, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16679, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17483, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5147, 0, 750, 100, 0, 0, 0, 40, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17844, 0, 750, 100, 0, 0, 0, 40, 0, 0);



#Dual wield fix for rogues, hunters and warriors
DELETE FROM trainer_spells WHERE learn_spell = '674';
DELETE FROM trainer_spells WHERE cast_spell = '674';
INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16771, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4215, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4087, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4595, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17120, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (8141, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4582, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3963, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (7315, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16738, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16685, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4214, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (6707, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5167, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3327, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1229, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4584, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1231, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1234, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5165, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1411, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3599, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4138, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3170, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (917, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17505, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (1404, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3598, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (13283, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (913, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (2130, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4583, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16686, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (987, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16673, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3328, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5166, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (918, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17480, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3401, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3407, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4089, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (4163, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16672, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16279, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3169, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (5517, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3041, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (3040, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (17122, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (2131, 0, 674, 100, 0, 0, 0, 20, 0, 0);

INSERT INTO trainer_spells
  (entry, cast_spell, learn_spell, spellcost, reqspell, reqskill, reqskillvalue, reqlevel, deletespell, is_prof)
VALUES
  (16684, 0, 674, 100, 0, 0, 0, 20, 0, 0);
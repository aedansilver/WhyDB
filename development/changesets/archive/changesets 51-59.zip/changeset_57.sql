﻿-- Removes the annoying 'This server is powered by WhyDB!' message.
DELETE FROM `worldbroadcast` WHERE `entry`='3';

-- Some displayid fixes.
UPDATE `creature_names` SET `male_displayid`='26853', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='30217';
UPDATE `creature_names` SET `male_displayid`='262', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1371';
UPDATE `creature_names` SET `male_displayid`='338', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1370';
UPDATE `creature_names` SET `male_displayid`='24135', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='26548';
UPDATE `creature_names` SET `male_displayid`='14500', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='14450';
UPDATE `creature_names` SET `male_displayid`='221', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1368';
UPDATE `creature_names` SET `male_displayid`='221', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1367';
UPDATE `creature_names` SET `male_displayid`='3289', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='5492';
UPDATE `creature_names` SET `male_displayid`='338', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1366';
UPDATE `creature_names` SET `male_displayid`='3285', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='5493';
UPDATE `creature_names` SET `male_displayid`='3290', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='5494';
UPDATE `creature_names` SET `male_displayid`='3283', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='5489';
UPDATE `creature_names` SET `male_displayid`='1525', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='2198';
UPDATE `creature_names` SET `male_displayid`='3284', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='5491';
UPDATE `creature_names` SET `male_displayid`='14492', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='14438';
UPDATE `creature_names` SET `male_displayid`='4845', `female_displayid`='4847', `male_displayid2`='4846', `female_displayid2`='4848' WHERE entry='6086';
UPDATE `creature_names` SET `male_displayid`='25943', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='29154';
UPDATE `creature_names` SET `male_displayid`='1498', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1350';
UPDATE `creature_names` SET `male_displayid`='5008', `female_displayid`='5005', `male_displayid2`='5006', `female_displayid2`='5003' WHERE entry='29152';
UPDATE `creature_names` SET `male_displayid`='2985', `female_displayid`='2987', `male_displayid2`='2986', `female_displayid2`='2988' WHERE entry='4996';
UPDATE `creature_names` SET `male_displayid`='1503', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1348';
UPDATE `creature_names` SET `male_displayid`='1500', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1349';
UPDATE `creature_names` SET `male_displayid`='2989', `female_displayid`='2991', `male_displayid2`='2990', `female_displayid2`='2992' WHERE entry='4995';
UPDATE `creature_names` SET `male_displayid`='1499', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='928';
UPDATE `creature_names` SET `male_displayid`='1524', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='1405';
UPDATE `creature_names` SET `male_displayid`='25289', `female_displayid`='0', `male_displayid2`='25341', `female_displayid2`='0' WHERE entry='29144';
UPDATE `creature_names` SET `male_displayid`='14472', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='14423';
UPDATE `creature_names` SET `male_displayid`='26106', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE entry='29287';
UPDATE `creature_names` SET `male_displayid`='18783', `female_displayid`='0', `male_displayid2`='11686', `female_displayid2`='0' WHERE `entry`='15384';
UPDATE `creature_names` SET `male_displayid`='1438', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1402';
UPDATE `creature_names` SET `male_displayid`='26112', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29293';
UPDATE `creature_names` SET `male_displayid`='25845', `female_displayid`='25847', `male_displayid2`='25846', `female_displayid2`='25848' WHERE `entry`='29016';
UPDATE `creature_names` SET `male_displayid`='26111', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29292';
UPDATE `creature_names` SET `male_displayid`='26114', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29295';
UPDATE `creature_names` SET `male_displayid`='26113', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29294';
UPDATE `creature_names` SET `male_displayid`='25850', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29019';
UPDATE `creature_names` SET `male_displayid`='4885', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='6171';
UPDATE `creature_names` SET `male_displayid`='26108', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29289';
UPDATE `creature_names` SET `male_displayid`='26107', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29288';
UPDATE `creature_names` SET `male_displayid`='4887', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='6173';
UPDATE `creature_names` SET `male_displayid`='1126', `female_displayid`='0', `male_displayid2`='11686', `female_displayid2`='0' WHERE `entry`='15214';
UPDATE `creature_names` SET `male_displayid`='26110', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29291';
UPDATE `creature_names` SET `male_displayid`='26109', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29290';
UPDATE `creature_names` SET `male_displayid`='25624', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29142';
UPDATE `creature_names` SET `male_displayid`='2993', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='5042';
UPDATE `creature_names` SET `male_displayid`='26119', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29300';
UPDATE `creature_names` SET `male_displayid`='26115', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29296';
UPDATE `creature_names` SET `male_displayid`='26116', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29297';
UPDATE `creature_names` SET `male_displayid`='26117', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29298';
UPDATE `creature_names` SET `male_displayid`='26118', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='29299';
UPDATE `creature_names` SET `male_displayid`='3167', `female_displayid`='0', `male_displayid2`='5446', `female_displayid2`='0' WHERE `entry`='29712';
UPDATE `creature_names` SET `male_displayid`='7008', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='7917';
UPDATE `creature_names` SET `male_displayid`='5080', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='338';
UPDATE `creature_names` SET `male_displayid`='5552', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1428';
UPDATE `creature_names` SET `male_displayid`='1447', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1299';
UPDATE `creature_names` SET `male_displayid`='1427', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1298';
UPDATE `creature_names` SET `male_displayid`='2709', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='6867';
UPDATE `creature_names` SET `male_displayid`='1446', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1297';
UPDATE `creature_names` SET `male_displayid`='25591', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='28650';
UPDATE `creature_names` SET `male_displayid`='1865', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1719';
UPDATE `creature_names` SET `male_displayid`='1423', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1294';
UPDATE `creature_names` SET `male_displayid`='252', `female_displayid`='251', `male_displayid2`='257', `female_displayid2`='221' WHERE `entry`='14496';
UPDATE `creature_names` SET `male_displayid`='8632', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='14497';
UPDATE `creature_names` SET `male_displayid`='10591', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='11068';
UPDATE `creature_names` SET `male_displayid`='5072', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1284';
UPDATE `creature_names` SET `male_displayid`='25899', `female_displayid`='0', `male_displayid2`='25898', `female_displayid2`='0' WHERE `entry`='29088';
UPDATE `creature_names` SET `male_displayid`='262', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='4982';
UPDATE `creature_names` SET `male_displayid`='2989', `female_displayid`='2991', `male_displayid2`='2990', `female_displayid2`='2992' WHERE `entry`='6237';
UPDATE `creature_names` SET `male_displayid`='1495', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='376';
UPDATE `creature_names` SET `male_displayid`='5081', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='5386';
UPDATE `creature_names` SET `male_displayid`='5549', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1444';
UPDATE `creature_names` SET `male_displayid`='1477', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1312';
UPDATE `creature_names` SET `male_displayid`='1486', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1315';
UPDATE `creature_names` SET `male_displayid`='1485', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1316';
UPDATE `creature_names` SET `male_displayid`='1492', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1317';
UPDATE `creature_names` SET `male_displayid`='5548', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1212';
UPDATE `creature_names` SET `male_displayid`='1481', `female_displayid`='0', `male_displayid2`='0', `female_displayid2`='0' WHERE `entry`='1318';

-- Delete inexistant (in DBC) areatriggers.
DELETE FROM `areatriggers` WHERE `entry` IN ('2527', '2532', '4055', '4057', '4794');

-- Quest item drop: Aether Ray Eye  fixe.
UPDATE creatureloot SET percentchance = 100 WHERE itemid = 32567;

-- Razorthorn Ravager fixe and spawns.
UPDATE `creature_proto` SET `faction` = '16' WHERE `entry` = '24922';
DELETE FROM `creature_spawns` WHERE `entry` = '24922';
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1513.79','4077','217.643','1.50014','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1504.69','4034.81','213.755','2.58792','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1464.73','4044.31','218.506','1.99494','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1371.89','3819.34','215.092','1.15456','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1480.48','3959.61','219.379','2.5565','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1387.55','3778.66','214.664','5.27397','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1441.16','3841.71','213.531','4.52392','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1406.09','3798.39','213.043','4.59461','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1432.35','3925.19','220.874','3.30262','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1500.31','3931.57','217.542','4.80274','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1402.19','3851.9','215.539','0.318114','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1451.97','3890.5','215.296','5.27005','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1474.45','3918.9','216.973','0.561587','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1500.07','3901.32','215.986','4.66922','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1502.77','3953.49','219.797','5.2779','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1511.48','4110.73','217.183','1.16635','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1477.28','4160.24','220.488','1.2763','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1458.53','4092.14','213.981','0.070715','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1446.64','4204.48','231.089','1.65329','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1411.87','4306.63','230.915','1.48444','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1373.36','4345.38','236.097','1.24096','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1314.38','4414.2','222.988','0.451638','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1283.71','4440.8','219.063','1.5669','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1283.81','4482.78','215.188','1.04461','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1231.09','4503.6','212.731','1.38233','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1231.31','4556.47','204.17','0.973926','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1177.65','4577.13','200.912','1.9007','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1187.72','4622.82','195.482','1.42161','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'24922','530','-1155.96','4599.54','195.297','2.90993','0','16631','16','0','0','0','0','0','0','0','0','0','0');

-- Darkspine Iron Ore loot.
REPLACE INTO `creatureloot` VALUES (NULL, '25060', '34479', '0.13', '0', '1', '1', '0');
REPLACE INTO `creatureloot` VALUES (NULL, '25073', '34479', '0.06', '0', '1', '1', '0');
REPLACE INTO `creatureloot` VALUES (NULL, '25084', '34479', '0.55', '0', '1', '1', '0');
REPLACE INTO `creatureloot` VALUES (NULL, '25085', '34479', '0.2', '0', '1', '1', '0');

-- Clintar Dreamwalker & Dreamwarden Lurosa spawn.
DELETE FROM `creature_spawns` WHERE `entry` = '22834';
DELETE FROM `creature_spawns` WHERE `entry` = '22837';
INSERT INTO `creature_spawns` VALUES (NULL,'22837','1','7517.58','-3054.21','444.918','4.88692','0','21111','994','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` VALUES (NULL,'22834','1','7459.48','-3123.03','438.415','5.46924','0','21107','994','0','0','0','0','0','0','0','0','0','0');


/* DK's Death Gate fix */
REPLACE INTO `gameobject_names` (
`entry` ,
`Type` ,
`DisplayID` ,
`Name` ,
`spellfocus` ,
`sound1` ,
`sound2` ,
`sound3` ,
`sound4` ,
`sound5` ,
`sound6` ,
`sound7` ,
`sound8` ,
`sound9` ,
`unknown1` ,
`unknown2` ,
`unknown3` ,
`unknown4` ,
`unknown5` ,
`unknown6` ,
`unknown7` ,
`unknown8` ,
`unknown9` ,
`unknown10` ,
`unknown11` ,
`unknown12` ,
`unknown13` ,
`unknown14`
)
VALUES (
'190942', '22', '8046', 'Death Gate', '53822', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'
);
REPLACE INTO `teleport_coords` (
`id` ,
`name` ,
`mapId` ,
`position_x` ,
`position_y` ,
`position_z` ,
`totrigger`
)
VALUES (
'53822', 'Death Gate', '609', '2355.2299', '-5661.3198', '426.028', '0'
);

/* [FIX] GO quests start: Wanted Poster */
DELETE FROM `gameobject_quest_starter` WHERE `id`='182165';

REPLACE INTO gameobject_quest_starter (`id`, `quest`) VALUES
(182165, 9820),
(182165, 10117),
(182165, 10033);

/* GO: Ley Lines of Quel'Danas */

REPLACE INTO gameobject_names
   (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`)
VALUES
   (310146, 8, 0, 'Ley Lines of Quel\'Danas', 1481, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

DELETE FROM gameobject_spawns WHERE Entry=310146;

REPLACE INTO gameobject_spawns
   (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`)
VALUES
   (310146, 530, 12181.2, -7337.85, 4.19741, 3.34836, 0, 0, 0.99466, -0.103201, 1, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns
   (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`)
VALUES
   (310146, 530, 12579, -6915.97, 4.60172, 3.15358, 0, 0, 0.999982, -0.00599564, 1, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns
   (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`)
VALUES
   (310146, 530, 12776.8, -6701.73, 1.25949, 3.58398, 0, 0, 0.975636, -0.219396, 1, 0, 0, 1, 0);

/* Spawns: Bonechewer Orc */

DELETE FROM creature_spawns WHERE `entry` = '21161';

REPLACE INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`)
VALUES
   (21161, 530, -224.639, 2736.39, -21.2997, 4.65222, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -254.926, 2859.05, -48.0277, 3.95085, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -230.819, 2857.88, -41.4624, 2.35807, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -205.043, 2124.68, 84.7337, 5.34494, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -169.084, 2107.71, 93.4787, 5.5782, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -214.118, 2063.18, 94.3023, 3.7333, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
   (21161, 530, -252.417, 2045.29, 102.322, 3.9053, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
REPLACE INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`)
VALUES
   (21161, 530, -165.648, 2189.12, 81.3844, 1.14149, 0, 17733, 1662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

/* GO-Spawns: Gryphon Eggs */

--  Gryphon Egg spawn fix by Maestro
INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -398.889, -2957.72, 94.6755, 1.62316, 0, 0, 0.725374, 0.688355, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -400.907, -2957.13, 94.3013, 2.18166, 0, 0, 0.887011, 0.461749, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -460.186, -2875.95, 97.045, -0.15708, 0, 0, 0.078459, -0.996917, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -458.228, -2872.08, 97.045, 1.78024, 0, 0, 0.777146, 0.62932, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -248.564, -3100.29, 126.732, -1.51844, 0, 0, 0.688354, -0.725374, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -229.455, -3109.93, 127.045, 0.244346, 0, 0, 0.121869, 0.992546, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -401.472, -2890.84, 86.4709, 0.122173, 0, 0, 0.0610485, 0.998135, 1, 4, 0, 1, 0);

INSERT INTO gameobject_spawns
  (Entry, map, position_x, position_y, position_z, Facing, orientation1, orientation2, orientation3, orientation4, State, Flags, Faction, Scale, stateNpcLink)
VALUES
  (181645, 0, -403.663, -2888.74, 84.9427, -0.418879, 0, 0, 0.207912, -0.978148, 1, 4, 0, 1, 0);
  
/* The Scarab Gong */
UPDATE `gameobject_names` SET `Type`='2',`sound1`='8742' WHERE `entry`='180717';
DELETE FROM gameobject_spawns WHERE `entry`='180717';
REPLACE INTO gameobject_spawns
   (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`)
VALUES
   (180717, 1, -8068.92, 1641.87, 27.0302, 1.59593, 0, 0, 0.715937, 0.698165, 1, 0, 0, 1, 0);

/* Basic Campfire FIX */
UPDATE `gameobject_names` SET `sound1`='10',`sound2`='31442' WHERE `entry`='29784';

/* Frostsaber Stalker Faction FIX */
UPDATE `creature_proto` SET `faction`='14' WHERE (`entry`='7432');
UPDATE `creature_spawns` SET `faction`='14' WHERE (`entry`='7432');

/* Tunkk Leatherworking Supplies SPAWN FIX */
INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate)
VALUES
  (2819, 0, -963.385, -3562.79, 58.8988, 4.59065, 2, 3951, 29, 4608, 16777472, 0, 4097, 0, 0, 0, 0, 0, 0);
  
/* Keena Trade Goods SPAWN FIX */
INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate)
VALUES
  (2821, 0, -918.911, -3533.79, 72.881, 0.977384, 0, 3953, 29, 4608, 16843008, 0, 4097, 0, 0, 0, 0, 0, 0);

/* A Dark Threat Looms */
UPDATE `quests` SET `PrevQuestid` = '0' WHERE `entry` = '250';
UPDATE `quests` SET `RequiredQuest1` = '0' WHERE `entry` = '250';

/* Image of Wind Trader Marid SPAWN FIX*/
INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate)
VALUES
  (20518, 530, 4007.08, 1517.26, -115.535, 5.09721, 0, 19671, 1731, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  
/* Gaeriyan spawn fix by Maestro */
INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate)
VALUES
  (9299, 1, -6938.25, -3904.91, 28.4402, 0.102051, 0, 8717, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  

/* Summon Charger Quest line FIX */
UPDATE `quests` SET `PrevQuestId`='9736',`RequiredQuest1`='9736' WHERE `entry`='9737';
UPDATE `quests` SET `PrevQuestId`='9735',`RequiredQuest1`='9735' WHERE `entry`='9736';
UPDATE `quests` SET `PrevQuestId`='9725',`RequiredQuest1`='9725' WHERE `entry`='9735';
UPDATE `quests` SET `PrevQuestId`='9723',`RequiredQuest1`='9723' WHERE `entry`='9725';
UPDATE `quests` SET `PrevQuestId`='9722',`RequiredQuest1`='9722' WHERE `entry`='9723';
UPDATE `quests` SET `PrevQuestId`='9721',`RequiredQuest1`='9721' WHERE `entry`='9722';

/* Abjurist Belmara Quest FIX */
update quests set reqkillmoborgoid1='0' where entry='10305';
update quests set reqkillmoborgoid2='0' where entry='10305';
update quests set reqkillmoborgoid3='0' where entry='10305';
update quests set reqkillmoborgoid4='0' where entry='10305';
update quests set reqkillmoborgocount1='0' where entry='10305';
update quests set reqkillmoborgocount2='0' where entry='10305';
update quests set reqkillmoborgocount3='0' where entry='10305';
update quests set reqkillmoborgocount4='0' where entry='10305';
update quests set reqcastspellid1='34140' where entry='10305';

/* Cohlien Frostweaver Quest FIX */
update quests set reqkillmoborgoid1='0' where entry='10307';
update quests set reqkillmoborgoid2='0' where entry='10307';
update quests set reqkillmoborgoid3='0' where entry='10307';
update quests set reqkillmoborgoid4='0' where entry='10307';
update quests set reqkillmoborgocount1='0' where entry='10307';
update quests set reqkillmoborgocount2='0' where entry='10307';
update quests set reqkillmoborgocount3='0' where entry='10307';
update quests set reqkillmoborgocount4='0' where entry='10307';
update quests set reqcastspellid1='34144' where entry='10307';

/* Conjurer Luminrath Quest FIX */
update quests set reqkillmoborgoid1='0' where entry='10306';
update quests set reqkillmoborgoid2='0' where entry='10306';
update quests set reqkillmoborgoid3='0' where entry='10306';
update quests set reqkillmoborgoid4='0' where entry='10306';
update quests set reqkillmoborgocount1='0' where entry='10306';
update quests set reqkillmoborgocount2='0' where entry='10306';
update quests set reqkillmoborgocount3='0' where entry='10306';
update quests set reqkillmoborgocount4='0' where entry='10306';
update quests set reqcastspellid1='34142' where entry='10306';

/* Battle-mage Dathrige Quest FIX */
update quests set reqkillmoborgoid1='0' where entry='10182';
update quests set reqkillmoborgoid2='0' where entry='10182';
update quests set reqkillmoborgoid3='0' where entry='10182';
update quests set reqkillmoborgoid4='0' where entry='10182';
update quests set reqkillmoborgocount1='0' where entry='10182';
update quests set reqkillmoborgocount2='0' where entry='10182';
update quests set reqkillmoborgocount3='0' where entry='10182';
update quests set reqkillmoborgocount4='0' where entry='10182';
update quests set reqcastspellid1='34141' where entry='10182';
  
/* Missing GO */
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191164','22','8111','Portal to Dalaran','53141','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');

/* AgmAr: Added few sniffed GO's */
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('1685','8','209','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2061','6','0','Campfire','0','1','2','7897','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2066','6','0','Bonfire Damage','0','1','5','7902','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2098','5','27','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2102','5','27','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2108','5','27','Trade District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2109','5','169','Fragrant Flowers','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2115','5','26','Trade District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2117','5','26','Stormwind Keep','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2120','5','26','Stormwind Keep','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2122','5','26','Trade District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2125','5','26','Trade District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2129','5','26','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2131','5','26','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2133','5','26','Trade District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2134','5','26','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2136','5','26','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2140','5','26','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2143','5','26','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2150','5','718','The Silver Shield','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2152','5','538','Pig and Whistle Tavern','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2153','5','725','Heavy Handed Weapons','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2154','5','718','The Protective Hide','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2157','5','725','Just Maces','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2159','5','681','City Hall','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2160','5','681','The Argent Dawn','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('2189','5','26','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('3662','3','336','Food Crate','57','2578','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10192','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10193','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10195','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10196','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10199','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10200','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10202','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10203','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10204','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10205','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10206','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10210','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10211','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10212','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10213','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10214','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10215','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10217','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('10219','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('21583','9','560','The Kaldorei and the Well of Eternity','637','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('23302','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('23303','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('23304','8','204','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('23305','8','209','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24389','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24392','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24393','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24394','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24396','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24398','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24400','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24402','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24404','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24408','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24409','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24410','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24411','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24412','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24413','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24414','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24415','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24416','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24417','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24418','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24419','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24420','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24421','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24423','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24424','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24428','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24436','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24446','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24451','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24452','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24453','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24455','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24460','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24461','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24462','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24463','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24464','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24472','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24483','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24491','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24494','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24495','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24497','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24499','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24507','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24508','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24512','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24513','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24514','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24515','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24516','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24517','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24518','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24519','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24520','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24525','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24535','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24546','7','603','Wooden Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24551','7','603','Wooden Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24558','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24565','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24575','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24589','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24597','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24601','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24603','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24604','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24606','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24607','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24612','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24613','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24614','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24615','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24616','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24617','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24618','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24620','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24621','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24622','7','622','Stone Bench','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24635','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24636','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24637','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24638','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24639','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24640','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24641','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24642','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24643','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24644','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24645','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24646','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24647','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24648','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24649','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24650','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24651','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24652','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24655','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24656','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24659','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24660','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24661','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24662','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24664','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24672','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24676','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24677','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24678','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24679','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24680','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24682','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24683','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24685','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24688','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24689','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24690','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24691','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24692','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24696','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24697','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24698','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24699','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24704','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24705','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24706','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24745','8','233','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24746','8','305','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24761','8','199','Warm Fire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('24762','8','199','Warm Fire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25336','5','7722','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25337','5','7722','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25338','5','4171','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25339','5','4171','Cathedral Square','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25346','5','7722','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('25347','5','7722','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('26494','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('26496','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('26499','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28027','5','26','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28028','5','26','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28029','5','26','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28030','5','26','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28031','5','26','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28033','5','27','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28034','5','27','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28038','5','26','Stormwind Gate','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28041','5','26','Stormwind Gate','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28043','5','26','Stormwind Gate','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28044','5','7721','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28045','5','7721','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28046','5','7721','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('28047','5','7721','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32349','19','1947','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32358','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32385','5','660','The Military Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32391','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32404','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32416','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32424','5','660','The Great Forge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('32429','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('35591','17','668','Fishing Bobber','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('37478','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('92011','8','273','Grimand\'s Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('103793','5','26','Mage Quarter','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('103796','5','26','Old Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('126046','5','7721','Dwarven District','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('130125','5','751','The Five Deadly Venoms','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('137644','5','660','The Forlorn Cavern','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('137647','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142339','5','660','The Mystic Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142838','5','660','The Mystic Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142851','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142911','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142912','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142914','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142915','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('142916','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143249','5','635','Craghelm\'s Plate and Chain','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143250','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143251','5','636','Goldfury\'s Hunting Supplies','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143253','5','640','Barim\'s Reagents','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143254','5','638','Timberline Arms','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143255','5','639','Bruuk\'s Corner','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143317','5','639','The Stonefire Tavern','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143323','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143324','5','638','Steelfury\'s Weapon Emporium','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143325','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143333','5','643','The Bronze Kettle','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143334','5','656','Finespindle\'s Leather Goods','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143336','5','642','Ironforge Physician','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143337','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143338','5','640','Thistlefuzz Arcanery','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143343','5','656','Stonebrow\'s Clothier','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143344','5','641','Deep Mountain Mining Guild','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143345','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143346','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143347','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143348','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143349','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('143362','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('144128','19','1907','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('144162','5','658','Springspindle\'s Gadgets','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('147824','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('148976','6','0','Fire','0','1','10','12796','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('149412','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('149417','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('149418','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('150087','5','637','Burbik\'s Supplies','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('152614','11','1587','Elevator','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164759','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164760','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164761','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164762','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164763','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164764','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164765','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164766','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164767','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('164908','5','719','Thane\'s Boots','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171525','5','660','The Great Forge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171526','5','660','Ironforge Main Gate','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171527','5','660','Tinker Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171528','5','660','Tinker Town','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171529','5','660','The Great Forge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171530','5','660','The Forlorn Cavern','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171531','5','660','The Library','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171532','5','660','Hall of Explorers','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171533','5','660','The Military Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171534','5','660','The Mystic Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171535','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171536','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171539','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171541','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171544','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171545','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171546','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171547','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171550','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171551','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171552','8','2470','Hot Coals','4','10','148976','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171553','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171554','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171555','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171556','19','1947','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171557','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171558','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171559','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171560','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171561','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171562','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171563','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171564','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171565','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171566','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171569','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171570','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171571','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171572','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171573','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171574','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171575','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171576','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171577','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171578','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171579','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171589','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171590','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171591','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171592','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171604','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171605','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171606','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171607','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171633','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171634','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171635','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171636','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171638','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171639','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171641','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171643','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171646','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171647','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171650','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171651','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171660','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171661','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171664','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171665','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171666','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171667','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171668','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171669','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171670','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171671','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171672','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171673','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171678','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171679','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171686','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171687','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171688','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171689','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171690','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171691','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171692','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171693','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171694','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171695','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171696','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171697','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171698','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171699','19','1947','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171700','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171701','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171702','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171703','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171704','5','635','Ironforge Armory','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171705','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171706','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171707','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171708','5','660','The Military Ward','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171709','5','660','The High Seat','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171710','5','660','Hall of Explorers','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171711','5','660','The High Seat','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171712','5','660','Hall of Explorers','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171713','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171714','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171715','8','2092','The Great Anvil','1','17','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171716','8','2375','Forge','3','30','148976','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171717','8','2374','Forge','3','30','148976','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171722','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171723','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171724','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171725','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171726','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171727','7','648','Dwarven High Back Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171728','7','648','Dwarven High Back Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171729','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171730','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171731','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171732','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171733','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171734','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171735','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171736','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171737','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171738','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171739','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171740','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171741','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171742','8','679','Potbelly Stove','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171743','8','679','Potbelly Stove','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171746','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171747','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171748','5','666','Berryfizz\'s Potions and Mixed Drinks','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171749','5','659','Things That Go Boom!','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171750','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171751','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171752','19','2190','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171753','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171754','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171755','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171756','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171757','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171758','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171759','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171760','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171761','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171762','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171763','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171764','8','197','Dwarven Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171771','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171772','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171773','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171774','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171775','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('171776','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('174746','9','3412','Etched Note','1591','0','4','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('174848','2','3572','Testing Equipment','0','3751','0','2581','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175265','2','3571','Testing Equipment','0','4331','0','3050','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175663','5','658','Doodad_GnomeSign_Engineer01','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175664','5','666','Doodad_DwarfSign_Alchemist01','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175665','5','659','Doodad_DwarfSign_Fireworks01','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175666','8','197','Brazier','0','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175667','8','197','Brazier','0','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175668','19','2190','Postbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175679','9','214','The Skull of Tyrannistrasz','1751','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175680','9','214','Fossilized Egg','1760','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175681','9','214','Roc Talon','1752','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175682','9','214','Geru Strider','1753','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175683','9','214','Toothgnasher\'s Skeleton','1754','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175684','9','214','Saurial Egg','1755','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175685','9','214','Pteradon Skeleton','1756','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175739','9','560','War of the Three Hammers','1914','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('175752','9','559','The New Horde','2030','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176004','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176005','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176006','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176007','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176008','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176009','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176010','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176011','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176012','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176013','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176014','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176015','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176016','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176017','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176018','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176019','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176020','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176021','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176022','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176023','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176024','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176025','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176026','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176027','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176028','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176029','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176030','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176031','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176032','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176033','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176034','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176035','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176036','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176037','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176038','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176039','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176040','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176041','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176042','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176043','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176044','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176045','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176046','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176047','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176048','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176049','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176050','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176051','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176052','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176053','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176054','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176055','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176056','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176057','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176058','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176059','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176060','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176061','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176062','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176063','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176064','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176065','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176066','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176067','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176068','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176069','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176070','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176071','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176072','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176073','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176074','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176075','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176076','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176077','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176078','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176079','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176080','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176081','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176082','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176083','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176084','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176085','11','3831','Subway','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176098','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176099','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176100','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176101','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176102','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176103','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176104','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176105','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176106','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176107','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176108','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176109','7','4091','Subway Bench','3','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176231','15','3015','Ship (The Lady Mehley)','292','30','1','0','0','1','584','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176310','15','3015','Ship (The Bravery)','967','30','1','0','0','1','588','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176311','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176312','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176313','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176314','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176315','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176316','7','673','Pew','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176576','0','4413','Officer\'s Door','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176624','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176625','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176626','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176627','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176628','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176629','8','197','Dwarven Brazier','4','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('176924','5','32','Ironforge Auction house','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('177200','9','214','King Llane I of the House of Wrynn','2292','0','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('177201','9','214','Grand Admiral Daelin Proudmoore','2293','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('177202','9','214','Lady Mara Fordragon','2294','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('178304','5','528','Box o\' Squirrels','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179264','1','261','Giant Clam','0','0','196608','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179345','1','259','Deeprun Chest','0','0','196608','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179595','23','5494','Meeting Stone','21','29','717','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179706','9','254','A Treatise on Military Ranks','2654','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179725','5','26','Champions\' Hall','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179728','5','26','Champions\' Hall','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179731','5','26','Command Center','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179732','5','26','SI:7','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179743','5','26','Command Center','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179744','5','26','SI:7','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('179984','8','6051','Brazier','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('180665','2','107','Draconic for Dummies','0','0','0','6669','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('180728','1','6519','Firework, Show, Type 1 White','0','0','196608','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('182071','5','4251','Small Chapel Fire','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('182072','5','4452','Large Chapel Fire','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186238','15','7546','Zeppelin, Horde (The Mighty Wind)','712','30','1','0','0','0','613','3481','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186835','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186836','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186837','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186838','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186839','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186840','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186841','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186842','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186843','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('186844','7','39','Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187188','8','200','Bonfire','4','10','2066','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187256','8','305','Forge','3','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187258','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187259','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187268','19','2190','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187279','5','388','Warsong Hold','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187280','5','388','Fizzcrank Airstrip','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187281','5','388','Taunka\'le Village','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187282','5','388','Kaskala','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187286','5','388','Riplash Ruins','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187287','5','388','Amber Ledge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187294','34','7608','Guild Vault','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187297','5','388','Fizzcrank Airstrip','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187298','5','388','Warsong Hold','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187304','5','388','Kaskala','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187305','5','388','Warsong Hold','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187306','5','388','Fizzcrank Airstrip','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187307','5','388','Taunka\'le Village','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187316','19','7610','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187324','5','388','Amber Ledge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187325','5','388','Amber Ledge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187338','5','388','Valiance Keep','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187348','5','388','Valiance Keep','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187349','5','388','Amber Ledge','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187350','5','388','Bor\'gorok Outpost','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187351','5','388','Sholazaar Basin','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187352','5','388','Valiance Keep','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187353','5','388','Bor\'gorok Outpost','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187558','7','91','','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187560','10','245','Valiance Keep Cannon','0','0','0','196608','0','0','0','0','0','0','42442','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187565','2','7633','Elder Atkanok','0','8450','0','0','0','0','0','0','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187670','3','7472','Tuskarr Ritual Object','1691','23085','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187675','5','5751','Borean Tundra Fire Large','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187689','3','31','Crafty\'s Stuff','1690','23094','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187851','2','328','Cultist Shrine','0','8672','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187880','5','6679','Circle','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187886','3','402','Burblegobble\'s Bauble','1768','23166','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187889','5','330','Airman Skyhopper\'s Flying Machine','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187897','3','6314','Fizzcrank Spare Parts','43','23168','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187899','3','6867','Fizzcrank Spare Parts','43','23168','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187900','3','6868','Fizzcrank Spare Parts','43','23168','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187901','3','451','Fizzcrank Spare Parts','43','23168','0','1','0','0','0','0','0','0','0','0','0','0','19676','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187915','9','218','Wanted: Hemet Nesingwary, Enemy of Nature','3057','0','2','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187980','3','1','First Aid Supplies','43','23176','0','0','0','0','0','0','0','0','0','0','0','0','21400','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187982','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187987','10','353','South Point Station Valve','1690','11788','17208','196608','0','0','0','0','0','0','0','0','0','0','19700','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187995','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187996','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187997','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187998','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('187999','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188000','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188001','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188002','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188005','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188006','10','7529','Caribou Trap','95','11865','0','0','0','1','0','0','0','0','46104','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188018','3','7680','Shipment of Animal Parts','93','23194','0','1','0','0','0','0','0','0','0','0','0','0','23645','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188027','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188029','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188030','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188031','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188033','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188040','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188041','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188042','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188043','1','7529','Mammoth Trap','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188109','10','353','South Point Station Valve','1690','11907','17208','196608','0','0','0','0','0','0','0','0','0','0','19700','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188120','3','6892','Fields, Factories and Workshops','1690','23321','0','0','0','0','0','0','0','0','0','0','0','0','23645','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188160','0','243','Explosives Cart','0','0','39321600','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188164','3','644','Kaskala Supplies','43','23374','0','1','0','0','0','0','0','0','0','0','0','0','23645','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188454','5','2047','Fizzcrank Paratrooper Teleporter','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188521','11','7797','Elevator','0','0','196608','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188612','8','200','Bonfire','4','10','2066','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188651','8','305','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188652','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('188692','10','245','Valiance Keep Cannon','0','0','0','196608','0','0','0','0','0','0','42442','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('189287','8','192','Campfire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('189315','5','7843','Dead Orca','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('189321','6','3072','Explosive Trap V','12','0','5','49064','1','0','0','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('189973','3','7844','Goldclover','1644','24093','0','1','1','1','0','0','0','72','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190287','9','5992','King Varian Wrynn','3102','7','4','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190352','0','7869','Doodad_HU_Portcullis03','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190536','15','7446','Ship, Icebreaker (Stormwind\'s Pride)','965','21','1','0','0','1','614','3481','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190556','8','199','Fireplace','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190557','8','1287','Runeforge','1552','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190568','33','628','Light\'s Point Tower','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190569','10','6352','Acherus Lightning','0','0','0','196608','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190584','3','7961','Battle-worn Sword','1635','24611','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190647','5','7971','Corpses','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190680','7','648','Dwarven High Back Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190681','7','648','Dwarven High Back Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190683','32','7896','Barbershop Chair','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190684','32','7896','Barbershop Chair','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190709','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190710','32','7896','Barbershop Chair','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190711','32','7896','Barbershop Chair','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190712','32','7896','Barbershop Chair','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190713','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190714','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190715','7','91','Highback Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190859','5','215','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190860','5','8021','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190861','5','286','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190862','5','285','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190863','5','8022','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190864','5','8023','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190865','5','5834','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190866','5','6370','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190867','5','6389','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190868','5','625','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190869','5','8021','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190870','5','154','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190871','5','8024','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190872','5','8025','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190873','5','5834','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190874','5','8022','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190875','5','8022','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190876','5','6370','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190877','5','6370','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190878','5','279','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190879','5','18','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190880','5','8026','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190881','5','9','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190882','5','6389','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190883','5','8021','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190884','5','8027','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190885','5','138','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190886','5','8024','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190887','5','3678','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190888','5','279','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190889','5','279','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190890','5','8028','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190891','5','6733','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190892','5','8021','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190893','5','8029','','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('190942','22','8046','Death Gate','52751','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191083','5','8050','Demonic Circle: Summon','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191126','16','787','Duel Flag','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191142','8','200','Bonfire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191148','33','7552','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191228','19','7815','Mailbox','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191237','8','233','Forge','3','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191238','8','273','Anvil','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191239','8','192','Campfire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191240','8','192','Campfire','4','10','2061','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191303','3','2313','Firethorn','1786','25089','0','1','1','1','0','191304','0','71','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191304','6','8083','Firethorn Trap','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191364','1','6700','Doodad_Nox_portal_orange_bossroom01','1','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191370','6','4251','Blaze','0','70','0','54085','0','0','65536','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191374','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191375','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191376','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191377','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191378','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191379','7','39','Wooden Chair','1','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191503','8','6701','Anvil','1','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191504','8','6701','Anvil','1','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191505','8','209','Forge','3','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191506','8','6701','Anvil','1','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191507','8','6701','Anvil','1','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191508','8','209','Forge','3','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191538','1','6699','Doodad_Nox_portal_purple_bossroom01','1','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191539','1','6699','Doodad_Nox_portal_purple_bossroom17','1','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191540','8','8109','Alchemy Lab','663','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191541','8','8109','Alchemy Lab','663','10','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191554','10','8067','Skeletal Gryphon Roost','0','0','0','0','0','0','0','0','0','0','0','0','191555','1','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191555','6','8114','Scourge Gryphon Roost Glow','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191577','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191580','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191581','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191582','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191583','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191584','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191585','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191586','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191587','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191588','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191589','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191590','1','8115','Acherus Soul Prison','0','1796','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191609','10','8123','Eye of Acherus Control Mechanism','1635','12641','0','0','0','0','0','0','0','0','51888','0','0','1','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191612','10','8124','Eye of Acherus (Flavor)','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191613','5','8125','Eye of Acherus (Flavor Trap)','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191616','9','8127','Touch of the Banshee','3157','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191617','9','8128','Compendium of Fallen Heroes','3163','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191618','9','8032','Report from the Frontlines: Western Northrend','3167','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191631','9','8130','Report from the Frontlines: Eastern Kingdoms','3169','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191632','9','3731','Report from the Frontlines: Dragonblight','3171','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191633','9','338','Report from the Frontlines: Undercity','3173','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191634','9','4135','The Death Knights of Acherus','3175','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191646','9','8131','Corpulous\' Mess Hall Rules','3211','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191648','9','6487','Account of the Raising of a Frost Wyrm','3213','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191649','9','1128','The Memoirs of Lord Thorval','3218','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191650','9','8133','Guide to the Side Effects of Reanimation','3226','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191652','9','6619','Grooming for Ghouls','3229','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191654','9','4371','ATTENTION: Geists','3239','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191655','9','8135','One Truth in Undeath','3240','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191656','9','559','On Scholomance','3244','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191657','9','3871','On Stratholme','3248','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191658','9','2530','On Naxxramas','3252','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191659','9','560','On Undeath','3256','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191662','9','7705','A Zombie\'s Guide to Proper Nutrition','3260','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191663','9','8136','This is my Runeblade...','3261','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191664','9','928','The Decree of the Scourge ','3269','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191746','5','8175','Runeforge','1','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191747','5','8175','Runeforge','1','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
replace into `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`, `sound2`, `sound3`, `sound4`, `sound5`, `sound6`, `sound7`, `sound8`, `sound9`, `unknown1`, `unknown2`, `unknown3`, `unknown4`, `unknown5`, `unknown6`, `unknown7`, `unknown8`, `unknown9`, `unknown10`, `unknown11`, `unknown12`, `unknown13`, `unknown14`) values('191748','5','8175','Runeforge','1','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');

/* remove double questitem */
replace into `quests` (`entry`, `ZoneId`, `sort`, `flags`, `MinLevel`, `questlevel`, `Type`, `RequiredRaces`, `RequiredClass`, `RequiredTradeskill`, `RequiredTradeskillValue`, `RequiredRepFaction`, `RequiredRepValue`, `LimitTime`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `srcItem`, `SrcItemCount`, `Title`, `Details`, `Objectives`, `CompletionText`, `IncompleteText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqKillMobOrGOId1`, `ReqKillMobOrGOId2`, `ReqKillMobOrGOId3`, `ReqKillMobOrGOId4`, `ReqKillMobOrGOCount1`, `ReqKillMobOrGOCount2`, `ReqKillMobOrGOCount3`, `ReqKillMobOrGOCount4`, `ReqCastSpellId1`, `ReqCastSpellId2`, `ReqCastSpellId3`, `ReqCastSpellId4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepFaction6`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewRepValue6`, `RewRepLimit`, `RewMoney`, `RewXP`, `RewSpell`, `CastSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `RewardMoneyAtMaxLevel`, `ExploreTrigger1`, `ExploreTrigger2`, `ExploreTrigger3`, `ExploreTrigger4`, `RequiredQuest1`, `RequiredQuest2`, `RequiredQuest3`, `RequiredQuest4`, `ReceiveItemId1`, `ReceiveItemId2`, `ReceiveItemId3`, `ReceiveItemId4`, `ReceiveItemCount1`, `ReceiveItemCount2`, `ReceiveItemCount3`, `ReceiveItemCount4`, `IsRepeatable`) values('10174','3523','0','128','67','68','0','0','0','0','0','0','0','0','0','10300','10188','28455','1','Curse of the Violet Tower','Now, you will be able to use the archmage\'s staff to contact him.$B$BHe resides in the Violet Tower, on an \'island\' to the southeast. The tower is both sanctuary and prison to him, cursed as it is. Kirin Tor can neither enter nor leave, keeping me apart from my master.$B$BThe staff\'s magic can penetrate the tower\'s defenses, but only if invoked by one outside the Kirin Tor.$B$BTake the archmage\'s staff and use it to conjure his image. Tell him what has happened and that I have not completely failed him.','Use Archmage Vargoth\'s Staff to make contact with Archmage Vargoth.$B$BIf you lose Archmage Vargoth\'s Staff, speak to Ravandwyr at Area 52 to receive a replacement.','<Archmage Vargoth\'s image examines you as you convey Ravandwyr\'s message.>$B$BRavandwyr has everything a master can expect of his apprentice. When I gave him the staff and told him to flee, I hoped that he would use it to find help and free me once Kael\'thas\'s forces withdrew from the tower. Since then, I have learned a great deal about the nature of the curse.$B$BIt can be broken, $N;, but it will require your help.','','','','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','3050','0','0','0','0','0','0','18300','0','0','0','0','10300','0','0','0','0','0','0','0','0','0','0','0','0');

/* Portal to ironforge Fix */
UPDATE `gameobject_names` SET `spellfocus` = '44089' WHERE `gameobject_names`.`entry` =183322 LIMIT 1 ;

/* Fixed Typos in GOs */
UPDATE `gameobject_names` SET `Name`='Copper Vein' WHERE `entry`='181248';
UPDATE `gameobject_names` SET `Name`='Tin Vein' WHERE `entry`='181249';

/* Fell Spirit Fixes */
update creature_proto set respawntime=600000 where entry=22454;
update creature_names set male_displayid=21072, female_displayid=0, male_displayid2=0, female_displayid2=0 where entry=20243;

/* List without any clue, but seems to be blizzlike */
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'8379','1','3982.23','-4760.74','304.804','4.67397','0','7591','35','0','0','0','0','0','0','0','0','0','0');
DELETE FROM creatureloot WHERE entryid = 6749;
UPDATE creature_proto SET faction = 14 WHERE entry = 20671;
UPDATE creature_proto SET faction = 14 WHERE entry = 10200;
UPDATE creature_proto SET faction = 14 WHERE entry = 2573;
UPDATE creature_proto SET npcflags = '4227' WHERE entry = '7852';
replace INTO `item_quest_association` VALUES (20760,8479,1);
replace INTO `item_quest_association` VALUES (31744,10897,1);
DELETE FROM `items` WHERE `entry` = 19879;
DELETE FROM `items` WHERE `entry` = 12947;
DELETE FROM `creature_spawns` WHERE `entry` = 22834;
DELETE FROM `creature_spawns` WHERE `entry` = 22837;
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'22837','1','7517.58','-3054.21','444.918','4.88692','0','21111','994','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'22834','1','7459.48','-3123.03','438.415','5.46924','0','21107','994','0','0','0','0','0','0','0','0','0','0');
UPDATE `creature_proto` SET `faction` = 16 WHERE `entry` = 24922;
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1513.79','4077','217.643','1.50014','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1504.69','4034.81','213.755','2.58792','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1464.73','4044.31','218.506','1.99494','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1371.89','3819.34','215.092','1.15456','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1480.48','3959.61','219.379','2.5565','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1387.55','3778.66','214.664','5.27397','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1441.16','3841.71','213.531','4.52392','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1406.09','3798.39','213.043','4.59461','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1432.35','3925.19','220.874','3.30262','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1500.31','3931.57','217.542','4.80274','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1402.19','3851.9','215.539','0.318114','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1451.97','3890.5','215.296','5.27005','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1474.45','3918.9','216.973','0.561587','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1500.07','3901.32','215.986','4.66922','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1502.77','3953.49','219.797','5.2779','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1511.48','4110.73','217.183','1.16635','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1477.28','4160.24','220.488','1.2763','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1458.53','4092.14','213.981','0.070715','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1446.64','4204.48','231.089','1.65329','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1411.87','4306.63','230.915','1.48444','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1373.36','4345.38','236.097','1.24096','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1314.38','4414.2','222.988','0.451638','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1283.71','4440.8','219.063','1.5669','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1283.81','4482.78','215.188','1.04461','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1231.09','4503.6','212.731','1.38233','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1231.31','4556.47','204.17','0.973926','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1177.65','4577.13','200.912','1.9007','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1187.72','4622.82','195.482','1.42161','0','16631','16','0','0','0','0','0','0','0','0','0','0');
INSERT INTO `creature_spawns` (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`) VALUES(NULL,'24922','530','-1155.96','4599.54','195.297','2.90993','0','16631','16','0','0','0','0','0','0','0','0','0','0');

/* Master & Artisan Cookbook FIX */
update items set spellid_1=19886, spellid_2=483, spelltrigger_2=6 where entry=16072;
update items set spellid_1=33361, spellid_2=483, spelltrigger_2=6 where entry=27736;

/* Undercover Sister quest-fix */
UPDATE `quests` SET `ObjectiveText1` = '', `ReqKillMobOrGOId1` = '0', `ReqKillMobOrGOCount1` = '0', `RequiredQuest1` = '11178' WHERE `entry` =11163 LIMIT 1 ;

/* Pattern: Mycah's Botanical Bag */
UPDATE `items` SET `RequiredFaction`='970' WHERE `entry`='38229'; 

/* Itempages: Mor'zul's Instructions */
REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2691, 'To bind a dreadsteed, you must do these three things:\r\n\r\nCreate a Circle of Greater Summoning.\r\n\r\nWithin the Circle, open a portal to Xoroth and pull the dreadsteed through it.\r\n\r\nDefeat the dreadsteed, then dominate its spirit.\r\n\r\nThe following pages will detail how each of these steps may be performed.  It will not be easy, but you have proven to be very able.  With focus and skill, I am confident the dreadsteed will be yours.\r\n\r\nRead on, Mor\'zul Bloodbringer', 2692);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2692, 'Implements of the Ritual\r\n\r\nBefore you begin your task, you must have the following magical implements:\r\n\r\nJ\'eevee\'s Jar\r\nA Black Lodestone\r\nXorothian Glyphs\r\n\r\nMy servant Gorzeeki will have them for you, for a price.  Do not attempt any step of your ritual without all of these implements.  Each is essential.\r\n\r\nWithin the next pages, I will describe how each implement must be used.', 2693);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2693, 'Circle of Greater Binding\r\n\r\nA Circle of Greater Binding must be created at a site where magic is strong.  There is such a place deep in the ruins of Eldre\'Thalas, also called Dire Maul.  In Eldre\'Thalas there is imprisoned a being of great power, Immol\'thar; it is on the pedestal of his prison where you must perform the ritual to create the Circle.\r\n\r\nFight your way to the Pedestal, then let J\'eevee out of his jar.', 2694);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2694, 'The Bell, the Wheel and the Candle\r\n\r\nAfter releasing J\'eevee he will then place the Bell, the Wheel and the Candle, and a circle will appear.  This is the start of the ritual.  You must be vigilant; the aforementioned objects conduct vast energies and are prone to failing.  When this happens you must quickly use your Black Lodestone to restart them before your entire ritual fails.\r\n\r\nIf all three objects have failed before you can restart them, then your ritual ends and you must begin it anew.', 2695);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2695, 'In addition to conducting the energies of the ritual, the Bell, Wheel and Candle have unique properties of their own.\r\n\r\nThe Bell of Dethmoora, when ringing, bestows warlocks in the circle with vigor and energy.\r\n\r\nThe Wheel of the Black March, when spinning, protects those in the circle from harm.\r\n\r\nThe Doomsday Candle, when burning, sends eldritch energy at foes who enter the circle.\r\n\r\nBecause of these blessings, it is very important to keep all of these objects working during the ritual.', 2696);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2696, 'It must also be noted that the Black Lodestone, used to restart the Bell, Wheel or Candle if they fail, requires soul shards.  Each time you restart a ritual object with the Lodestone one of your soul shards will be consumed, so be sure to have a large stock of them before the ritual begins.\r\n', 2697);

REPLACE INTO itempages
   (`entry`, `text`, `next_page`)
VALUES
   (2697, 'Completing the Ritual\r\n\r\nYou can track your progress by the magic runes along the border of the circle.  When nine runes appear then the ritual is complete, and you will see energy rise from the newly empowered Circle.\r\n\r\nFrom there, you may invoke the Xorothian Glyphs and open a portal into Xoroth and pull a dreadsteed through it.\r\n\r\nDefeat the dreadsteed and release his spirit.  Confront the spirit and it will be enthralled, and you will be rewarded with the secret of its summoning.', 0);
   
/* hp and stuff */
UPDATE `creature_proto` SET `minlevel`='71', `maxlevel`='71', `minhealth`='64000', `maxhealth`='64000', `mindamage`='200', `maxdamage`='400' WHERE `entry`='21140';

/* Quest Ethereum Prisioner and something more */
update creature_proto set minlevel=71, maxlevel=71, faction=16, minhealth=7181, maxhealth=7181, mindamage=180, maxdamage=280 where entry=20520;
-- Second the loot
delete from creatureloot where entryid=20520;
insert into creatureloot (entryid,itemid,percentchance,heroicpercentchance,mincount,maxcount,ffa_loot) values
(20520, 31957, 93, 0, 1, 1, 0),
(20520, 21877, 27, 0, 1, 3, 0),
(20520, 30477, 11, 0, 1, 1, 0),
(20520, 27677, 7, 0, 1, 1, 0),
(20520, 25057, 5, 0, 1, 1, 0),
(20520, 25309, 3, 0, 1, 1, 0),
(20520, 24690, 2, 0, 1, 1, 0);

-- and now the spawn in the same place of any prision
delete from creature_spawns where entry=20520;
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3973.05','2430.32','114.278','-1.69297');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3959.07','2429.8','114.278','-2.11185');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3947.17','2443.18','114.073','-2.67035');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3959.3','2443.07','114.278','-1.58825');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3972.35','2443.57','114.279','-2.42601');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3958.81','2457.11','114.278','-2.89725');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3719.2','2446.39','103.982','2.04204');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3718.79','2424.25','103.927','-3.05433');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3726.53','2440.4','103.981','0.558505');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3718.81','2435.08','103.93','2.79253');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3725.59','2428.65','103.501','1.50098');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3726.86','2450.14','103.98','1.53589');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3735.94','2435.4','104.003','-1.06465');
insert into `creature_spawns` (`Entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) values('20520','530','3736.05','2445.98','103.681','1.8675');

/* SEASON 4 FIX */
-- complete season 4 vendor table redo by Maestro

-- first delete statement to avoid duplicate entries


DELETE FROM `vendors` WHERE `Entry` = '25176';
DELETE FROM `vendors` WHERE `Entry` = '25177';
DELETE FROM `vendors` WHERE `Entry` = '25179';
DELETE FROM `vendors` WHERE `Entry` = '26352';
DELETE FROM `vendors` WHERE `Entry` = '26378';
DELETE FROM `vendors` WHERE `Entry` = '27668';
DELETE FROM `vendors` WHERE `Entry` = '27721';
DELETE FROM `vendors` WHERE `Entry` = '27722';



-- inserting the new vendor table for season 4

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25176, 38550, 1, 0, 0, 2388);





INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25177, 38550, 1, 0, 0, 2388);




INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 30486, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 30487, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 30488, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 30489, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 30490, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31958, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31959, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31960, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31961, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31962, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31963, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31964, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31965, 1, 0, 0, 2239);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31966, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31967, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31968, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31969, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31971, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31972, 1, 0, 0, 22);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31973, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31974, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31975, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31976, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31977, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31978, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31979, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31980, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31981, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31982, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31983, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31984, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31985, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31986, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31987, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31988, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31989, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31990, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31991, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31992, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31993, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31995, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31996, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31997, 1, 0, 0, 22);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31998, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 31999, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32000, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32001, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32002, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32003, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32004, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32005, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32006, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32007, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32008, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32009, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32010, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32011, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32012, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32013, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32014, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32015, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32016, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32017, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32018, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32019, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32020, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32021, 1, 0, 0, 21);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32022, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32023, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32024, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32025, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32026, 1, 0, 0, 2239);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32027, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32028, 1, 0, 0, 2239);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32029, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32030, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32031, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32032, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32033, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32034, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32035, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32036, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32037, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32038, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32039, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32040, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32041, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32042, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32043, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32044, 1, 0, 0, 2239);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32045, 1, 0, 0, 2242);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32046, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32047, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32048, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32049, 1, 0, 0, 2281);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32050, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32051, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32052, 1, 0, 0, 2239);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32053, 1, 0, 0, 2238);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32054, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32055, 1, 0, 0, 2237);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32056, 1, 0, 0, 2277);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32057, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32059, 1, 0, 0, 2278);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32060, 1, 0, 0, 2279);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32961, 1, 0, 0, 2240);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32962, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32963, 1, 0, 0, 2238);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 32964, 1, 0, 0, 2238);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33076, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33077, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33078, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33309, 1, 0, 0, 2242);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33937, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33940, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33943, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33946, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33949, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 33952, 1, 0, 0, 2241);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (25179, 38550, 1, 0, 0, 2388);




INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26352, 38550, 1, 0, 0, 2388);




INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (26378, 36737, 1, 0, 0, 2375);




INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27668, 38550, 1, 0, 0, 2388);


DELETE FROM `vendors` WHERE `Entry` = '27721';

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27721, 38550, 1, 0, 0, 2388);



INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34985, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34986, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34987, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34988, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34989, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34990, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34991, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34992, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34993, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34994, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34995, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34996, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34997, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34998, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 34999, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35000, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35001, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35002, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35003, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35004, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35005, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35006, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35007, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35008, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35009, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35010, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35011, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35012, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35013, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35014, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35015, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35016, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35017, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35018, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35019, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35020, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35021, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35022, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35023, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35024, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35025, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35026, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35027, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35028, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35029, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35030, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35031, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35032, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35033, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35034, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35035, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35036, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35037, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35038, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35039, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35040, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35041, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35042, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35043, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35044, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35045, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35046, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35047, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35048, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35049, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35050, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35051, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35052, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35053, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35054, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35055, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35056, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35057, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35058, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35059, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35060, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35061, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35062, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35063, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35064, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35065, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35066, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35067, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35068, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35069, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35070, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35071, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35072, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35073, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35074, 1, 0, 0, 2283);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35075, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35076, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35077, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35078, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35079, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35080, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35081, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35082, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35083, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35084, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35085, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35086, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35087, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35088, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35089, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35090, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35091, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35092, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35093, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35094, 1, 0, 0, 2364);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35095, 1, 0, 0, 2363);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35096, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35097, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35098, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35099, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35100, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35101, 1, 0, 0, 2362);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35102, 1, 0, 0, 2361);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35103, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35104, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35105, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35106, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35107, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35108, 1, 0, 0, 1758);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35109, 1, 0, 0, 2360);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35110, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35111, 1, 0, 0, 2286);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35112, 1, 0, 0, 2365);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35113, 1, 0, 0, 2366);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35114, 1, 0, 0, 2359);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 35115, 1, 0, 0, 2337);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 36737, 1, 0, 0, 2375);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38545, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38546, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38547, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38548, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38549, 1, 0, 0, 2388);

INSERT INTO vendors
  (entry, item, amount, max_amount, inctime, extended_cost)
VALUES
  (27722, 38550, 1, 0, 0, 2388);



-- Okay now spawn the vendors
-- lets delete spawns first you never know

DELETE FROM creature_spawns WHERE entry=25176;
DELETE FROM creature_spawns WHERE entry=25177;
DELETE FROM creature_spawns WHERE entry=25179;
DELETE FROM creature_spawns WHERE entry=26352;
DELETE FROM creature_spawns WHERE entry=26378;
DELETE FROM creature_spawns WHERE entry=27668;
DELETE FROM creature_spawns WHERE entry=27721;
DELETE FROM creature_spawns WHERE entry=27722;

-- time to spawn the npcs now

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate)
VALUES
  (25176, 530, -2158.66, 6636.57, 0.299064, 1.06957, 0, 22398, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (25177, 1, -7119.02, -3772.81, 8.90593, 0.921374, 0, 22438, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380825);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (25179, 530, 2893.14, 5982.34, 2.53936, 0.980167, 0, 22439, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380823);


INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (26352, 530, 3075.18, 3633.45, 143.779, 2.3829, 0, 23768, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380824);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (26378, 1, -7120.56, -3773.93, 9.13712, 0.750492, 0, 22438, 35, 512, 16843008, 0, 4097, 0, 0, 0, 0, 0, 0, 358627);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (27668, 530, -1965.61, 5172.92, -38.2435, 0.376958, 0, 24735, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380820);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (27721, 530, -1878.16, 5649.38, 127.459, 1.36273, 0, 24764, 35, 512, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380822);

INSERT INTO creature_spawns
  (entry, map, position_x, position_y, position_z, orientation, movetype, displayid, faction, flags, bytes0, bytes1, bytes2, emote_state, npc_respawn_link, channel_spell, channel_target_sqlid, channel_target_sqlid_creature, standstate, id)
VALUES
  (27722, 530, -2113.38, 5385.3, 53.8081, 2.79372, 0, 24764, 35, 512, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1380821);

/* Quest FIX: Investigating Amani Catacombes */
UPDATE `quests` SET `ReqKillMobOrGOId1`='181148' WHERE (`entry`='9193');

  
/* DONE! */
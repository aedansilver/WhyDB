UPDATE db_version SET revision = 62, changeset = 81 WHERE db_name LIKE 'WhyDB';


/*No longer sold from vendors (since patch 3.2)*/
DELETE FROM vendors where item = 36933;
DELETE FROM vendors where item = 36930;
DELETE FROM vendors where item = 36927;
DELETE FROM vendors where item = 36921;
DELETE FROM vendors where item = 36918;
DELETE FROM vendors where item = 36924;

/*Added to vendors in 3.2*/
REPLACE INTO `vendors` VALUES (31580, 36931, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31580, 36928, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31580, 36934, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31580, 36919, 1, 0, 0, 2484);

REPLACE INTO `vendors` VALUES (32172, 36931, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (32172, 36928, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (32172, 36934, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (32172, 36919, 1, 0, 0, 2484);

REPLACE INTO `vendors` VALUES (31582, 36931, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31582, 36928, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31582, 36934, 1, 0, 0, 2484);
REPLACE INTO `vendors` VALUES (31582, 36919, 1, 0, 0, 2484);


/*Move to Heirloom vendor*/
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42944;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42943;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42950;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42946;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48677;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48716;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42948;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42945;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48691;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42985;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42991;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48689;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42947;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42992;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42951;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48683;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48685;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42949;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48687;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42984;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 48718;
UPDATE `vendors` SET entry = 35508 WHERE entry = 31582 AND item = 42952;


/*New recall ports*/
REPLACE INTO recall values (956, 'Ulduar', 571, 9012.471, -1110.2506, 1165.2766, 0.022);

REPLACE INTO recall values (957, 'K3', 571, 6122.066, -1060, 402.62, 4.776);

/*Added missing items*/
REPLACE INTO `items` VALUES ('47146','4','0','-1','Chalice of Searing Light','61377','4','8','0','302495','75623','23','-1','-1','258','80','0','0','0','0','0','0','0','0','1','0','5','45','100','7','65','5','65','6','57','32','57','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','100','0','1','0','-1','0','-1','0','1','0','-1','0','-1','0','0','0','-1','0','-1','0','0','0','0','0','0','0','0','0','0','0','0','1','','0','0','0','0','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','375','0','0','0','0');

/*Missing Npcs*/

REPLACE INTO `creature_names` (`name`, `subname`, `info_str`, `type`, `family`, `rank`, `male_displayid`, `female_displayid`, `male_displayid2`, `female_displayid2`, `civilian`, `leader`, `entry`) VALUES ('Enchanter Erodin', 'Heirloom Vendor', '', '0', '0', '0', '29829', '0', '0', '0', '0', NULL, '35508');
REPLACE INTO `creature_proto` (`minlevel`, `maxlevel`, `faction`, `minhealth`, `maxhealth`, `mana`, `scale`, `npcflags`, `attacktime`, `attacktype`, `mindamage`, `maxdamage`, `rangedattacktime`, `rangedmindamage`, `rangedmaxdamage`, `respawntime`, `armor`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `combat_reach`, `bounding_radius`, `auras`, `boss`, `money`, `invisibility_type`, `death_state`, `walk_speed`, `run_speed`, `fly_speed`, `IsTrainingDummy`, `entry`) VALUES ('80', '80', '1714', '10080', '10080', '8814', '1', '128', '1500', '-1', '0', '0', '0', '0', '0', '36000', '1', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '2.5', '8', '14', '0', '35508');
REPLACE INTO `creature_names` (`name`, `subname`, `info_str`, `type`, `family`, `rank`, `male_displayid`, `female_displayid`, `male_displayid2`, `female_displayid2`, `civilian`, `leader`, `entry`) VALUES ('Dark Essence', '', '', '0', '0', '0', '29270', '0', '0', '0', '0', NULL, '34567');
REPLACE INTO `creature_proto` (`minlevel`, `maxlevel`, `faction`, `minhealth`, `maxhealth`, `mana`, `scale`, `npcflags`, `attacktime`, `attacktype`, `mindamage`, `maxdamage`, `rangedattacktime`, `rangedmindamage`, `rangedmaxdamage`, `respawntime`, `armor`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `combat_reach`, `bounding_radius`, `auras`, `boss`, `money`, `invisibility_type`, `death_state`, `walk_speed`, `run_speed`, `fly_speed`, `IsTrainingDummy`, `entry`) VALUES ('83', '83', '35', '139450', '139450', '4258', '1', '0', '1500', '-1', '0', '0', '0', '0', '0', '36000', '1', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '2.5', '8', '14', '0', '34567');
UPDATE `creature_names` SET `entry` = '34567', `name` = 'Dark Essence', `subname` = '', `info_str` = '', `QuestItem1` = '0', `QuestItem2` = '0', `QuestItem3` = '0', `QuestItem4` = '0', `QuestItem5` = '0', `QuestItem6` = '0', `Flags1` = '0', `type` = '0', `family` = '0', `rank` = '0', `unk4` = '0', `spelldataid` = NULL, `male_displayid` = '29270', `female_displayid` = '0', `male_displayid2` = '0', `female_displayid2` = '0', `unknown_float1` = '1', `unknown_float2` = '1', `civilian` = '0', `leader` = NULL WHERE `entry` = 34567 LIMIT 1;
UPDATE `creature_proto` SET `entry` = '34567', `minlevel` = '83', `maxlevel` = '83', `faction` = '35', `minhealth` = '139450', `maxhealth` = '139450', `mana` = '4258', `scale` = '1', `npcflags` = '0', `attacktime` = '1500', `attacktype` = '-1', `mindamage` = '0', `maxdamage` = '0', `can_ranged` = '0', `rangedattacktime` = '0', `rangedmindamage` = '0', `rangedmaxdamage` = '0', `respawntime` = '36000', `armor` = '1', `resistance1` = '0', `resistance2` = '0', `resistance3` = '0', `resistance4` = '0', `resistance5` = '0', `resistance6` = '0', `combat_reach` = '1', `bounding_radius` = '0', `auras` = '0', `boss` = '0', `money` = '0', `invisibility_type` = '0', `death_state` = '0', `walk_speed` = '2.5', `run_speed` = '8', `fly_speed` = '14', `extra_a9_flags` = '0', `spell1` = '0', `spell2` = '0', `spell3` = '0', `spell4` = '0', `spell_flags` = '0', `modImmunities` = '0', `isTrainingDummy` = '0', `guardtype` = '0' WHERE `entry` = 34567 LIMIT 1;
REPLACE INTO `creature_names` (`name`, `subname`, `info_str`, `type`, `family`, `rank`, `male_displayid`, `female_displayid`, `male_displayid2`, `female_displayid2`, `civilian`, `leader`, `entry`) VALUES ('Highlord Tirion Fordring', '', '', '0', '0', '3', '29270', '0', '0', '0', '0', NULL, '36095');
REPLACE INTO `creature_proto` (`minlevel`, `maxlevel`, `faction`, `minhealth`, `maxhealth`, `mana`, `scale`, `npcflags`, `attacktime`, `attacktype`, `mindamage`, `maxdamage`, `rangedattacktime`, `rangedmindamage`, `rangedmaxdamage`, `respawntime`, `armor`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `combat_reach`, `bounding_radius`, `auras`, `boss`, `money`, `invisibility_type`, `death_state`, `walk_speed`, `run_speed`, `fly_speed`, `IsTrainingDummy`, `entry`) VALUES ('83', '83', '1106', '13945000', '13945000', '4258000', '1', '0', '1500', '-1', '0', '0', '0', '0', '0', '36000', '1', '0', '0', '0', '0', '0', '0', '1', '0', '0', '1', '0', '0', '0', '2.5', '8', '14', '0', '36095');
UPDATE `creature_names` SET `entry` = '36095', `name` = 'Highlord Tirion Fordring', `subname` = '', `info_str` = '', `QuestItem1` = '0', `QuestItem2` = '0', `QuestItem3` = '0', `QuestItem4` = '0', `QuestItem5` = '0', `QuestItem6` = '0', `Flags1` = '0', `type` = '0', `family` = '0', `rank` = '3', `unk4` = '0', `spelldataid` = NULL, `male_displayid` = '29270', `female_displayid` = '0', `male_displayid2` = '0', `female_displayid2` = '0', `unknown_float1` = '1', `unknown_float2` = '1', `civilian` = '0', `leader` = NULL WHERE `entry` = 36095 LIMIT 1;
UPDATE `creature_proto` SET `entry` = '36095', `minlevel` = '83', `maxlevel` = '83', `faction` = '1106', `minhealth` = '13945000', `maxhealth` = '13945000', `mana` = '4258000', `scale` = '1', `npcflags` = '0', `attacktime` = '1500', `attacktype` = '-1', `mindamage` = '0', `maxdamage` = '0', `can_ranged` = '0', `rangedattacktime` = '0', `rangedmindamage` = '0', `rangedmaxdamage` = '0', `respawntime` = '36000', `armor` = '1', `resistance1` = '0', `resistance2` = '0', `resistance3` = '0', `resistance4` = '0', `resistance5` = '0', `resistance6` = '0', `combat_reach` = '1', `bounding_radius` = '0', `auras` = '0', `boss` = '1', `money` = '0', `invisibility_type` = '0', `death_state` = '0', `walk_speed` = '2.5', `run_speed` = '8', `fly_speed` = '14', `extra_a9_flags` = '0', `spell1` = '0', `spell2` = '0', `spell3` = '0', `spell4` = '0', `spell_flags` = '0', `modImmunities` = '0', `isTrainingDummy` = '0', `guardtype` = '0' WHERE `entry` = 36095 LIMIT 1;
UPDATE `creature_names` SET `entry` = '35495', `name` = 'Magistrix Vesara', `subname` = 'Emblem of Triumph Quartermaster', `info_str` = '', `QuestItem1` = '0', `QuestItem2` = '0', `QuestItem3` = '0', `QuestItem4` = '0', `QuestItem5` = '0', `QuestItem6` = '0', `Flags1` = '0', `type` = '0', `family` = '0', `rank` = '0', `unk4` = '0', `spelldataid` = NULL, `male_displayid` = '29831', `female_displayid` = '0', `male_displayid2` = '0', `female_displayid2` = '0', `unknown_float1` = '1', `unknown_float2` = '1', `civilian` = '0', `leader` = NULL WHERE `entry` = 35495 LIMIT 1;
UPDATE `creature_proto` SET `entry` = '35495', `minlevel` = '80', `maxlevel` = '80', `faction` = '1124', `minhealth` = '10080', `maxhealth` = '10080', `mana` = '8814', `scale` = '1', `npcflags` = '128', `attacktime` = '1500', `attacktype` = '-1', `mindamage` = '0', `maxdamage` = '0', `can_ranged` = '0', `rangedattacktime` = '0', `rangedmindamage` = '0', `rangedmaxdamage` = '0', `respawntime` = '36000', `armor` = '1', `resistance1` = '0', `resistance2` = '0', `resistance3` = '0', `resistance4` = '0', `resistance5` = '0', `resistance6` = '0', `combat_reach` = '1', `bounding_radius` = '0', `auras` = '0', `boss` = '0', `money` = '0', `invisibility_type` = '0', `death_state` = '0', `walk_speed` = '2.5', `run_speed` = '8', `fly_speed` = '14', `extra_a9_flags` = '0', `spell1` = '0', `spell2` = '0', `spell3` = '0', `spell4` = '0', `spell_flags` = '0', `modImmunities` = '0', `isTrainingDummy` = '0', `guardtype` = '0' WHERE `entry` = 35495 LIMIT 1;

/*Creature Fixes*/
UPDATE `creature_proto` SET mana = 3994, faction = '12' WHERE 'entry' = '33236';
UPDATE `creature_proto` SET mana = 3994, faction = '12' WHERE 'entry' = '33572';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34234';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33237';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33113';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34069';
UPDATE `creature_proto` SET faction = '12', mana = '41690' WHERE entry = '34086';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34085';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33121';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33186';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33293';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '33344';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34267';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34271';
UPDATE `creature_proto` SET faction = '35' WHERE entry= '34816';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34269';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34273';
UPDATE `creature_proto` SET faction = '12' WHERE entry = '34164';
UPDATE creature_proto SET mana = 2129000 WHERE entry = 16128;
UPDATE creature_names SET rank = 3 WHERE entry = 16128;

/*Object Fixes*/
UPDATE `gameobject_names` SET Name = 'Pile of Candy' WHERE entry = '195147';
-- UPDATE `trainer_defs` SET trainer_type = '0' WHERE '3'; <-- WTF is THAT?

/*Spawns for new vendors*/

REPLACE INTO `creature_spawns` VALUES (135141, 31581, 571, 5939.161, 510.1, 650.1784, 2.171, 0, 27560, 2123, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
REPLACE INTO `creature_spawns` VALUES (135142, 35495, 571, 5935.96, 507.6, 650.18, 2.262, 0, 29831, 2123, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
UPDATE `creature_spawns` SET entry = 33964, displayid = 28987 WHERE id = 104241;
REPLACE INTO `creature_spawns` VALUES (135143, 35508, 571, 5946.1333, 512, 650.1796, 2.8973, 0, 29829, 2123, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
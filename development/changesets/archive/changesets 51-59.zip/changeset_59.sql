/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Hi all whydb developers, users and other supporters!
 * Well after a long time of waiting it finally comes to the true moment.
 * 
 * WhyDB Finaly presents WhyDB v2.0!
 *
 * We wish you a good and happy new year!
 *		WhyDB - CYBERDEViL, AgmAr, MesoX, Lich, Sadikum
 *
 *
 * Changelog:
 * - Applied the Wotlk test patch to the db ;)
 * - Spawned Dalaran
 * - Spawned Borean Tundra
 * - Spawned Winter Grasp
 * - Spawned Sholazar Basin
 * - Spawned Howling Fjod
 * - Spawned Dragonblight
 * - Spawned Grizzly Hills
 * - Spawned Zul'Drak
 * - Spawned Ebon Hold
 * - Added new vendor templates
 * - Added new creature_quest_starters|finishers
 * - Added tons of new creature_proto
 * - Added tons of new quests
 * - Fixed tons of little bugs, to many to name all.
 * - Why did loot_creatures.ffa_loot have int(3) if it only is used for boolean values? Changed to tinyint(1)
 * 
 * Sorry guys but we did not create a changeset 'cause the patch was to big for it, so changes are made in ascent_world directory.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

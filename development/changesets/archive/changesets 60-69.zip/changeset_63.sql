ALTER TABLE `playercreateinfo` ADD COLUMN `introid` INT UNSIGNED DEFAULT '0' NOT NULL AFTER `maxdmg`;
UPDATE `playercreateinfo` SET `introid` = '81' WHERE `race` = '1';
UPDATE `playercreateinfo` SET `introid` = '21' WHERE `race` = '2';
UPDATE `playercreateinfo` SET `introid` = '41' WHERE `race` = '3';
UPDATE `playercreateinfo` SET `introid` = '61' WHERE `race` = '4';
UPDATE `playercreateinfo` SET `introid` = '2' WHERE `race` = '5';
UPDATE `playercreateinfo` SET `introid` = '141' WHERE `race` = '6';
UPDATE `playercreateinfo` SET `introid` = '101' WHERE `race` = '7';
UPDATE `playercreateinfo` SET `introid` = '121' WHERE `race` = '8';
UPDATE `playercreateinfo` SET `introid` = '162' WHERE `race` = '10';
UPDATE `playercreateinfo` SET `introid` = '163' WHERE `race` = '11';
UPDATE `playercreateinfo` SET `introid` = '165' WHERE `class` = '6';


alter table `playercreateinfo` add column taximask text(255);

-- human
update `playercreateinfo` set taximask="2" where race=1;
-- orc (2), troll (8)
update `playercreateinfo` set taximask="4194304" where race in (2, 8);
-- dwarf (3), gnome (7)
update `playercreateinfo` set taximask="32" where race in (3, 7);
-- night elf
update `playercreateinfo` set taximask="100663296" where race=4;
-- undead
update `playercreateinfo` set taximask="1024" where race=5;
-- tauren
update `playercreateinfo` set taximask="2097152" where race=6;
-- blood elf
update `playercreateinfo` set taximask="0 0 131072" where race=10;
-- draenei
update `playercreateinfo` set taximask="0 0 536870912" where race=11;

-- death knight
update `playercreateinfo` set taximask="4294967295 4093640703 830406655 0 33570816 1310944 3250593812 73752 896 67111952" where class=6;


-- Firemaul of Destruction
UPDATE `items` SET `itemstatscount` = '3',
`stat_type1` = '4',
`stat_value1` = '31',
`stat_type2` = '7',
`stat_value2` = '50',
`stat_type3` = '35',
`stat_value3` = '40',
`delay` = '3700' WHERE `items`.`entry` =27524 LIMIT 1 ; 

-- Lightsworn Hammer
UPDATE `items` SET `stat_value1` = '7',
`stat_type2` = '12',
`stat_value2` = '5',
`stat_type3` = '11',
`delay` = '1800',
`spellid_1` = '33273',
`spellid_2` = '18378' WHERE `items`.`entry` =27538 LIMIT 1 ;

-- Demonblood Eviscerator
UPDATE `items` SET `stat_type1` = '7',
`stat_value1` = '16',
`stat_type2` = '34',
`stat_value2` = '17',
`delay` = '2600',
`spellid_1` = '9335' WHERE `items`.`entry` =27533 LIMIT 1 ; 

UPDATE items SET `allowableclass` = '-1' WHERE `allowableclass` = '0';

UPDATE items SET `allowablerace` = '-1' WHERE `allowablerace` = '0'; 
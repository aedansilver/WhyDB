/* DB_VERSION table */

DROP TABLE IF EXISTS `db_version`;
CREATE TABLE `db_version` (
  `db_name` varchar(255) collate latin1_general_ci NOT NULL COMMENT 'Name of the database',
  `revision` int(11) unsigned NOT NULL default '0' COMMENT 'svn revision number',
  `changeset` int(11) unsigned NOT NULL default '0' COMMENT 'changeset number',
  KEY `db_name` (`db_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Vypisuji data pro tabulku `db_version`
-- 

INSERT INTO `db_version` VALUES ('WhyDB', 252, 58);

/* FOR DEVS - this please add to every changeset with new numbers for info ;) */

UPDATE `db_version` SET revision ='252', changeset = '58' WHERE db_name LIKE 'WhyDB';
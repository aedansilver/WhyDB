UPDATE db_version SET revision = 12, changeset = 65 WHERE db_name LIKE 'WhyDB';

-- delete the existing spawns
DELETE FROM creature_spawns WHERE entry = "6491";


-- spawn the new spirit healers
INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9115, 423, 96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2403.43, 3995.29, 99.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2433.44, 3835.28, 94.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2479.84, 3695.68, 106.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2519.66, 3538.7, 120.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2449.93, 3377.49, 115.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2511.98, 3275.15, 99.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2570.5, 3135.96, 107.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   ( 6491, 530, 2695.05, 2940.24, 94.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2815.3, 2830.89, 76.02, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2846.52, 2955.54, 113.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2943.66, 3056.64, 112.72, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3022.79, 3163.7, 118.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3188.37, 3257.08, 88.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3271.49, 3366.92, 105.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3399.31, 3400.41, 101.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3520.2, 3511.7, 125.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3640.77, 3522.84, 104.12, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3586.96, 3717.31, 115.59, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3578.56, 3957.1, 118, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3491.41, 4127.39, 119.84, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2117.21, 1807.68, 1171.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2113.42, 1326.88, 1153.99, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2213.83, 1328.19, 1178.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2173.64, 1534.45, 1129.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2174.9, 1594.51, 1126.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2226.6, 1692.81, 1161.85, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2213.18, 1469.54, 1175.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2111.42, 1441.82, 1163.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2121.79, 1670.5, 1169.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1692.78, 1672.57, 1225.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1724.51, 1405.74, 1208.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1808.19, 1726.82, 1206.02, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1796.22, 1341.52, 1188.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2477.41, 4151.27, 113.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1918.94, 1766.3, 1194.12, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1914.77, 1381.5, 1175.39, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2057.31, 1848.26, 1192.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2047.89, 1324.84, 1170.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2227.6, 1819.58, 1151.61, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2253.47, 1298.66, 1188.84, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2368.35, 1800.79, 1166.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2353.73, 1336.66, 1192.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2541.25, 1787.24, 1187.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2495.96, 1402.39, 1204.59, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2603.99, 1695.96, 1229.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2626.9, 1457.85, 1225.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2355.3, 1683.71, 1173.15, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2351.79, 1455.4, 1185.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2012.4, 1455.41, 1172.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2013.06, 1677.24, 1182.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 1807.74, 1539.42, 1267.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 2523.69, 1596.6, 1269.35, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1616.9, 5077.05, 174.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1596.31, 4948.65, 169.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1606.36, 4792.58, 138.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1621.04, 4563.14, 137.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1771.94, 4585.16, 144.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1914.58, 4677.85, 133.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2102.66, 4685.08, 139.95, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2274.35, 4725.43, 159.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2251.08, 4907.94, 140.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2344.62, 5072.5, 268.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2653, 5100.26, 275.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2877.52, 4738.91, 278.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3323.6, 4503.88, 152.41, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3455.31, 4468.35, 154.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3731.12, 4738.45, 240.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3926.2, 4825.28, 264.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4086.35, 4849.9, 267.43, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4120.71, 5214.15, 264.99, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4153.55, 5508.92, 272.11, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4095.11, 5811.89, 259.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3995.33, 6092.06, 262.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3656.61, 6208.11, 272.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3482.78, 6487.13, 134.43, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3839.15, 6586.81, 135.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3797.19, 6900.24, 142.43, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3753.24, 7118.03, 141.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3432.89, 7312.38, 138.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3199.99, 7264.96, 146.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2818.31, 7269.72, 364.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2356.31, 7345.09, 363.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1933, 7389.18, 364.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4408.89, 2328.78, 31.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4541.32, 2281.76, 17.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4568.14, 2023.8, 90.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4618.17, 1850.61, 153.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4791.52, 1082.18, -8.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4445.43, 863.56, 6.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4507.6, 553.55, 124.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4445.81, 224.84, 93.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4231.62, 58.63, 7.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4084.62, 120.51, 63.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2997.38, 207.58, 3.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3004.49, 482.05, -15.4, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2752.54, 509.31, -25.64, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2721.16, 711.03, -21.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2753.67, 966.15, -3.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2597.45, 1040.72, 40.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2464.28, 1074.65, 33.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2459.08, 1277.57, 33.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2477.69, 1386.24, 47.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2652.66, 1484.21, 23.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3942.59, 3686.29, 286.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2218.9, 6017.35, 135.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1955.9, 6768.81, 164.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4022.99, 2048.58, 96.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2999.23, 2439.06, 62.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3032.44, 3594.28, 145.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4363.88, 3093.74, 132.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 337.13, 8616.87, 24.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 874.91, 7284.72, 23.02, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3562.41, 4666.44, -21.99, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -249.77, 1023.32, 54.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 700.09, 2207.99, 288.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2033.53, 8479.53, -0.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -856.21, 6600.06, 173.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1289.79, 9166.72, 218.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 0, 0, 0, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1876.5, 3700.5, -19.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2059, 3560.39, -74.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2047.74, 3278.56, -61.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2098.93, 3116.51, -51.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2205.61, 2968.3, -69.07, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2375.42, 2848.08, -69.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2648.27, 3020.65, -13.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4151.09, 3425.82, 293.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2650.24, 1666.66, 10.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2447.42, 1612.81, -27.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2319.13, 1749.94, -13.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2415.76, 1811.62, -1.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3965.06, 4128.62, 0.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4024.3, 4421.72, -50, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3904.3, 4591.4, -45.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3990.14, 4869.48, -107.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3886.29, 5149.57, -59.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3910.99, 5404.07, -35.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3801.34, 5618.75, -26.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3844.34, 5931.41, -25.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3898.57, 6147.65, -37.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3621.98, 6225.18, -18.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3379.58, 6206.48, -3.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3045.37, 6508.57, 99.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2962.33, 6796.88, -51.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2987.35, 7045.47, -54.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3244.7, 7079.02, -49.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3155.75, 7316.31, -25.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3122.56, 8079.49, -49.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2989.35, 8445.13, -36.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2984.12, 8700.11, -53.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2799.85, 8785.75, -42.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2619.46, 8953.7, -11.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2153.3, 9323.71, 52.43, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1933.72, 9343.67, 74.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -999.51, 9045.62, 91.59, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -697.57, 8881.73, 185.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 559, 4055.5, 2919.66, 13.61, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 66.3, 60.13, 6.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 1463.22, 16470.1, 66.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2540.15, 3866.65, 10.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1793.42, 4931.61, -22.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1654.37, 7938.99, -46.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1066.97, 8066.54, -39.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -160.43, 9053.54, 5.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 32.16, 9120.4, -17.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 223.55, 9132.74, -11.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 702.76, 8927.53, -2.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 381.31, 9113.74, -4.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 747.45, 8702.9, 6.11, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1104.4, 8781.98, -10.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1347.02, 8679.23, 6.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1838.93, 8496.51, -19.03, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1348.12, 8677.57, 6.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1706.28, 8407.81, -24.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1317.5, 8135.39, -2.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1398.58, 7763.03, 8.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1412.41, 8430.12, -4.68, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1394.98, 7756.5, 12.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1001.9, 5714.57, -9.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 781.71, 4987.82, -12.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1011.16, 5039.57, -26.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -212.45, 5579.67, 22.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1286.73, 7883.12, 10.22, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 562, 6238.93, 262.96, 0.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 211.32, 6200.03, 22.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 248.34, 7084.93, 36.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1510.36, 3281.81, -16.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1445.7, 3050.23, -16.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1497.4, 2657.17, -53.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1306.28, 2478.4, 56.81, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1278.37, 1381.71, 9.1, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -668.98, 1516.19, 18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -465.08, 1272.1, 12.39, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -827.57, 1194.34, 16.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -958.58, 803.91, 2.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -570.33, 675.79, -0.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -213.51, 730.68, -0.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 60.38, 725.16, 14.58, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 337.84, 853.22, 13.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 386.68, 1044.78, 26.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 298.67, 1225.23, -1.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 134.53, 1230.39, 2.4, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -92.83, 1350.91, -12.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 60.88, 1542.69, 17.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 274.6, 1674.63, -5.78, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 107.71, 1841.23, 21.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 354.62, 1952.75, 23.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 608.1, 1778.63, 104.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 851.69, 1688.06, 89.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 1148.44, 1798.14, 116.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 742.63, 2887.71, 8.9, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
  (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 582.86, 2954.06, 4.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 540.98, 3144.23, 8.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 540.31, 3932.88, 188.93, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 562, 6184.98, 236.01, 4.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 562, 6292.66, 288.58, 4.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 101.14, -184.93, 127.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 559, 4055.85, 2921.78, 50.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 559, 4085.45, 2866.83, 12.4, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 742.63, 2887.71, 8.9, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -695.88, 4118.21, 64.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 181.48, 4361.58, 116.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16223.8, 16278.6, 20.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16423, 16237, 71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2495.87, 6802.26, 21.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 559, 4027.6, 2972.78, 12.07, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 335.89, 7625.12, 22.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1978.47, -3655.89, 119.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1754.21, -11067.3, 76.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2020.59, -11983.5, 33.25, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3324.31, -12089.9, 28.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4312.78, -12441, 17.19, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 8709.46, -6671.76, 70.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 9407, -6847.67, 16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -803.01, 2702.59, 106.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 158.06, 2562.73, 75.78, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4123.14, -13660.1, 74.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 6730.49, -7936.89, 170.1, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 7015.23, -7300, 45.42, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 7694.18, -6730.11, 48.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 8936.56, -7439.9, 82.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7991.57, 1557.8, 4.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 10458.5, -6364.61, 39.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10606.8, 294.05, 31.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -6831.32, 891.44, 33.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2647.55, -4014.39, 105.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 713.71, 638.36, -10.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 1354.7, 1270.27, -11.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 772.76, 1213.11, 15.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 1211.52, 781.56, -82.71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 1201.87, 1163.13, -56.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 1016.59, 955.19, -42.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 834.73, 784.98, -57.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -1215.59, -2531.75, 21.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -831.88, -3518.52, 72.48, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 1313.9, 1310.74, -9.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 529, 684.01, 681.22, -12.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1236.89, -2411.99, 60.68, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9552.46, -1374.05, 51.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1780.11, 221.76, 59.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5165.52, -874.66, 507.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -981.92, -74.65, 20.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1177.78, -4464.24, 21.35, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4590.41, 1632.08, 93.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 536.5, -1085.72, 106.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 101.14, -184.93, 127.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1459.17, -1858.67, 124.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1035.27, -2104.28, 122.95, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -291, -4374, 107, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 489, 1029.14, 1387.49, 340.84, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 489, 1415.33, 1554.79, 343.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 489, 933.33, 1433.72, 345.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 489, 1523.81, 1481.76, 352.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, 643, 44, 69.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, -1496.07, -333.34, 101.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, -531.22, -405.23, 49.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, 73.42, -496.43, 48.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -634.64, -4296.03, 40.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, -1090.48, -253.31, 57.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, 676, -374, 30, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16619.5, 16577.5, 43.9, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16620.7, 16622.7, 21.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16614.8, 16663, 21.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -778, -4985, 19, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -6450.61, -1113.51, 308.02, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 5935.47, -1217.75, 383.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1392, -3701, 77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 7426, -2809, 464, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -3127.69, -3046.94, 33.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 4788.78, -6845, 89.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 908.32, -1520.29, 55.04, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, 873, -491.28, 96.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, -1437.67, -610.09, 51.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2942.76, -6037.13, 5.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 16310.3, 16268.9, 69.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1750.34, -669.79, 44.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16223.8, 16278.6, 20.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, 16310.3, 16268.9, 69.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2421.72, -2953.62, 123.47, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 6875.76, -4661.54, 701.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2055.74, -5020.95, 74.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 908.32, -1520.29, 55.04, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -3347.72, -856.71, 1.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 4291.28, 96.96, 43.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7205.56, -2436.67, -218.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 3806.54, -1600.29, 218.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (491, 0, 2604.52, -543.39, 89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 898.26, 434.53, 65.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -11542.6, -228.64, 27.84, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10846.6, -2949.49, 13.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2681.06, -4009.75, 107.85, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 323.51, -2227.2, 137.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -5530.28, -3459.28, -45.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4439.97, 370.15, 51.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4596.4, 3229.43, 8.99, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2348.67, 492.03, 33.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 37, -448.19, -1027.86, 430.72, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1081.4, -3478.68, 63.61, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -2517.75, -1972.64, 91.78, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7190.95, -3944.65, 9.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -3525.71, -4315.46, 7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 30, -157.41, 31.21, 77.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -732.8, -592.5, 22.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 8706, 965, 13.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -14285, 288.45, 32.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10567.8, -3377.2, 22.25, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9151.98, 410.94, 92.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9339.46, 171.41, 61.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -8935.33, -188.65, 80.42, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9403.25, -2037.69, 58.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -6805, -2287.19, 280.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5049.45, -809.7, 495.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5680.04, -518.92, 396.27, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -6164.23, 336.32, 399.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -1307.66, -3192.15, 37.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -18.68, -981.17, 55.84, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 516.19, 1589.81, 127.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1822.61, 214.67, 60.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1882.94, 1629.11, 94.42, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 10384.8, 811.53, 1317.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2633.41, -629.74, 107.58, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400020, 6491, 1, 9701.25, 945.62, 1291.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 10054.3, 2117.12, 1329.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -2175.19, -342.03, -5.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -6432.26, -278.29, 3.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 37, -661.53, -485.31, 385.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4656, -1765, -41, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -11110.4, -1833.24, 71.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 6739.19, 209.99, 23.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -2944.56, -153.22, 65.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1357.1, -4412.01, 28.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 233.46, -4793.73, 10.19, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -448.31, 2512.65, 93.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -592.6, -2523.49, 91.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -6289.91, -3493.11, 251.48, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -3289.12, -2435.99, 18.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5351.23, -2881.58, 340.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5687, -515, 398, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9194.31, -2313.26, 88.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10546.9, 1197.24, 31.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10774.3, -1189.67, 33.15, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2535.26, 4396.42, 103.32, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2710.52, 4440.32, 105.85, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2916.15, 4444.49, 111.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3069.1, 4357.14, 119.07, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3091.8, 4146.84, 126.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3221.17, 4069.1, 103.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3355.79, 4149.28, 137.78, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3980.61, 4262.21, 130.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3802.7, 4204.43, 108.91, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3766.71, 4008.23, 116.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3796.27, 3772.19, 100.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4049.61, 3692.78, 101.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4152.53, 3886.21, 121.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4235.16, 4080.62, 95.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4169.83, 4209.06, 118.71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3836.08, 3477.26, 75.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3994.95, 3538.27, 122.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4211.4, 3632, 124.11, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4395.24, 3708.62, 96.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4580.69, 3584, 94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4793.19, 3527.37, 102.16, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4903.71, 3323.86, 101.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4945.87, 3110.83, 98.22, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400385, 6491, 530, 5156.75, 2974.21, 75.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 5204.7, 2868.11, 54.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 5019.97, 2798.73, 52.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4885.18, 2663.13, 85.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4853.17, 2354.02, 101.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4680.81, 2287.48, 129.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4522.44, 2280.28, 136.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   ( `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4436.57, 2485.48, 90.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4448.3, 2658.15, 111.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4285.06, 2837.04, 100.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4136.62, 2699.33, 101.03, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3975.24, 2807.44, 115.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3931.79, 3020.67, 104.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3895.88, 3257.64, 120.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3629.36, 3095.11, 112.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3476.45, 3293.56, 94.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3348.41, 3172.06, 91.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3216.28, 2992.53, 124.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3022.81, 2892.91, 90.24, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2860.47, 2735.28, 86.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2863.8, 2537.41, 105.19, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2856.08, 2297.04, 98.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2834.86, 2040.24, 92.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2868.81, 1848.69, 96.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2895.75, 1708.09, 105.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3110.67, 1624.43, 112.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3276.02, 1726.59, 101.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3332.26, 1986.97, 94.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3315.85, 2185.52, 108.39, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3384.58, 2376.22, 73.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3492.84, 2570.84, 138.48, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3590.41, 2677.08, 134.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3740.94, 2696.99, 112.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3737.85, 2894.69, 100.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3862.95, 2554.46, 80.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3648.26, 2414.61, 75.9, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3546.97, 2219.76, 92.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3550.01, 2002.35, 92.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3509.69, 1762.49, 75.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3645.26, 1712.66, 106.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3681.18, 1558.56, 103.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3775.55, 1437.54, -152.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3969.01, 1336.41, -143.47, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4166.45, 1329.15, -149.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4199.54, 1484.24, -127.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4258.28, 1672.84, 113.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4362.23, 1927.16, 95.64, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4347.15, 2143.36, 116.93, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4246.96, 2450.75, 91.3, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 4117.15, 2332.29, 103.11, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3975.8, 2437.47, 114.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2501.34, 1983.39, 84.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2573.35, 2127.1, 98.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2648.16, 2353.63, 93.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2659.25, 2547.14, 110.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2587.89, 2711.6, 110.04, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2473.63, 2964.98, 106.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400442, 6491, 530, 2209.18, 2901.68, 93.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2164.32, 2667.39, 78.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2078.21, 2405.5, 65.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2079.82, 2227.04, 67.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2240.18, 2067.8, 61.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 552.19, 1995.15, 103.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3065, 5426.42, 148.39, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3872.66, 5514.41, 271.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2296.35, 7023.23, 364.12, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2312.27, 5083.93, 272.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 0, 0, 0, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 101.14, -184.93, 127.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 2980.19, 1869.82, 143.61, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1272.42, 2436.85, 64.1, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -8159.51, -4628.7, -124.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3134.54, 719.48, -20.64, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -4117.03, 1058.26, 31.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400459, 6491, 530, 2362.67, 2327.41, 106.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400460, 6491, 530, 2011.39, 5575.79, 262.72, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400461, 6491, 530, 3522.84, 6821.62, 140.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`id`, `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (400462, 6491, 530, 3447.31, 4803.82, 260.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -382.91, 1117.42, 84.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1148.08, 5897.62, 188.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 572, 1277.87, 1744.9, 32.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 572, 1295.13, 1586.44, 32.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 572, 1285.81, 1667.9, 39.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -3524.27, 619.53, 4.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   ( 6491, 530, -3624.93, 600.01, 11.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 3621.87, 6519.53, 124.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4032.4, -3414.03, 38.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4632.79, -3129.43, 34.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1958.13, -3682.22, 171.91, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 728.27, -2992.27, 24.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 117.02, -3698.8, 0.68, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1191.77, -4115.08, 149.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2243.12, -4650.64, 218.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1923.72, -5986.35, 9.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 717.78, -5878.41, 287, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 205, -5944.01, 7.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 57.92, -4649.08, 283.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 668.02, -4931.68, 3.91, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1812.21, -5613.43, 220.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7351.04, -1315.89, -261.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -6160.06, -1142.43, -217.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 475.69, 1469.87, 9.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2729.91, 1286.64, 292.47, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7754.16, -4971.9, 5.91, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -8591.8, -3629.76, 13.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 5633.33, -4759.59, 777.71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 6499.59, -2384.34, 589.85, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5537.46, 2904.91, 517.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1839.77, -2149.68, 67.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -6867.31, -1539.84, 241.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -7100.9, -3488.39, 241.93, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -3973.53, -2014.49, 96.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3041.21, 4314.9, 29.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -1424.37, 4359.58, 241.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 12851.8, -6854.8, 11.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 12851.8, -6854.8, 11.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, 12851.8, -6854.8, 110.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, -10425.3, 7329.17, 313.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, -10431.2, 7377.98, 313.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 451, -10414.7, 7414.45, 312.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 530, -2433.64, 4660.97, 160.88, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 566, 0, 0, 0, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3100.18, -1983.4, 83.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3534.13, -2882.06, 204.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4352.78, -4247.99, 162.32, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4117.91, -4816.41, 76.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3967.28, -2316.64, 213.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2933.64, -2836.78, 73.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4323.39, -3606.85, 248, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4604.76, -976.65, 169.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3667.91, -1044.36, 130.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3218.74, -700.37, 167.48, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3843.01, 1425.52, 90.64, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3498.38, 2100.42, 69.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2772.18, 1042.4, 25.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3599.17, 2846.07, 70.95, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3538.17, 275.51, 45.61, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4812.89, 1022.49, 144.81, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4466.17, 1257.02, 140.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2842, 5973.16, 114.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2007.96, 5936.55, 37.4, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3621.88, 6805.54, 171.71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3559.93, 5818.79, 128.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4223.44, 5335.88, 30.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4514.81, 5661.56, 82.03, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3041.14, 3843.49, 3.76, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3576.16, 4087.61, 22.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2842.96, 6655.17, 36.41, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 2478.59, 5289.41, 32.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 791.43, -419.45, 136.57, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5537.57, 2905.04, 517.72, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5104.35, 2302.23, 368.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5101.04, 3461.45, 368.49, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5031.51, 3710.43, 372.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5140.35, 2182.01, 390.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4317.97, 2407.42, 392.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4335.81, 3234.56, 390.25, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4826.36, 5467.17, -54.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1335.47, -4785.18, 188.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5620.52, 5840.97, -63.47, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5538.26, 4851.61, -196.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6246.95, 5164.34, -83.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6274.77, 4409.44, -68.9, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5519.07, 3593.28, -14.22, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1388.8, 203.36, 32.15, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1396.06, -288.04, 32.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1122.28, 4.42, 68.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 964.6, -189.78, 90.66, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1457.19, -53.71, 5.18, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1618.81, 31.28, 8.35, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5703.97, -2467.94, 287.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5557.91, -1615.61, 242.25, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5244.65, -2133.33, 244.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4939.81, -2958.49, 289.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5798.52, -3286.55, 363.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5522.76, -4101.73, 364.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6618.71, -4795.52, 450.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5849.21, 763.31, 641.05, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 609, 2364.42, -5771.32, 151.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 617, 1292.51, 792.05, 9.34, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 617, 1235.88, 771.08, 15.5, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 617, 1347.43, 813, 15.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 618, 763.56, -274, 3.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 618, 763.93, -295.01, 3.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 618, 762.91, -284.28, 28.28, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1623.7, -94.83, 12.35, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1617.17, 67.13, 8.06, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2366.63, -5774.42, 151.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 609, 1886.78, -5784.59, 102.86, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 609, 2116.19, -5286.94, 81.22, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -6115.09, -1339.45, -179.58, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -3769.47, -4883.16, 5.52, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1362.55, -5394.17, -28.37, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -8290.62, 1403.52, 4.73, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 1103.08, -4977.5, 32.32, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 981.54, 1309.67, 45.94, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1342.17, -5527.75, 10.09, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6351.79, 5643.56, 70.54, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5041.85, -642.72, 225.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6070.45, 85.97, 369.62, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7080.44, -141.22, 783.23, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 9021.61, -1166.62, 1058.8, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7915.03, -2453.76, 1137.96, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 8105.5, -996.58, 936.71, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7463.99, -3320.57, 897.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5882.89, 666.81, 169.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5597.15, -595.53, 191, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3421.2, -1280.93, 125.97, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 3793.73, 2064.34, 93.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 8188.08, 2859.48, 604.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7233.66, 2159.7, 564.7, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7886.05, 718.78, 519.2, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 4421.3, -1981.25, 158.17, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 607, 1232.39, -65.73, 70.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7825.23, -2023.12, 1225.4, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 8387.58, -214.28, 839.45, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6947, -545.41, 914.93, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 6422.35, -1184.35, 446.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5036.33, 4494.32, -93.33, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2359.22, -5661.06, 382.26, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7149.75, 3691.58, 817.85, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 7092.46, -1440.91, 922.64, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 1773.33, 768.81, 55.69, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 794.76, -422.39, 135.77, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 7766.53, -4100.77, 697.13, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 6619.88, -3542.4, 681.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 4460.24, -4287.7, 917.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 4320.15, -5574.72, 121.98, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 3203.82, -4947.18, 157.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1439.21, 1972.74, 85.74, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1783.51, 2857.27, 56.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1967.22, 1723.91, 61.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1553.23, 981.85, 90.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -481.84, 1221.74, 97.31, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2928.99, 380.25, 91.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 2291.3, -1731.71, 118.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1284.34, -298.9, 5.51, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 1698.13, 1043.75, 148.29, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   ( 6491, 1, 161.39, -1693.86, 93.55, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 790.06, -2541.63, 91.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1887.99, -3055.97, 91.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1480.13, -2143.87, 92.82, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, 271.84, -3313.76, 56.03, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -2725.16, -1115.49, 20.15, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -1171.5, -1129.94, 27.87, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -5361.55, -2363.09, -37.39, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -6115.81, -3849.17, -58.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -9044.9, -2721.88, 37.38, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7753.64, -3009.76, 42.1, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -5526.86, 1450.52, 23.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -4336.89, -383.39, 36.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -3332.47, 2276.89, 27.56, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7967.79, 784.5, -1.01, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 1, -7051.92, 1290.27, 5.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   ( `entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   ( 6491, 0, -1343.26, -2046.73, 70.67, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -898.73, -1473.56, 58.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 3118.51, -4804, 101.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 3339.8, -3229.78, 142.81, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2208.66, -2923.06, 107.93, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 2663.41, -1725.17, 123.89, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -577.41, 118.94, 53.75, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, 581.8, -3827.57, 119.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -192.39, -3043.9, 120.14, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -2953.3, -1758.1, 9.41, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -3979.8, -2848.51, 12.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -3343.1, -3424.86, 64.48, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -13325.5, 153.6, 17.63, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -12547.2, -586.24, 39.53, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -12001.2, 429.75, 2.95, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10839.2, -480.76, 42.46, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -11218.7, 1711.25, 39.03, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9980.25, 1758.08, 37.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -11806.6, -2962.69, 7.65, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10320.1, -4121.21, 22.36, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -10347.2, -2585.03, 23.6, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9473, -3009.03, 134.83, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -9564.74, -605.88, 58.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -7923.56, -1353.23, 134.08, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -7987.49, -2370.21, 123.92, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5382.65, 36.67, 395.44, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5475.18, -1845.84, 399.79, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 0, -5329.98, -3779.33, 310.21, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO creature_spawns
   (`entry`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `movetype`, `displayid`, `faction`, `flags`, `bytes0`, `bytes1`, `bytes2`, `emote_state`, `npc_respawn_link`, `channel_spell`, `channel_target_sqlid`, `channel_target_sqlid_creature`, `standstate`, `mountdisplayid`, `slot1item`, `slot2item`, `slot3item`)
VALUES
   (6491, 571, 5463.84, 2840.68, 418.68, 3.14, 0, 5233, 35, 768, 16843008, 65536, 4097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- delete 8 dublicate spawns for npc 491
DELETE FROM creature_spawns where entry=491 and position_z=89;


-- Naxxramas loot
/* Anub'Rekhan */ 
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES 
 ('15956','40753','0','96','1','1','0'), 
 ('15956','39716','0','24','1','1','0'), 
 ('15956','39714','0','23','1','1','0'), 
 ('15956','39712','0','23','1','1','0'),
 ('15956','39717','0','23','1','1','0'), 
 ('15956','39704','0','19','1','1','0'), 
 ('15956','39720','0','19','1','1','0'), 
 ('15956','39722','0','19','1','1','0'), 
 ('15956','39719','0','19','1','1','0'), 
 ('15956','39721','0','19','1','1','0'), 
 ('15956','39701','0','19','1','1','0'), 
 ('15956','39706','0','18','1','1','0'), 
 ('15956','39718','0','18','1','1','0'), 
 ('15956','39703','0','18','1','1','0'), 
 ('15956','39702','0','18','1','1','0'), 
 ('15956','40074','0','11','1','1','0'), 
 ('15956','40074','0','11','1','1','0'), 
 ('15956','40080','0','11','1','1','0'), 
 ('15956','40071','0','11','1','1','0'), 
 ('15956','40075','0','11','1','1','0'), 
 ('15956','40069','0','10','1','1','0'), 
 ('15956','40107','0','10','1','1','0'), 
 ('15956','40065','0','10','1','1','0'), 
 ('15956','40064','0','10','1','1','0');
 
  /* Gothik the Harvester 25 man */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES 
 ('16060','40753','0','97','1','1','1'),
 ('16060','40335','0','19','1','1','0'),
 ('16060','40334','0','19','1','1','0'),
 ('16060','40329','0','19','1','1','0'),
 ('16060','40340','0','19','1','1','0'),
 ('16060','40342','0','19','1','1','0'),
 ('16060','40338','0','19','1','1','0'),
 ('16060','40336','0','19','1','1','0'),
 ('16060','40337','0','19','1','1','0'),
 ('16060','40341','0','19','1','1','0'),
 ('16060','40332','0','19','1','1','0'),
 ('16060','40328','0','19','1','1','0'),
 ('16060','40330','0','19','1','1','0'),
 ('16060','40331','0','18','1','1','0'),
 ('16060','40339','0','18','1','1','0'),
 ('16060','40333','0','18','1','1','0'),
 ('16060','40253','0','11','1','1','0'),
 ('16060','40254','0','11','1','1','0'),
 ('16060','40256','0','11','1','1','0'),
 ('16060','40258','0','11','1','1','0'),
 ('16060','40257','0','11','1','1','0'),
 ('16060','40250','0','10','1','1','0'),
 ('16060','40251','0','10','1','1','0'),
 ('16060','40252','0','10','1','1','0'),
 ('16060','40255','0','10','1','1','0');
 
  /* Grobbulus */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15931','40753','0','97','1','1','1'), 
 ('15931','40278','0','19','1','1','0'), 
 ('15931','40288','0','19','1','1','0'), 
 ('15931','40289','0','19','1','1','0'), 
 ('15931','40283','0','19','1','1','0'), 
 ('15931','40287','0','19','1','1','0'), 
 ('15931','40281','0','19','1','1','0'), 
 ('15931','40285','0','18','1','1','0'), 
 ('15931','40282','0','18','1','1','0'), 
 ('15931','40284','0','18','1','1','0'), 
 ('15931','40279','0','18','1','1','0'), 
 ('15931','40351','0','18','1','1','0'), 
 ('15931','40274','0','18','1','1','0'), 
 ('15931','40280','0','17','1','1','0'), 
 ('15931','40277','0','17','1','1','0'), 
 ('15931','40275','0','17','1','1','0'), 
 ('15931','40254','0','11','1','1','0'), 
 ('15931','40256','0','11','1','1','0'), 
 ('15931','40253','0','11','1','1','0'), 
 ('15931','40258','0','11','1','1','0'), 
 ('15931','40251','0','10','1','1','0'), 
 ('15931','40257','0','10','1','1','0'), 
 ('15931','40250','0','10','1','1','0'), 
 ('15931','40252','0','10','1','1','0'), 
 ('15931','40255','0','10','1','1','0');
 
  /* Instructor Razuvious */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('16061','40753','0','97','1','1','1'), 
 ('16061','40319','0','19','1','1','0'), 
 ('16061','40324','0','19','1','1','0'), 
 ('16061','40326','0','19','1','1','0'), 
 ('16061','40327','0','19','1','1','0'), 
 ('16061','40318','0','19','1','1','0'), 
 ('16061','40315','0','19','1','1','0'), 
 ('16061','40321','0','18','1','1','0'), 
 ('16061','40316','0','18','1','1','0'), 
 ('16061','40322','0','18','1','1','0'), 
 ('16061','40320','0','18','1','1','0'), 
 ('16061','40325','0','18','1','1','0'), 
 ('16061','40306','0','18','1','1','0'), 
 ('16061','40323','0','17','1','1','0'), 
 ('16061','40317','0','17','1','1','0'), 
 ('16061','40305','0','17','1','1','0'), 
 ('16061','40075','0','11','1','1','0'), 
 ('16061','40069','0','11','1','1','0'), 
 ('16061','40071','0','11','1','1','0'), 
 ('16061','40074','0','11','1','1','0'), 
 ('16061','40107','0','10','1','1','0'), 
 ('16061','40065','0','10','1','1','0'), 
 ('16061','40064','0','10','1','1','0'), 
 ('16061','40108','0','10','1','1','0'), 
 ('16061','40080','0','10','1','1','0');
 
  /* Loatheb */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('16011','40753','0','95','1','1','1'), 
 ('16011','40639','0','74','1','1','0'),
 ('16011','40638','0','57','1','1','0'),
 ('16011','40637','0','55','1','1','0'),
 ('16011','40249','0','19','1','1','0'),
 ('16011','40244','0','19','1','1','0'),
 ('16011','40247','0','19','1','1','0'),
 ('16011','40239','0','19','1','1','0'),
 ('16011','40242','0','19','1','1','0'),
 ('16011','40245','0','18','1','1','0'),
 ('16011','40240','0','18','1','1','0'),
 ('16011','40243','0','18','1','1','0'),
 ('16011','40241','0','18','1','1','0'),
 ('16011','40246','0','17','1','1','0');
 
  /* Noth the Plaguebringer */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15954','40753','0','95','1','1','1'), 
 ('15954','40193','0','19','1','1','0'),
 ('15954','40602','0','19','1','1','0'),
 ('15954','40198','0','19','1','1','0'),
 ('15954','40185','0','19','1','1','0'),
 ('15954','40200','0','19','1','1','0'),
 ('15954','40184','0','19','1','1','0'),
 ('15954','40197','0','18','1','1','0'),
 ('15954','40191','0','18','1','1','0'),
 ('15954','40189','0','18','1','1','0'),
 ('15954','40190','0','18','1','1','0'),
 ('15954','40192','0','18','1','1','0'),
 ('15954','40187','0','18','1','1','0'),
 ('15954','40196','0','18','1','1','0'),
 ('15954','40186','0','18','1','1','0'),
 ('15954','40188','0','11','1','1','0'),
 ('15954','40074','0','11','1','1','0'),
 ('15954','40065','0','11','1','1','0'),
 ('15954','40071','0','11','1','1','0'),
 ('15954','40075','0','11','1','1','0'),
 ('15954','40080','0','10','1','1','0'),
 ('15954','40069','0','10','1','1','0'),
 ('15954','40108','0','10','1','1','0'),
 ('15954','40064','0','10','1','1','0'),
 ('15954','40107','0','10','1','1','0');
 
  /* Sapphiron */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15989','40753','0','95','1','1','1'), 
 ('15989','44577','0','99','1','1','1'),
 ('15989','40379','0','20','1','1','0'),
 ('15989','40375','0','19','1','1','0'),
 ('15989','40382','0','19','1','1','0'),
 ('15989','40378','0','19','1','1','0'),
 ('15989','40368','0','19','1','1','0'),
 ('15989','40373','0','19','1','1','0'),
 ('15989','40367','0','19','1','1','0'),
 ('15989','40370','0','19','1','1','0'),
 ('15989','40374','0','19','1','1','0'),
 ('15989','40381','0','18','1','1','0'),
 ('15989','40366','0','18','1','1','0'),
 ('15989','40372','0','18','1','1','0'),
 ('15989','40365','0','18','1','1','0'),
 ('15989','40377','0','18','1','1','0'),
 ('15989','40369','0','18','1','1','0'),
 ('15989','40376','0','17','1','1','0'),
 ('15989','40371','0','17','1','1','0'),
 ('15989','40363','0','17','1','1','0'),
 ('15989','40380','0','17','1','1','0'),
 ('15989','40362','0','17','1','1','0');
 
  /* Gluth */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES 
 ('15932','40753','0','97','1','1','1'),
 ('15932','40639','0','25','1','1','0'),
 ('15932','40636','0','24','1','1','0'),
 ('15932','40627','0','24','1','1','0'),
 ('15932','40638','0','20','1','1','0'),
 ('15932','40635','0','20','1','1','0'),
 ('15932','40637','0','20','1','1','0'),
 ('15932','40626','0','2','1','1','0'),
 ('15932','40634','0','2','1','1','0'),
 ('15932','40625','0','2','1','1','0'),
 ('15932','39717','0','2','1','1','0'),
 ('15932','40185','0','2','1','1','0'),
 ('15932','40289','0','2','1','1','0'),
 ('15932','40274','0','2','1','1','0'),
 ('15932','40239','0','2','1','1','0'),
 ('15932','40193','0','2','1','1','0'),
 ('15932','40204','0','2','1','1','0'),
 ('15932','40203','0','2','1','1','0'),
 ('15932','40242','0','2','1','1','0'),
 ('15932','39763','0','2','1','1','0'),
 ('15932','40247','0','2','1','1','0'),
 ('15932','40346','0','2','1','1','0'),
 ('15932','39760','0','2','1','1','0'),
 ('15932','40602','0','2','1','1','0'),
 ('15932','40277','0','2','1','1','0'),
 ('15932','40332','0','2','1','1','0'),
 ('15932','39712','0','2','1','1','0'),
 ('15932','39765','0','2','1','1','0'),
 ('15932','40273','0','2','1','1','0'),
 ('15932','40350','0','2','1','1','0'),
 ('15932','39714','0','2','1','1','0'),
 ('15932','40281','0','2','1','1','0'),
 ('15932','40343','0','2','1','1','0'),
 ('15932','40334','0','2','1','1','0'),
 ('15932','39721','0','2','1','1','0'),
 ('15932','39761','0','2','1','1','0'),
 ('15932','39730','0','2','1','1','0'),
 ('15932','39720','0','2','1','1','0');
 
  /* Grand Widow Faerlina */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES 
 ('15953','40753','0','97','1','1','1'), 
 ('15953','39726','0','24','1','1','0'), 
 ('15953','39723','0','23','1','1','0'), 
 ('15953','39725','0','22','1','1','0'), 
 ('15953','39727','0','22','1','1','0'), 
 ('15953','39731','0','19','1','1','0'), 
 ('15953','39757','0','19','1','1','0'), 
 ('15953','39730','0','19','1','1','0'), 
 ('15953','39735','0','19','1','1','0'), 
 ('15953','39733','0','19','1','1','0'), 
 ('15953','39756','0','19','1','1','0'), 
 ('15953','39729','0','18','1','1','0'), 
 ('15953','39728','0','18','1','1','0'), 
 ('15953','39732','0','18','1','1','0'), 
 ('15953','39734','0','18','1','1','0'), 
 ('15953','40065','0','11','1','1','0'), 
 ('15953','40080','0','11','1','1','0'), 
 ('15953','40074','0','11','1','1','0'), 
 ('15953','40108','0','11','1','1','0'), 
 ('15953','40075','0','10','1','1','0'), 
 ('15953','40107','0','10','1','1','0'), 
 ('15953','40071','0','10','1','1','0'), 
 ('15953','40064','0','10','1','1','0'), 
 ('15953','40069','0','10','1','1','0');
 
  /* Heigan the Unclean */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15936','40753','0','97','1','1','1'), 
 ('15936','40207','0','19','1','1','0'), 
 ('15936','40235','0','19','1','1','0'), 
 ('15936','40237','0','19','1','1','0'), 
 ('15936','40236','0','19','1','1','0'), 
 ('15936','40206','0','19','1','1','0'), 
 ('15936','40204','0','19','1','1','0'), 
 ('15936','40209','0','18','1','1','0'), 
 ('15936','40208','0','18','1','1','0'), 
 ('15936','40210','0','18','1','1','0'), 
 ('15936','40238','0','18','1','1','0'), 
 ('15936','40234','0','18','1','1','0'), 
 ('15936','40203','0','18','1','1','0'), 
 ('15936','40233','0','17','1','1','0'), 
 ('15936','40201','0','17','1','1','0'), 
 ('15936','40205','0','17','1','1','0'), 
 ('15936','40250','0','11','1','1','0'), 
 ('15936','40254','0','11','1','1','0'), 
 ('15936','40256','0','11','1','1','0'), 
 ('15936','40253','0','11','1','1','0'), 
 ('15936','40258','0','10','1','1','0'), 
 ('15936','40251','0','10','1','1','0'), 
 ('15936','40255','0','10','1','1','0'), 
 ('15936','40257','0','10','1','1','0'), 
 ('15936','40252','0','10','1','1','0');
 
  /* Kel'Thuzad */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15990','40753','0','86','2','2','1'), 
 ('15990','40633','0','55','1','1','0'), 
 ('15990','40632','0','52','1','1','0'),
 ('15990','40631','0','18','1','1','0'),
 ('15990','40403','0','18','1','1','0'),
 ('15990','40405','0','18','1','1','0'),
 ('15990','40395','0','17','1','1','0'),
 ('15990','40402','0','17','1','1','0'),
 ('15990','40396','0','17','1','1','0'),
 ('15990','40383','0','17','1','1','0'),
 ('15990','40387','0','17','1','1','0'),
 ('15990','40398','0','17','1','1','0'),
 ('15990','40388','0','17','1','1','0'),
 ('15990','40401','0','17','1','1','0'),
 ('15990','40399','0','17','1','1','0'),
 ('15990','40384','0','17','1','1','0'),
 ('15990','40400','0','16','1','1','0'),
 ('15990','40385','0','16','1','1','0'),
 ('15990','40386','0','16','1','1','0');
 
  /* Maexxna */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15952','40753','0','85','1','1','1'), 
 ('15952','40063','0','20','1','1','0'),
 ('15952','39768','0','19','1','1','0'),
 ('15952','39763','0','19','1','1','0'),
 ('15952','39764','0','18','1','1','0'),
 ('15952','39766','0','18','1','1','0'),
 ('15952','40061','0','18','1','1','0'),
 ('15952','40062','0','18','1','1','0'),
 ('15952','40060','0','18','1','1','0'),
 ('15952','39765','0','18','1','1','0'),
 ('15952','39758','0','18','1','1','0'),
 ('15952','39759','0','18','1','1','0'),
 ('15952','39760','0','18','1','1','0'),
 ('15952','39767','0','18','1','1','0'),
 ('15952','39761','0','17','1','1','0'),
 ('15952','39762','0','17','1','1','0'),
 ('15952','40258','0','74','1','1','0'),
 ('15952','40250','0','11','1','1','0'),
 ('15952','40255','0','11','1','1','0'),
 ('15952','40256','0','11','1','1','0'),
 ('15952','40254','0','11','1','1','0'),
 ('15952','40253','0','11','1','1','0'),
 ('15952','40257','0','10','1','1','0'),
 ('15952','40252','0','10','1','1','0'),
 ('15952','40251','0','10','1','1','0');
 
  /* Patchwerk */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('16028','40753','0','95','1','1','1'), 
 ('16028','40267','0','19','1','1','0'),
 ('16028','40263','0','19','1','1','0'),
 ('16028','40272','0','19','1','1','0'),
 ('16028','40271','0','19','1','1','0'),
 ('16028','40261','0','19','1','1','0'),
 ('16028','40259','0','19','1','1','0'),
 ('16028','40270','0','19','1','1','0'),
 ('16028','40264','0','19','1','1','0'),
 ('16028','40269','0','19','1','1','0'),
 ('16028','40262','0','18','1','1','0'),
 ('16028','40265','0','18','1','1','0'),
 ('16028','40268','0','18','1','1','0'),
 ('16028','40266','0','18','1','1','0'),
 ('16028','40273','0','18','1','1','0'),
 ('16028','40260','0','18','1','1','0'),
 ('16028','40075','0','11','1','1','0'),
 ('16028','40065','0','11','1','1','0'),
 ('16028','40108','0','11','1','1','0'),
 ('16028','40074','0','11','1','1','0'),
 ('16028','40107','0','11','1','1','0'),
 ('16028','40071','0','10','1','1','0'),
 ('16028','40080','0','10','1','1','0'),
 ('16028','40069','0','10','1','1','0'),
 ('16028','40064','0','10','1','1','0');
 
  /* Thaddius */
 REPLACE INTO `loot_creatures`
 (`entryid`,`itemid`,`percentchance`,`heroicpercentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES
 ('15928','40753','0','95','1','1','1'), 
 ('15928','40636','0','73','1','1','0'),
 ('15928','40635','0','57','1','1','0'),
 ('15928','40634','0','54','1','1','0'),
 ('15928','40303','0','19','1','1','0'),
 ('15928','40300','0','19','1','1','0'),
 ('15928','40304','0','18','1','1','0'),
 ('15928','40299','0','18','1','1','0'),
 ('15928','40301','0','18','1','1','0'),
 ('15928','40296','0','17','1','1','0'),
 ('15928','40294','0','17','1','1','0'),
 ('15928','40298','0','17','1','1','0'),
 ('15928','40297','0','17','1','1','0'),
 ('15928','40302','0','16','1','1','0');
-- dalaran GO's loot
 REPLACE INTO `loot_gameobjects` (`entryid`, `itemid`, `percentchance`, `heroicpercentchance`, `mincount`, `maxcount`, `ffa_loot`) VALUES (192818, 43100, 100, 0, 1, 1, 0); 
 REPLACE INTO `loot_gameobjects` (`entryid`, `itemid`, `percentchance`, `heroicpercentchance`, `mincount`, `maxcount`, `ffa_loot`) VALUES (192823, 43128, 100, 0, 1, 1, 0); 
 REPLACE INTO `loot_gameobjects` (`entryid`, `itemid`, `percentchance`, `heroicpercentchance`, `mincount`, `maxcount`, `ffa_loot`) VALUES (192824, 43138, 100, 0, 1, 1, 0);
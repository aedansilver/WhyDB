UPDATE db_version SET revision = 23, changeset = 67 WHERE db_name LIKE 'WhyDB';


DELETE FROM creature_spawns WHERE id=1381562;
DELETE FROM creature_waypoints WHERE spawnid=1381562;

DELETE FROM creature_spawns WHERE id=1381662;
DELETE FROM creature_waypoints WHERE spawnid=1381662;

DELETE FROM creature_spawns WHERE id=1381576;
DELETE FROM creature_waypoints WHERE spawnid=1381576;

DELETE FROM creature_spawns WHERE id=1381985;
DELETE FROM creature_waypoints WHERE spawnid=1381985;

DELETE FROM creature_spawns WHERE id=1381552;
DELETE FROM creature_waypoints WHERE spawnid=1381552;

DELETE FROM creature_spawns WHERE id=1382128;
DELETE FROM creature_waypoints WHERE spawnid=1382128;

DELETE FROM creature_spawns WHERE id=1381550;
DELETE FROM creature_waypoints WHERE spawnid=1381550;

DELETE FROM creature_spawns WHERE id=1381570;
DELETE FROM creature_waypoints WHERE spawnid=1381570;

DELETE FROM creature_spawns WHERE id=1381645;
DELETE FROM creature_waypoints WHERE spawnid=1381645;

DELETE FROM creature_spawns WHERE id=1382029;
DELETE FROM creature_waypoints WHERE spawnid=1382029;

DELETE FROM creature_spawns WHERE id=1381574;
DELETE FROM creature_waypoints WHERE spawnid=1381574;

DELETE FROM creature_spawns WHERE id=1382150;
DELETE FROM creature_waypoints WHERE spawnid=1382150;

DELETE FROM creature_spawns WHERE id=1381639;
DELETE FROM creature_waypoints WHERE spawnid=1381639;

DELETE FROM creature_spawns WHERE id=1382133;
DELETE FROM creature_waypoints WHERE spawnid=1382133;

DELETE FROM creature_spawns WHERE id=1381629;
DELETE FROM creature_waypoints WHERE spawnid=1381629;

DELETE FROM creature_spawns WHERE id=1382151;
DELETE FROM creature_waypoints WHERE spawnid=1382151;

DELETE FROM creature_spawns WHERE id=1381670;
DELETE FROM creature_waypoints WHERE spawnid=1381670;

DELETE FROM creature_spawns WHERE id=1381689;
DELETE FROM creature_waypoints WHERE spawnid=1381689;

DELETE FROM creature_spawns WHERE id=1382109;
DELETE FROM creature_waypoints WHERE spawnid=1382109;
           
DELETE FROM creature_spawns WHERE id=1381186;
DELETE FROM creature_waypoints WHERE spawnid=1381186;

DELETE FROM creature_spawns WHERE id=1382152;
DELETE FROM creature_waypoints WHERE spawnid=1382152;

DELETE FROM creature_spawns WHERE id=1381591;
DELETE FROM creature_waypoints WHERE spawnid=1381591;

DELETE FROM creature_spawns WHERE id=1381692;
DELETE FROM creature_waypoints WHERE spawnid=1381692;

DELETE FROM creature_spawns WHERE id=1381671;
DELETE FROM creature_waypoints WHERE spawnid=1381671;

DELETE FROM creature_spawns WHERE id=1381560;
DELETE FROM creature_waypoints WHERE spawnid=1381560;

DELETE FROM creature_spawns WHERE id=1382056;
DELETE FROM creature_waypoints WHERE spawnid=1382056;

DELETE FROM creature_spawns WHERE id=1381966;
DELETE FROM creature_waypoints WHERE spawnid=1381966;

DELETE FROM creature_spawns WHERE id=1382049;
DELETE FROM creature_waypoints WHERE spawnid=1382049;

DELETE FROM creature_spawns WHERE id=1381653;
DELETE FROM creature_waypoints WHERE spawnid=1381653;

DELETE FROM creature_spawns WHERE id=1381676;
DELETE FROM creature_waypoints WHERE spawnid=1381676;

DELETE FROM creature_spawns WHERE id=1381586;
DELETE FROM creature_waypoints WHERE spawnid=1381586;

DELETE FROM creature_spawns WHERE id=1381962;
DELETE FROM creature_waypoints WHERE spawnid=1381962;

DELETE FROM creature_spawns WHERE id=1381556;
DELETE FROM creature_waypoints WHERE spawnid=1381556;

DELETE FROM creature_spawns WHERE id=1381433;
DELETE FROM creature_waypoints WHERE spawnid=1381433;

DELETE FROM creature_spawns WHERE id=1382055;
DELETE FROM creature_waypoints WHERE spawnid=1382055;

DELETE FROM creature_spawns WHERE id=1382052;
DELETE FROM creature_waypoints WHERE spawnid=1382052;

DELETE FROM creature_spawns WHERE id=1381659;
DELETE FROM creature_waypoints WHERE spawnid=1381659;

DELETE FROM creature_spawns WHERE id=1382071;
DELETE FROM creature_waypoints WHERE spawnid=1382071;

DELETE FROM creature_spawns WHERE id=1382031;
DELETE FROM creature_waypoints WHERE spawnid=1382031;

DELETE FROM creature_spawns WHERE id=1382032;
DELETE FROM creature_waypoints WHERE spawnid=1382032;

DELETE FROM creature_spawns WHERE id=1381672;
DELETE FROM creature_waypoints WHERE spawnid=1381672;
 
DELETE FROM creature_spawns WHERE id=1381649;
DELETE FROM creature_waypoints WHERE spawnid=1381649;

DELETE FROM creature_spawns WHERE id=1381661;
DELETE FROM creature_waypoints WHERE spawnid=1381661;

DELETE FROM creature_spawns WHERE id=1381319;
DELETE FROM creature_waypoints WHERE spawnid=1381319;

DELETE FROM creature_spawns WHERE id=1381582;
DELETE FROM creature_waypoints WHERE spawnid=1381582;

DELETE FROM creature_spawns WHERE id=1382060;
DELETE FROM creature_waypoints WHERE spawnid=1382060;

DELETE FROM creature_spawns WHERE id=1381736;
DELETE FROM creature_waypoints WHERE spawnid=1381736;

DELETE FROM creature_spawns WHERE id=1381573;
DELETE FROM creature_waypoints WHERE spawnid=1381573;

DELETE FROM creature_spawns WHERE id=1381572;
DELETE FROM creature_waypoints WHERE spawnid=1381572;

DELETE FROM creature_spawns WHERE id=1381857;
DELETE FROM creature_waypoints WHERE spawnid=1381857;

DELETE FROM creature_spawns WHERE id=1382141;
DELETE FROM creature_waypoints WHERE spawnid=1382141;

DELETE FROM creature_spawns WHERE id=1382142;
DELETE FROM creature_waypoints WHERE spawnid=1382142;

DELETE FROM creature_spawns WHERE id=1381589;
DELETE FROM creature_waypoints WHERE spawnid=1381589;

DELETE FROM creature_spawns WHERE id=1382111;
DELETE FROM creature_waypoints WHERE spawnid=1382111;

DELETE FROM creature_spawns WHERE id=1381419;
DELETE FROM creature_waypoints WHERE spawnid=1381419;

DELETE FROM creature_spawns WHERE id=1381657;
DELETE FROM creature_waypoints WHERE spawnid=1381657;

DELETE FROM creature_spawns WHERE id=1381599;
DELETE FROM creature_waypoints WHERE spawnid=1381599;

DELETE FROM creature_spawns WHERE id=1381600;
DELETE FROM creature_waypoints WHERE spawnid=1381600;

DELETE FROM creature_spawns WHERE id=1381405;
DELETE FROM creature_waypoints WHERE spawnid=1381405;

DELETE FROM creature_spawns WHERE id=1381568;
DELETE FROM creature_waypoints WHERE spawnid=1381568;

DELETE FROM creature_spawns WHERE id=1381575;
DELETE FROM creature_waypoints WHERE spawnid=1381575;

DELETE FROM creature_spawns WHERE id=1381402;
DELETE FROM creature_waypoints WHERE spawnid=1381402;

DELETE FROM creature_spawns WHERE id=1382050;
DELETE FROM creature_waypoints WHERE spawnid=1382050;

DELETE FROM creature_spawns WHERE id=1381602;
DELETE FROM creature_waypoints WHERE spawnid=1381602;

DELETE FROM creature_spawns WHERE id=1381688;
DELETE FROM creature_waypoints WHERE spawnid=1381688;

DELETE FROM creature_spawns WHERE id=1381630;
DELETE FROM creature_waypoints WHERE spawnid=1381630;


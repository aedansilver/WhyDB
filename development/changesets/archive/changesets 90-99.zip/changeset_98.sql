/* Changeset 98
	* Update description for 2 items.
	* Add teleport_coords for Cannon Prep spells.
	* Repair quest: Buying Some Time, missing kill requirement, thanks Tiramisu.
	* Update Salvageable Wood/Steel gameobject_spawns entry, thanks Cynmod.
	* Update requirement for Alliance Triage quest, thanks Tiramisu.
	* Update requirement for A Yeti Of Your Own quest.
	* Update spell for items Recipe: Succulent Orca Stew and Recipe: Showeltusk Soup.
	* Make quests non repeatable that shouldn't be, thanks Tiramisu.
	* Make quests repeatable that should be, thanks Tiramisu.
	* Oshu'gun Crystal Powder quest corrections, add required quests, thanks Tiramisu.
	* Fix Aldor/Scryer quest reputation rewards, thanks Tiramisu.
	* DK starting area quest: A special surprise, thanks to Tiramisu.
	* Remove incorrect reputation reward from The Apple Falls, thanks Tiramisu.
	* Repair quest: The Return of the Crusade?, missing kill requirement, thanks Tiramisu.
	* Scourgestone quests missing starter and finisher NPC entries, thanks to Tiramisu.
	* Deleted some event specific spawns
	* Deleted some rare spawns which had multiple spawn points
	* Processed around 5 very huge WDB files, thanks to Jordythery and volitall
	* Fix minlevel for 46 maps.
	* Fixed death state for Ruby Dragon
	* Fixed 1 go to have blizzlike GO ID
	* Deleted creature "Waypoint" from database, it was causing fuckups for quests
	* Updated item Pioneer Buckler to be 100% blizzlike
	* Updated item Grimoire of Blood Pact (Rank 3) to be 100% blizzlike
	* Updated item Everglowing Robe to be 100% blizzlike
	* Updated item Grimoire of Devour Magic (Rank 6) to be 100% blizzlike
	* Updated item Boots of Ferocity to be 100% blizzlike
	* Updated item Grimoire of Intercept (Rank 2) to be 100% blizzlike
	* Updated item Grimoire of Anguish (Rank 2) blizzlike
	* Updated item General's Scaled Greaves to be 100% blizzlike
	all items with ID up to 37487 are 100% blizzlike. More will come in next release.
*/

-- Update description for 2 items.
UPDATE `items` SET `description` = 'Teaches you how to summon this companion.' WHERE `entry` = '21168';
UPDATE `items` SET `description` = 'Teaches you how to summon this companion.' WHERE `entry` = '32498';

-- Add teleport_coords for Cannon Prep spells.
REPLACE INTO `teleport_coords` VALUES ('24730', 'Cannon Prep (Elwynn Forest)', '0', '-9569.150391', '-14.753426', '68.051422', '4.874008'),
	('24831', 'Cannon Prep (Mulgore)', '1', '-1326.711914', '86.301125', '133.093918', '3.510725'),
	('42826', 'Cannon Prep (Shattrath)', '530', '-1742.640869', '5454.712402', '-7.928009', '4.606363');

-- Repair quest: Buying Some Time, missing kill requirement, thanks Tiramisu.
UPDATE `quests` SET `ReqKillMobOrGOId1` = '26195', `ReqKillMobOrGOCount1` = '20' WHERE `entry` = '11938';

-- Update Salvageable Wood/Steel gameobject_spawns entry, thanks Cynmod.
update gameobject_spawns set entry = 182799 where entry = 182936;
update gameobject_spawns set entry = 182797 where entry = 182937;
update gameobject_spawns set entry = 182797 where entry = 182798;
DELETE FROM `loot_gameobjects` WHERE `entryid` IN (182936,182937,182798);

-- Update requirement for Alliance Triage quest, thanks Tiramisu.
UPDATE `quests` SET `RequiredTradeskillValue` = '225', `RequiredQuest1` = '0' WHERE `entry` = '6624';

-- Update requirement for A Yeti Of Your Own quest.
UPDATE `quests` SET `RequiredTradeskill` = '202', `RequiredTradeSkillValue` = '250', `RequiredQuest1` = '5163' WHERE `entry` = '8798';

-- Update spell for items Recipe: Succulent Orca Stew and Recipe: Showeltusk Soup.
UPDATE `items` SET `spellid_1` = '45547' WHERE `entry` = '39692';
UPDATE `items` SET `spellid_1` = '44438' WHERE `entry` = '34126';

-- Make quests non repeatable that shouldn't be, thanks Tiramisu.
UPDATE quests SET isrepeatable = '0' WHERE entry IN (
  10074,  -- Oshu'gun Crystal Powder, Horde (part 1)
  10076   -- Oshu'gun Crystal Powder, Alli (part 1)
);
-- Make quests repeatable that should be, thanks Tiramisu.
UPDATE quests SET isrepeatable = '1' WHERE entry IN (
  10075,  -- Oshu'gun Crystal Powder, Horde (part 2)
  10077   -- Oshu'gun Crystal Powder, Alli (part 2)
);
-- Fix race requirement for 3 quests.
UPDATE `quests` SET `RequiredRaces` = '690' WHERE `entry` IN ('11887', '11654', '11659');

-- Oshu'gun Crystal Powder quest corrections, add required quests
UPDATE quests SET requiredquest1 = '10074' WHERE entry = '10075';
UPDATE quests SET requiredquest1 = '10076' WHERE entry = '10077';

-- Fix Aldor/Scryer quest reputation rewards
UPDATE quests SET rewrepvalue1 = '-275', rewrepvalue2 = '250' WHERE entry IN (
  10189  -- Manaforge B'naar
);
UPDATE quests SET rewrepvalue1 = '-82', rewrepvalue2 = '75' WHERE entry IN (
  10686, -- The Warden's Cage
  10689  -- Altruis
);

-- DK starting area quest: A special surprise. There are 10 of these, one for
-- each race. Correcting RequiredRaces flag for all:
UPDATE quests SET RequiredRaces = '32' WHERE entry = '12739'; -- Tauren
UPDATE quests SET RequiredRaces = '1' WHERE entry = '12742'; -- Human
UPDATE quests SET RequiredRaces = '8' WHERE entry = '12743'; -- Night elf
UPDATE quests SET RequiredRaces = '4' WHERE entry = '12744'; -- Dwarf
UPDATE quests SET RequiredRaces = '64' WHERE entry = '12745'; -- Gnome
UPDATE quests SET RequiredRaces = '1024' WHERE entry = '12746'; -- Draenei
UPDATE quests SET RequiredRaces = '512' WHERE entry = '12747'; -- Blood Elf
UPDATE quests SET RequiredRaces = '2' WHERE entry = '12748'; -- Orc
UPDATE quests SET RequiredRaces = '128' WHERE entry = '12749'; -- Troll
UPDATE quests SET RequiredRaces = '16' WHERE entry = '12750'; -- Undead

-- Remove incorrect reputation reward from rogue class quest lvl 10, The Apple Falls
UPDATE quests SET rewrepvalue1 = '0' WHERE entry = 2241;

-- Repair quest: The Return of the Crusade?, missing kill requirement:
UPDATE quests SET ReqKillMobOrGOId1 = '27875', ReqKillMobOrGOCount1 = '20' WHERE entry = '12476';

-- Scourgestone quests missing starter and finisher NPC entries
REPLACE INTO `creature_quest_starter` (`id`, `quest`) VALUES
  ('10839','5402'),
  ('10839','5403'),
  ('10840','5407'),
  ('10840','5408'),
  ('11039','5508'),
  ('11039','5509'),
  ('11039','5510');
REPLACE INTO `creature_quest_finisher` (`id`, `quest`) VALUES
  ('10839','5402'),
  ('10839','5403'),
  ('10840','5407'),
  ('10840','5408'),
  ('11039','5508'),
  ('11039','5509'),
  ('11039','5510');

-- Generated by WhyDB changeset creator - table creature_names
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 232;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 266;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 334;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 335;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 344;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 346;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 348;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 382;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 412;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 415;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 429;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 431;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 432;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 433;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 434;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 437;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 445;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 464;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 485;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 486;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 518;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 543;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 568;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 579;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 580;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 675;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 703;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 769;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 790;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 793;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 856;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 859;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 900;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 903;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 931;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 932;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 933;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 934;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 935;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 936;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 956;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1013;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1014;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1029;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1035;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 1070;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 1119;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1157;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1158;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1159;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 1160;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 1182;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 1259;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1276;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 1322;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1331;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1332;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1334;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1335;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1336;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1342;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 1343;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 1436;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 1671;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 1788;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 1802;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 1804;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 1805;
UPDATE creature_names SET unknown_float1 = '3.3', unknown_float2 = '3' WHERE entry = 1852;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 2105;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2188;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2249;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2271;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2272;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2274;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 2333;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2358;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2359;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2360;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 2388;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2392;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2393;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2395;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2397;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2403;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2411;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2412;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2413;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 2429;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 2434;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2440;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2449;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 2451;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 2466;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 2468;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 2469;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2555;
UPDATE creature_names SET male_displayid = '28224', unknown_float1 = '1.15' WHERE entry = 2558;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2564;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2590;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2591;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2628;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2676;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 2678;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 2694;
UPDATE creature_names SET unknown_float1 = '15' WHERE entry = 2748;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 2783;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 2803;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 2918;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 2941;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3053;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3087;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3088;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3089;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3090;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3091;
UPDATE creature_names SET family = '0' WHERE entry = 3102;
UPDATE creature_names SET female_displayid = '3735' WHERE entry = 3128;
UPDATE creature_names SET male_displayid = '1860', female_displayid = '1862' WHERE entry = 3129;
UPDATE creature_names SET female_displayid = '1533', male_displayid2 = '1958' WHERE entry = 3131;
UPDATE creature_names SET unknown_float2 = '1.2' WHERE entry = 3183;
UPDATE creature_names SET male_displayid = '4186', female_displayid = '4187' WHERE entry = 3196;
UPDATE creature_names SET female_displayid = '4195' WHERE entry = 3199;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 3203;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3235;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3237;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3238;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3239;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3252;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 3305;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3339;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3374;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3375;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3376;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3377;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3378;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 3388;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 3391;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3392;
UPDATE creature_names SET unknown_float1 = '0.85' WHERE entry = 3397;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3414;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3456;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3466;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3473;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3491;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3492;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3493;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3494;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3496;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3497;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3498;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3499;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 3502;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 3537;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 3538;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3572;
UPDATE creature_names SET unknown_float1 = '8' WHERE entry = 3581;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 3582;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 3621;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 3659;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 3700;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 3780;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3789;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3791;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 3853;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3854;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 3855;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 3857;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3859;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3863;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3864;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3865;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3866;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3872;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 3877;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 3886;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 3887;
UPDATE creature_names SET male_displayid = '4587', female_displayid = '0' WHERE entry = 3907;
UPDATE creature_names SET male_displayid = '4587', female_displayid = '0' WHERE entry = 3909;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 3919;
UPDATE creature_names SET unknown_float1 = '6' WHERE entry = 3927;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 3943;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4026;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4027;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4028;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4029;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4031;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4032;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4034;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4035;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4037;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4038;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4041;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4042;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4083;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4096;
UPDATE creature_names SET unknown_float1 = '0.9' WHERE entry = 4100;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4101;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4104;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4114;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4118;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4120;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4124;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4140;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4143;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4144;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4147;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4150;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4151;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4154;
UPDATE creature_names SET unknown_float1 = '0.2' WHERE entry = 4166;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4248;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 4274;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 4278;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 4279;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 4317;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4343;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4380;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4382;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4385;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4387;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4389;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4390;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4419;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4429;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4430;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 4444;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4452;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4453;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4454;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4458;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4461;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 4472;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4495;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4496;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4498;
UPDATE creature_names SET unknown_float1 = '4', unknown_float2 = '1.5' WHERE entry = 4516;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4593;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4594;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4595;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4606;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4607;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 4608;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4620;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4623;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4630;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4632;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4633;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4634;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4635;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4636;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4637;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4638;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4639;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4640;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4641;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4642;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4643;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4644;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4645;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4646;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4647;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4648;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4649;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4651;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4652;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4653;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4654;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4655;
UPDATE creature_names SET unknown_float1 = '0.95' WHERE entry = 4656;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4657;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4658;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4659;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4661;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4663;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4664;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4665;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4666;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4667;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4668;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4670;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4671;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4672;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4673;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4674;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4675;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4676;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4677;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4678;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4679;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4680;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4681;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4682;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4684;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4685;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4686;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4687;
UPDATE creature_names SET unknown_float1 = '0.4' WHERE entry = 4688;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 4689;
UPDATE creature_names SET unknown_float1 = '0.4' WHERE entry = 4690;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4692;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4693;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4694;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4695;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4699;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 4700;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 4701;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 4702;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4709;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4720;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4726;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4727;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4728;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4729;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4792;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 4799;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4805;
UPDATE creature_names SET unknown_float1 = '4.5' WHERE entry = 4807;
UPDATE creature_names SET male_displayid = '2882', female_displayid = '2883', male_displayid2 = '2884', female_displayid2 = '2885', unknown_float1 = '3' WHERE entry = 4809;
UPDATE creature_names SET male_displayid = '2898', female_displayid = '2899', male_displayid2 = '2900', female_displayid2 = '2901', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4810;
UPDATE creature_names SET male_displayid = '2886', female_displayid = '2887', male_displayid2 = '2888', female_displayid2 = '2889', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4811;
UPDATE creature_names SET female_displayid = '2895', male_displayid2 = '2896', female_displayid2 = '2897', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4812;
UPDATE creature_names SET male_displayid = '2876', female_displayid = '2877', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4813;
UPDATE creature_names SET male_displayid = '2890', female_displayid = '2891', male_displayid2 = '2892', female_displayid2 = '2893', unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 4814;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4815;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4818;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4819;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4820;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4821;
UPDATE creature_names SET unknown_float1 = '2.3' WHERE entry = 4823;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4827;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 4830;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '2.5' WHERE entry = 4832;
UPDATE creature_names SET male_displayid = '4675', female_displayid = '4676', male_displayid2 = '19835', female_displayid2 = '19836', unknown_float1 = '1.15' WHERE entry = 4834;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4847;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4848;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4849;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4852;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4853;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 4854;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4855;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4857;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4860;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4861;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 4863;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4885;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4886;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4888;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4889;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4890;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4898;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4899;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 4900;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4941;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4945;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4946;
UPDATE creature_names SET unknown_float1 = '0.02' WHERE entry = 4958;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 4965;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4966;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 4971;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 4977;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 4978;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4980;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 4983;
UPDATE creature_names SET female_displayid = '21687', unknown_float1 = '1.15' WHERE entry = 5057;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 5058;
UPDATE creature_names SET male_displayid = '2978', female_displayid = '2977', male_displayid2 = '2979', female_displayid2 = '2980', unknown_float1 = '1.1' WHERE entry = 5085;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 5086;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5089;
UPDATE creature_names SET male_displayid = '4677', female_displayid = '4679', male_displayid2 = '19833', female_displayid2 = '19834', unknown_float1 = '1.15' WHERE entry = 5184;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5224;
UPDATE creature_names SET female_displayid = '7671', male_displayid2 = '7672' WHERE entry = 5226;
UPDATE creature_names SET female_displayid = '6671' WHERE entry = 5259;
UPDATE creature_names SET female_displayid = '4772' WHERE entry = 5267;
UPDATE creature_names SET female_displayid = '6676' WHERE entry = 5270;
UPDATE creature_names SET female_displayid = '4774' WHERE entry = 5271;
UPDATE creature_names SET female_displayid = '6677' WHERE entry = 5273;
UPDATE creature_names SET unknown_float1 = '25' WHERE entry = 5312;
UPDATE creature_names SET unknown_float1 = '25', unknown_float2 = '10' WHERE entry = 5317;
UPDATE creature_names SET unknown_float1 = '25' WHERE entry = 5319;
UPDATE creature_names SET unknown_float1 = '25' WHERE entry = 5320;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5336;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5337;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5359;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5360;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5361;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5396;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5397;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5430;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5455;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5456;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5457;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5458;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5459;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5472;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5474;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 5501;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5598;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 5600;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5601;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5602;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 5620;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 5624;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 5634;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 5638;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5641;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5642;
UPDATE creature_names SET male_displayid = '6419', female_displayid = '6420', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5648;
UPDATE creature_names SET female_displayid = '6424', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5649;
UPDATE creature_names SET male_displayid = '6421', female_displayid = '6422', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 5650;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 5652;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 5662;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5752;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5760;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5762;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5771;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5797;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5798;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 5799;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 5800;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5824;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 5840;
UPDATE creature_names SET unknown_float1 = '0.9' WHERE entry = 5847;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 5849;
UPDATE creature_names SET female_displayid = '1127', male_displayid2 = '549' WHERE entry = 5890;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 5901;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5916;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5931;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 5937;
UPDATE creature_names SET male_displayid = '7838', female_displayid = '6779', male_displayid2 = '6780', female_displayid2 = '6781', unknown_float1 = '1.3' WHERE entry = 6004;
UPDATE creature_names SET male_displayid = '6770', female_displayid = '6771', male_displayid2 = '6772', female_displayid2 = '6773', unknown_float1 = '1.3' WHERE entry = 6006;
UPDATE creature_names SET unknown_float1 = '0.05' WHERE entry = 6017;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6019;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 6118;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 6125;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 6126;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 6127;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 6132;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 6166;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6167;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6212;
UPDATE creature_names SET unknown_float1 = '1.02', unknown_float2 = '2' WHERE entry = 6213;
UPDATE creature_names SET female_displayid = '6925', unknown_float1 = '1.02' WHERE entry = 6221;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6222;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6224;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6225;
UPDATE creature_names SET unknown_float1 = '2.5' WHERE entry = 6226;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 6228;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6230;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 6232;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6234;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 6235;
UPDATE creature_names SET unknown_float1 = '6' WHERE entry = 6243;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 6244;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 6247;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 6251;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 6375;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 6395;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 6495;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 6496;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 6546;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 6548;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 6706;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6727;
UPDATE creature_names SET female_displayid = '5448' WHERE entry = 6728;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6729;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 6730;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 6791;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6906;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 6907;
UPDATE creature_names SET unknown_float1 = '3.5' WHERE entry = 6908;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 6910;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 6912;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7009;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7011;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 7023;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7030;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 7033;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 7034;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 7035;
UPDATE creature_names SET unknown_float1 = '0.25' WHERE entry = 7076;
UPDATE creature_names SET unknown_float1 = '0.25' WHERE entry = 7077;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 7078;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7086;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7092;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7097;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7098;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7099;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7100;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7101;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7114;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7118;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7132;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7136;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7139;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7153;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7154;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7155;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7156;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7157;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7158;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 7172;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 7206;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 7228;
UPDATE creature_names SET female_displayid = '6426', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 7246;
UPDATE creature_names SET male_displayid = '6427', female_displayid = '6428', unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 7247;
UPDATE creature_names SET unknown_float1 = '7', unknown_float2 = '2' WHERE entry = 7267;
UPDATE creature_names SET unknown_float1 = '7', unknown_float2 = '4' WHERE entry = 7271;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 7272;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '2' WHERE entry = 7273;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 7274;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 7275;
UPDATE creature_names SET female_displayid = '6437' WHERE entry = 7276;
UPDATE creature_names SET female_displayid = '6418', unknown_float1 = '3' WHERE entry = 7286;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7290;
UPDATE creature_names SET unknown_float1 = '9' WHERE entry = 7291;
UPDATE creature_names SET unknown_float1 = '0.25' WHERE entry = 7309;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7320;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7321;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7327;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7328;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7329;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7332;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 7333;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 7334;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 7335;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7337;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7341;
UPDATE creature_names SET unknown_float1 = '0.25' WHERE entry = 7343;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7345;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 7346;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7348;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7352;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7353;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7396;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7397;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 7405;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7447;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 7456;
UPDATE creature_names SET unknown_float1 = '0.2' WHERE entry = 7527;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 7603;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 7604;
UPDATE creature_names SET unknown_float1 = '3.5' WHERE entry = 7605;
UPDATE creature_names SET unknown_float1 = '3.5' WHERE entry = 7606;
UPDATE creature_names SET unknown_float1 = '9.7' WHERE entry = 7607;
UPDATE creature_names SET unknown_float1 = '3.5' WHERE entry = 7608;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '20' WHERE entry = 7666;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 7714;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 7731;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 7736;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7764;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7765;
UPDATE creature_names SET unknown_float1 = '0' WHERE entry = 7768;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 7771;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 7779;
UPDATE creature_names SET unknown_float1 = '1.4' WHERE entry = 7780;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7784;
UPDATE creature_names SET unknown_float1 = '0.1' WHERE entry = 7785;
UPDATE creature_names SET unknown_float1 = '0.5' WHERE entry = 7786;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 7787;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7788;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 7789;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 7795;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 7796;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 7797;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 7801;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7803;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 7850;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7852;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7878;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7879;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 7880;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 7900;
UPDATE creature_names SET unknown_float1 = '0.1' WHERE entry = 7915;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7939;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7941;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7942;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7943;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7945;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7946;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7947;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7948;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 7949;
UPDATE creature_names SET female_displayid = '4084', unknown_float1 = '2' WHERE entry = 8017;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 8019;
UPDATE creature_names SET unknown_float1 = '0.2' WHERE entry = 8035;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8095;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8119;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 8120;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '8' WHERE entry = 8127;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8130;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 8138;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 8141;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 8150;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 8151;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 8152;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 8153;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 8154;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8156;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 8157;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 8320;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 8400;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 8402;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 8417;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8479;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 8480;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 8509;
UPDATE creature_names SET unknown_float1 = '0.01' WHERE entry = 8510;
UPDATE creature_names SET unknown_float1 = '8' WHERE entry = 8567;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 8585;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 8738;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 8876;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 8877;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 8878;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 8888;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8889;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8890;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8891;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8892;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8894;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 8896;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 8897;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 8904;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8909;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8910;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8911;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8912;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8913;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 8914;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 8916;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 8922;
UPDATE creature_names SET female_displayid = '9354', male_displayid2 = '9028', female_displayid2 = '9029' WHERE entry = 8932;
UPDATE creature_names SET female_displayid = '909', male_displayid2 = '821', female_displayid2 = '520', unknown_float1 = '2.5' WHERE entry = 8933;
UPDATE creature_names SET unknown_float1 = '1.55' WHERE entry = 8957;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 8960;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '5' WHERE entry = 9018;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 9020;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 9021;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 9022;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '2' WHERE entry = 9023;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '5' WHERE entry = 9024;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 9025;
UPDATE creature_names SET unknown_float1 = '9', unknown_float2 = '2' WHERE entry = 9028;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 9116;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 9238;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 9318;
UPDATE creature_names SET unknown_float1 = '4.5', unknown_float2 = '2' WHERE entry = 9319;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 9377;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 9464;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 9465;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 9467;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 9525;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 9528;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 9529;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 9558;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 9636;
UPDATE creature_names SET unknown_float1 = '6' WHERE entry = 9677;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '5' WHERE entry = 9678;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 9679;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 9680;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 9681;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 9683;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 9684;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 9878;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 9982;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 9983;
UPDATE creature_names SET unknown_float1 = '0.2' WHERE entry = 10016;
UPDATE creature_names SET unknown_float1 = '0.2' WHERE entry = 10017;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 10037;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 10043;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10048;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10059;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 10063;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10079;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 10082;
UPDATE creature_names SET unknown_float1 = '4.5', unknown_float2 = '2' WHERE entry = 10096;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 10120;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 10293;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10377;
UPDATE creature_names SET unknown_float1 = '0.1' WHERE entry = 10389;
UPDATE creature_names SET unknown_float1 = '6.5', unknown_float2 = '2' WHERE entry = 10393;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 10416;
UPDATE creature_names SET unknown_float1 = '5', unknown_float2 = '2' WHERE entry = 10417;
UPDATE creature_names SET unknown_float1 = '15', unknown_float2 = '4' WHERE entry = 10436;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '1.5' WHERE entry = 10438;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10617;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 10697;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10698;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10758;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 10760;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 10761;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10836;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 10897;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10920;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 10921;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10922;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10923;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 10924;
UPDATE creature_names SET unknown_float1 = '0' WHERE entry = 10925;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 11019;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 11024;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 11103;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 11104;
UPDATE creature_names SET female_displayid = '10638', male_displayid2 = '10639', female_displayid2 = '10640', unknown_float1 = '5', unknown_float2 = '3' WHERE entry = 11120;
UPDATE creature_names SET unknown_float1 = '2.5' WHERE entry = 11142;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 11181;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 11259;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11438;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11451;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11452;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11453;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11454;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11455;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11456;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 11457;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11461;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11462;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11464;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11465;
UPDATE creature_names SET unknown_float1 = '8' WHERE entry = 11490;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 11491;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11516;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11553;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11554;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11555;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11557;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11558;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 11559;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 11564;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 11576;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 11577;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 11578;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11596;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 11625;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 11626;
UPDATE creature_names SET unknown_float1 = '25' WHERE entry = 11667;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11686;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11688;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11715;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11717;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11777;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11778;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11781;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11782;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11784;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11785;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11786;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11787;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11788;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11793;
UPDATE creature_names SET name = 'Sister of Celebras', unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 11794;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 11799;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 11822;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 11824;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 11825;
UPDATE creature_names SET unknown_float1 = '35', unknown_float2 = '35' WHERE entry = 11832;
UPDATE creature_names SET unknown_float1 = '0.65' WHERE entry = 11873;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 11937;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 12046;
UPDATE creature_names SET unknown_float1 = '7' WHERE entry = 12203;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '1.5' WHERE entry = 12206;
UPDATE creature_names SET unknown_float1 = '5.5', unknown_float2 = '1.5' WHERE entry = 12207;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12223;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12224;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '4' WHERE entry = 12225;
UPDATE creature_names SET unknown_float1 = '7.5' WHERE entry = 12236;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12237;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 12238;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12239;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12240;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 12241;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 12245;
UPDATE creature_names SET unknown_float1 = '6.5' WHERE entry = 12258;
UPDATE creature_names SET unknown_float1 = '25' WHERE entry = 12497;
UPDATE creature_names SET unknown_float1 = '1.02' WHERE entry = 12576;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 12578;
UPDATE creature_names SET unknown_float1 = '100' WHERE entry = 12803;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '2' WHERE entry = 12902;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 12937;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 12960;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 13019;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '1.5' WHERE entry = 13021;
UPDATE creature_names SET female_displayid = '12963', unknown_float1 = '0.75' WHERE entry = 13022;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 13076;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '2' WHERE entry = 13196;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '2' WHERE entry = 13197;
UPDATE creature_names SET unknown_float1 = '20' WHERE entry = 13217;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 13276;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '3' WHERE entry = 13280;
UPDATE creature_names SET unknown_float1 = '7' WHERE entry = 13282;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '1.5' WHERE entry = 13285;
UPDATE creature_names SET female_displayid = '13210', unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13323;
UPDATE creature_names SET female_displayid = '13279', male_displayid2 = '13280', female_displayid2 = '13281', unknown_float1 = '0.5' WHERE entry = 13328;
UPDATE creature_names SET unknown_float1 = '0.4' WHERE entry = 13456;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 13599;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '2' WHERE entry = 13601;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 13656;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 13697;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 13698;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '4' WHERE entry = 13716;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 13717;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 13718;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13738;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13739;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13740;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13741;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 13742;
UPDATE creature_names SET unknown_float1 = '8' WHERE entry = 13841;
UPDATE creature_names SET male_displayid2 = '0', female_displayid2 = '0' WHERE entry = 13876;
UPDATE creature_names SET unknown_float1 = '3.5' WHERE entry = 13896;
UPDATE creature_names SET unknown_float1 = '550' WHERE entry = 14020;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 14226;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 14230;
UPDATE creature_names SET flags1 = '0' WHERE entry = 14271;
UPDATE creature_names SET female_displayid = '3764', unknown_float1 = '3' WHERE entry = 14275;
UPDATE creature_names SET unknown_float1 = '8', unknown_float2 = '4' WHERE entry = 14327;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 14349;
UPDATE creature_names SET unknown_float1 = '0.15' WHERE entry = 14350;
UPDATE creature_names SET unknown_float1 = '6', unknown_float2 = '6' WHERE entry = 14354;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 14356;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '1.5' WHERE entry = 14357;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 14424;
UPDATE creature_names SET unknown_float1 = '105', unknown_float2 = '5' WHERE entry = 14515;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 14523;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 14621;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14624;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14625;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14626;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14627;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14628;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 14634;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 14961;
UPDATE creature_names SET unknown_float1 = '50' WHERE entry = 15008;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 15315;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 15395;
UPDATE creature_names SET male_displayid = '4587', female_displayid = '0', unknown_float1 = '0.05' WHERE entry = 15487;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 16079;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 16227;
UPDATE creature_names SET unknown_float1 = '1', unknown_float2 = '1' WHERE entry = 16800;
UPDATE creature_names SET unknown_float1 = '1', unknown_float2 = '1' WHERE entry = 16801;
UPDATE creature_names SET unknown_float1 = '1', unknown_float2 = '1' WHERE entry = 16802;
UPDATE creature_names SET unknown_float2 = '0.5' WHERE entry = 16974;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 17039;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 17084;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 17085;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 17108;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 17413;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '4' WHERE entry = 17877;
UPDATE creature_names SET unknown_float1 = '18' WHERE entry = 17942;
UPDATE creature_names SET male_displayid = '17035', female_displayid = '17612', unknown_float1 = '1.35' WHERE entry = 17998;
UPDATE creature_names SET male_displayid = '17035', female_displayid = '17612', unknown_float1 = '1.35' WHERE entry = 18000;
UPDATE creature_names SET male_displayid = '17035', female_displayid = '17612', unknown_float1 = '1.35' WHERE entry = 18002;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '10' WHERE entry = 18105;
UPDATE creature_names SET male_displayid = '18323', unknown_float1 = '3' WHERE entry = 18139;
UPDATE creature_names SET male_displayid = '17627' WHERE entry = 18140;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 18201;
UPDATE creature_names SET male_displayid = '17898', female_displayid = '17900', unknown_float1 = '1.3' WHERE entry = 18548;
UPDATE creature_names SET unknown_float1 = '0.1' WHERE entry = 18736;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 19305;
UPDATE creature_names SET unknown_float1 = '0.5' WHERE entry = 19419;
UPDATE creature_names SET unknown_float1 = '0.5' WHERE entry = 19420;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 19442;
UPDATE creature_names SET unknown_float1 = '0.5' WHERE entry = 19459;
UPDATE creature_names SET unknown_float1 = '0.5' WHERE entry = 19640;
UPDATE creature_names SET unknown_float1 = '0.4', unknown_float2 = '0.4' WHERE entry = 19733;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 20231;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 20232;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '10' WHERE entry = 20234;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '10' WHERE entry = 20235;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '10' WHERE entry = 20237;
UPDATE creature_names SET male_displayid = '5494', female_displayid = '16925', unknown_float1 = '1.35' WHERE entry = 20251;
UPDATE creature_names SET unknown_float1 = '50' WHERE entry = 20273;
UPDATE creature_names SET unknown_float1 = '50', unknown_float2 = '50' WHERE entry = 20274;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 20292;
UPDATE creature_names SET unknown_float1 = '0.9' WHERE entry = 20293;
UPDATE creature_names SET unknown_float1 = '50' WHERE entry = 20339;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 20599;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 20672;
UPDATE creature_names SET unknown_float1 = '0.2', unknown_float2 = '0.2' WHERE entry = 20710;
UPDATE creature_names SET unknown_float1 = '0.3', unknown_float2 = '0.3' WHERE entry = 20792;
UPDATE creature_names SET male_displayid = '1061', female_displayid = '16925' WHERE entry = 20814;
UPDATE creature_names SET male_displayid = '1061', female_displayid = '16925' WHERE entry = 20816;
UPDATE creature_names SET unknown_float1 = '2.9' WHERE entry = 21127;
UPDATE creature_names SET male_displayid = '17202', female_displayid = '16925' WHERE entry = 21182;
UPDATE creature_names SET male_displayid = '20165', female_displayid = '20744' WHERE entry = 21242;
UPDATE creature_names SET unknown_float1 = '0.75' WHERE entry = 21244;
UPDATE creature_names SET unknown_float1 = '0.6' WHERE entry = 21245;
UPDATE creature_names SET killcredit2 = '0', unknown_float1 = '1.1' WHERE entry = 21405;
UPDATE creature_names SET female_displayid = '20024', male_displayid2 = '0', female_displayid2 = '0', unknown_float1 = '1.35' WHERE entry = 21429;
UPDATE creature_names SET male_displayid = '16480', female_displayid = '19595', unknown_float1 = '1.35' WHERE entry = 21443;
UPDATE creature_names SET female_displayid = '19595', male_displayid2 = '0', female_displayid2 = '0', unknown_float1 = '1.35' WHERE entry = 21451;
UPDATE creature_names SET female_displayid = '20024', male_displayid2 = '0', female_displayid2 = '0', unknown_float1 = '1.35' WHERE entry = 21463;
UPDATE creature_names SET female_displayid = '17612', male_displayid2 = '0', female_displayid2 = '0', unknown_float1 = '1.35' WHERE entry = 21489;
UPDATE creature_names SET unknown_float1 = '17', unknown_float2 = '10' WHERE entry = 21504;
UPDATE creature_names SET female_displayid = '20288', male_displayid2 = '20288', female_displayid2 = '20289' WHERE entry = 21636;
UPDATE creature_names SET male_displayid = '20562', female_displayid = '20391', male_displayid2 = '20537' WHERE entry = 21660;
UPDATE creature_names SET female_displayid = '20396' WHERE entry = 21662;
UPDATE creature_names SET female_displayid = '20448', male_displayid2 = '20449', female_displayid2 = '20450', unknown_float1 = '1.5' WHERE entry = 21749;
UPDATE creature_names SET male_displayid = '1126', female_displayid = '20024' WHERE entry = 21967;
UPDATE creature_names SET male_displayid = '20417', female_displayid = '11686', unknown_float1 = '1.1' WHERE entry = 22086;
UPDATE creature_names SET male_displayid = '20698', female_displayid = '11686', unknown_float1 = '1.1' WHERE entry = 22087;
UPDATE creature_names SET male_displayid = '20688', female_displayid = '11686', unknown_float1 = '1.1' WHERE entry = 22088;
UPDATE creature_names SET unknown_float1 = '1.2' WHERE entry = 22381;
UPDATE creature_names SET male_displayid = '17202', female_displayid = '16925' WHERE entry = 22403;
UPDATE creature_names SET unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 22931;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 15901;
UPDATE creature_names SET unknown_float1 = '1.15' WHERE entry = 23554;
UPDATE creature_names SET male_displayid = '1196', female_displayid = '10255', unknown_float1 = '1.15' WHERE entry = 23555;
UPDATE creature_names SET male_displayid = '1126', female_displayid = '25268' WHERE entry = 23585;
UPDATE creature_names SET male_displayid = '21663', female_displayid = '21664', unknown_float1 = '1.15' WHERE entry = 23594;
UPDATE creature_names SET male_displayid = '21658', female_displayid = '21660', unknown_float1 = '1.15' WHERE entry = 23595;
UPDATE creature_names SET male_displayid = '21639', female_displayid = '21640', unknown_float1 = '1.15' WHERE entry = 23637;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 23723;
UPDATE creature_names SET male_displayid = '20570', female_displayid = '17188' WHERE entry = 23868;
UPDATE creature_names SET male_displayid = '20570', female_displayid = '17188' WHERE entry = 23869;
UPDATE creature_names SET rank = '1', unknown_float1 = '100' WHERE entry = 23899;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 23900;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 23951;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 23979;
UPDATE creature_names SET family = '0', unknown_float1 = '0.4' WHERE entry = 24476;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 24477;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 24830;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 25021;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 25022;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 25023;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 25024;
UPDATE creature_names SET unknown_float1 = '1.1' WHERE entry = 25025;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 24893;
UPDATE creature_names SET name = 'Gems and General Goods Vendor' WHERE entry = 26303;
UPDATE creature_names SET name = 'Plate Glyph Vendor' WHERE entry = 26304;
UPDATE creature_names SET male_displayid = '23761' WHERE entry = 26305;
UPDATE creature_names SET name = 'Cloth Glyph Vendor', male_displayid = '23760' WHERE entry = 26306;
UPDATE creature_names SET name = 'Leather & Mail Glyph Vendor', male_displayid = '23763' WHERE entry = 26308;
UPDATE creature_names SET unknown_float1 = '1.25' WHERE entry = 27703;
UPDATE creature_names SET unknown_float1 = '0.1' WHERE entry = 25534;
UPDATE creature_names SET unknown_float1 = '1.05' WHERE entry = 26076;
UPDATE creature_names SET type = '6' WHERE entry = 26115;
UPDATE creature_names SET killcredit2 = '0' WHERE entry = 26171;
UPDATE creature_names SET killcredit2 = '0', unknown_float1 = '1.3' WHERE entry = 26172;
UPDATE creature_names SET unknown_float1 = '1.3' WHERE entry = 26173;
UPDATE creature_names SET killcredit2 = '0', unknown_float1 = '1.3' WHERE entry = 26189;
UPDATE creature_names SET unknown_float1 = '12', unknown_float2 = '8' WHERE entry = 26206;
UPDATE creature_names SET unknown_float1 = '0.3' WHERE entry = 26224;
UPDATE creature_names SET unknown_float1 = '0.97', unknown_float2 = '0.98' WHERE entry = 26231;
UPDATE creature_names SET unknown_float1 = '0.97', unknown_float2 = '0.98' WHERE entry = 26299;
UPDATE creature_names SET killcredit2 = '27372', unknown_float1 = '1' WHERE entry = 26633;
UPDATE creature_names SET questitem2 = '37200' WHERE entry = 26644;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 26813;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 26853;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '5' WHERE entry = 26859;
UPDATE creature_names SET unknown_float1 = '10', unknown_float2 = '5' WHERE entry = 26979;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 27126;
UPDATE creature_names SET unknown_float1 = '1.35' WHERE entry = 27263;
UPDATE creature_names SET unknown_float1 = '1', unknown_float2 = '1' WHERE entry = 27328;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 27373;
UPDATE creature_names SET unknown_float1 = '1', unknown_float2 = '1' WHERE entry = 27520;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 27646;
UPDATE creature_names SET unknown_float1 = '20' WHERE entry = 27665;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 27716;
UPDATE creature_names SET unknown_float1 = '950', unknown_float2 = '2' WHERE entry = 27780;
UPDATE creature_names SET male_displayid = '28355', unknown_float1 = '0.02' WHERE entry = 28066;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 28854;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 28998;
UPDATE creature_names SET unknown_float1 = '1' WHERE entry = 29664;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 29751;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 29801;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 29806;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 29960;
UPDATE creature_names SET unknown_float1 = '2' WHERE entry = 29962;
UPDATE creature_names SET killcredit1 = '0' WHERE entry = 29964;
UPDATE creature_names SET type = '4', family = '0', unknown_float1 = '1.6' WHERE entry = 30001;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 30152;
UPDATE creature_names SET flags1 = '0', unknown_float1 = '3', unknown_float2 = '3' WHERE entry = 30290;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31223;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31224;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31225;
UPDATE creature_names SET unknown_float1 = '10' WHERE entry = 31285;
UPDATE creature_names SET unknown_float1 = '0.1', unknown_float2 = '0.05' WHERE entry = 31292;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 31293;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 31295;
UPDATE creature_names SET unknown_float1 = '4' WHERE entry = 31296;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 31297;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31298;
UPDATE creature_names SET unknown_float1 = '3' WHERE entry = 31299;
UPDATE creature_names SET unknown_float1 = '0.1', unknown_float2 = '0.05' WHERE entry = 31308;
UPDATE creature_names SET unknown_float1 = '0.1', unknown_float2 = '0.05' WHERE entry = 31309;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31316;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31322;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31328;
UPDATE creature_names SET unknown_float1 = '5' WHERE entry = 31330;
UPDATE creature_names SET unknown_float1 = '1000', unknown_float2 = '500' WHERE entry = 31334;
UPDATE creature_names SET unknown_float1 = '18.72' WHERE entry = 31406;
UPDATE creature_names SET unknown_float1 = '1.5' WHERE entry = 32438;
UPDATE creature_names SET unknown_float2 = '3' WHERE entry = 32800;
UPDATE creature_names SET name = 'Death Knight Trainer and Runeforge' WHERE entry = 33251;
UPDATE creature_names SET unknown_float1 = '3.97' WHERE entry = 33324;
UPDATE creature_names SET killcredit2 = '0', female_displayid = '25343', male_displayid2 = '0', female_displayid2 = '0' WHERE entry = 33537;
UPDATE creature_names SET female_displayid = '29169', male_displayid2 = '29170', unknown_float1 = '2' WHERE entry = 34300;
UPDATE creature_names SET male_displayid = '30598', female_displayid = '30599', male_displayid2 = '30600', female_displayid2 = '30601' WHERE entry = 36950;
UPDATE creature_names SET male_displayid = '30606', female_displayid = '30607', male_displayid2 = '30608' WHERE entry = 36961;
UPDATE creature_names SET male_displayid = '30603', female_displayid = '30604', male_displayid2 = '30605' WHERE entry = 36969;
UPDATE creature_names SET male_displayid = '27322', female_displayid = '27325', male_displayid2 = '27326', female_displayid2 = '27327' WHERE entry = 36971;
UPDATE creature_names SET male_displayid = '30467', female_displayid = '30468' WHERE entry = 37021;
UPDATE creature_names SET male_displayid = '30609', female_displayid = '30610', male_displayid2 = '30611' WHERE entry = 37116;
UPDATE creature_names SET male_displayid = '30750', female_displayid = '30751', male_displayid2 = '30752' WHERE entry = 37189;
UPDATE creature_names SET male_displayid = '30750', female_displayid = '30751', male_displayid2 = '30752' WHERE entry = 37920;
UPDATE creature_names SET male_displayid = '23037', female_displayid = '23038', male_displayid2 = '23039' WHERE entry = 37930;
UPDATE creature_names SET male_displayid = '30310', female_displayid = '30311' WHERE entry = 38200;
UPDATE creature_names SET unknown_float2 = '100' WHERE entry = 37955;
UPDATE creature_names SET male_displayid = '1126', female_displayid = '23257' WHERE entry = 38319;
UPDATE creature_names SET male_displayid = '169', female_displayid = '11686' WHERE entry = 38163;
UPDATE creature_names SET rank = '3', male_displayid = '30721', unknown_float1 = '1250', unknown_float2 = '500' WHERE entry = 36597;
UPDATE creature_names SET rank = '1', killcredit2 = '0', male_displayid = '31135', unknown_float1 = '12' WHERE entry = 38472;
UPDATE creature_names SET rank = '1', killcredit2 = '0', unknown_float1 = '75' WHERE entry = 38558;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38557;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38551;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36511;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 37232;
UPDATE creature_names SET male_displayid = '0' WHERE entry = 38370;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38471;
UPDATE creature_names SET rank = '1', male_displayid2 = '0' WHERE entry = 36853;
UPDATE creature_names SET flags1 = '64', male_displayid2 = '0' WHERE entry = 36980;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 37186;
UPDATE creature_names SET killcredit2 = '0', male_displayid2 = '0' WHERE entry = 37531;
UPDATE creature_names SET killcredit2 = '0', male_displayid2 = '0' WHERE entry = 37532;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38223;
UPDATE creature_names SET killcredit2 = '0', male_displayid2 = '0' WHERE entry = 37228;
UPDATE creature_names SET killcredit2 = '0', male_displayid2 = '0' WHERE entry = 37229;
UPDATE creature_names SET killcredit2 = '0', male_displayid2 = '0' WHERE entry = 37695;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 37698;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38199;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38995;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39372;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36633;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36701;
UPDATE creature_names SET name = 'Val\'kyr Protector', male_displayid2 = '0' WHERE entry = 38392;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38589;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36598;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36609;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 36823;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 37799;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38421;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38429;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38430;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38548;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38556;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38579;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38584;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38667;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38757;
UPDATE creature_names SET flags1 = '0', male_displayid2 = '0' WHERE entry = 40533;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40725;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 38285;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39746;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39747;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39751;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39794;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39814;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 39899;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40001;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40029;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40041;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40042;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40043;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40044;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40055;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40081;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40083;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40091;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40100;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40135;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40142;
UPDATE creature_names SET male_displayid = '169', female_displayid = '11686' WHERE entry = 40146;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40417;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40419;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40421;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40423;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40429;
UPDATE creature_names SET rank = '0' WHERE entry = 40626;
UPDATE creature_names SET rank = '0' WHERE entry = 40627;
UPDATE creature_names SET rank = '0' WHERE entry = 40628;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40870;
UPDATE creature_names SET male_displayid2 = '0' WHERE entry = 40246;
-- End of changeset for - table creature_names (WhyDB changeset creator)

-- Generated by WhyDB changeset creator - table gameobject_names
UPDATE gameobject_names SET spellfocus = '2061' WHERE entry = 151951;
UPDATE gameobject_names SET Type = '5' WHERE entry = 164729;
UPDATE gameobject_names SET sound1 = '177388', sound2 = '10' WHERE entry = 177388;
UPDATE gameobject_names SET sound1 = '1' WHERE entry = 178647;
UPDATE gameobject_names SET Type = '3', spellfocus = '43', sound1 = '180453', sound3 = '1' WHERE entry = 180453;
UPDATE gameobject_names SET sound2 = '13' WHERE entry = 181319;
UPDATE gameobject_names SET QuestItem1 = '30524', QuestItem2 = '30525', QuestItem3 = '30526', QuestItem4 = '0' WHERE entry = 184810;
UPDATE gameobject_names SET QuestItem1 = '30524', QuestItem2 = '30525', QuestItem3 = '30526', QuestItem4 = '0' WHERE entry = 184812;
UPDATE gameobject_names SET QuestItem1 = '30524', QuestItem2 = '30525', QuestItem3 = '30526', QuestItem4 = '0' WHERE entry = 184813;
UPDATE gameobject_names SET QuestItem1 = '30524', QuestItem2 = '30525', QuestItem3 = '30526', QuestItem4 = '0' WHERE entry = 184814;
UPDATE gameobject_names SET QuestItem1 = '30524', QuestItem2 = '30525', QuestItem3 = '30526', QuestItem4 = '0' WHERE entry = 184815;
UPDATE gameobject_names SET unknown14 = '1' WHERE entry = 192245;
UPDATE gameobject_names SET unknown2 = '1', unknown5 = '1' WHERE entry = 201814;
UPDATE gameobject_names SET sound1 = '28057' WHERE entry = 201872;
UPDATE gameobject_names SET sound1 = '28090' WHERE entry = 201875;
UPDATE gameobject_names SET sound1 = '28057' WHERE entry = 202177;
UPDATE gameobject_names SET sound1 = '28058' WHERE entry = 202238;
UPDATE gameobject_names SET sound1 = '28088' WHERE entry = 202241;
UPDATE gameobject_names SET Type = '31', spellfocus = '595' WHERE entry = 202265;
UPDATE gameobject_names SET Type = '31', spellfocus = '595', sound1 = '0' WHERE entry = 202266;
UPDATE gameobject_names SET sound1 = '28096' WHERE entry = 202340;
INSERT INTO gameobject_names VALUES ('203002','0','1287','Batlharus Channel Object','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('203004','10','9483','Broken Red Dragon Egg','','','','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1.5','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('203079','10','7398','Red Dragon Egg (Large)','','','','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','2.75','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('203003','10','7398','Red Dragon Egg','','','','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1.5','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('203080','10','9483','Broken Red Dragon Egg (Large)','','','','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','2.75','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202794','10','1327','Twilight Portal','','','','0','0','0','0','0','0','0','0','0','0','75074','0','0','0','0','0','0','0','0','0','0','0','0','0','5','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('203624','0','9624','Halion Twilight Ring','','','','1','0','0','0','0','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1.6','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202796','10','1327','Twilight Portal','','','','0','0','0','0','0','0','0','0','0','0','74812','0','0','0','0','0','0','0','0','0','0','0','0','0','2','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202795','10','1327','Twilight Portal','','','','0','0','0','0','0','0','0','0','0','0','75074','0','0','0','0','0','0','0','0','0','0','0','0','0','2','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('194498','5','8619','Gnomeregan Banner','','','','0','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','2','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202713','5','9392','Hazard Light Red 02','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202898','5','210','Scroll','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202564','5','9366','Gnome Table','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0.8','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202733','5','9086','Teleporter Pad','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202760','5','9086','Large Teleporter Pad','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','3','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202872','5','9441','Rocket Platform','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1.5','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202767','5','356','Defensive Radiation Pump Control','','','','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0','0','0','0','0');
INSERT INTO gameobject_names VALUES ('202922','10','9460','Irradiator 3000','','','','0','0','0','1000000','0','0','0','0','0','0','0','0','0','1','0','0','0','0','1','0','0','0','0','0','1','0','0','0','0','0','0');
-- End of changeset for - table gameobject_names (WhyDB changeset creator)

-- Generated by WhyDB changeset creator - table itempages
UPDATE itempages SET text = 'The devastating Second War against the orcish horde left the Alliance of Lordaeron in a state of shock and disarray. The bloodthirsty orcs, led by the mighty warchief, Orgrim Doomhammer, not only smashed their way through the dwarf-held lands of Khaz Modan, but had razed many of Lordaeron\'s central provinces as well. The unrelenting orcs even succeeded in ravaging the\r\nelves\' remote kingdom of Quel\'Thalas before their rampage was finally stopped.' WHERE entry = 627;
UPDATE itempages SET text = 'The Alliance armies led by Sir Anduin Lothar, Uther the Lightbringer, and Admiral Daelin Proudmoore pushed the orcs south into the shattered land of Azeroth - the first kingdom to fall before the orcs\' ruthless onslaught.\r\n\r\nThe Alliance forces under Sir Lothar managed to push Doomhammer\'s clans out of Lordaeron and back into the orc-controlled lands of Azeroth. Lothar\'s forces surrounded the orcs\' volcanic citadel of Blackrock Spire and laid siege to their defenses.' WHERE entry = 628;
UPDATE itempages SET text = 'There was nothing left for the ragged, scattered orc survivors but to flee to the last standing bastion of orcish power - the dark portal.\r\n\r\nTuralyon and his warriors chased the remaining orcs through the festering Swamp of Sorrows and into the corrupted Blasted Lands where the dark portal stood. There, at the foot of the colossal portal, the broken horde and the rugged Alliance clashed in what would be the last, bloodiest battle of the Second War. ' WHERE entry = 631;
UPDATE itempages SET text = 'The Mallet of Zul\'Farrak\r\n\r\nTo create the Mallet of Zul\'Farrak, one must first travel to the Altar of Zul and obtain the sacred mallet from a troll Keeper.\r\n\r\nNext, one must bring the sacred mallet to the altar atop of the troll city of Jintha\'alor.\r\n\r\nUsing the sacred mallet at the altar will infuse it with power, and transform it into the Mallet of Zul\'Farrak.\r\n' WHERE entry = 1091;
UPDATE itempages SET text = '<HTML>\r\n<BODY>\r\n<IMG src=\"InterfacePicturesLinken_sepia_256px\"/>\r\n</BODY>\r\n</HTML>' WHERE entry = 1371;
UPDATE itempages SET text = 'After the exiled Frostwolves charged through the portal, only a few orc clans followed. These orcs quickly set up a base of operations within the Black Morass, a dark and swampy area far to the east of the kingdom of Stormwind. As the orcs began to branch out and explore the new lands, they came into immediate conflict with the human defenders of Stormwind. \r\n' WHERE entry = 1965;
UPDATE itempages SET text = 'His old comrade, Durotan, returned from exile and warned him yet again of Gul\'dan\'s treachery. In speedy retribution, Gul\'dan\'s assassins murdered Durotan and his family, leaving only his infant son alive. Unknown to Doomhammer was the fact that Durotan\'s infant son was found by the human officer, Aedelas Blackmoore, and taken as a slave. \r\n\r\nThat infant orc would one day rise to become the greatest leader his people would ever know. ' WHERE entry = 1972;
UPDATE itempages SET text = 'The Prophet is powerful, and communicates with the spirits of our ancestors. But he is a fool! He has no idea the true power he possesses. On his person is the Amulet of Spirits--it is where most of his strength comes from.\r\n\r\nI have learned that the Amulet is powerful, but it is incomplete.' WHERE entry = 2592;
UPDATE itempages SET text = '<HTML>\r\n<BODY>\r\n<IMG src=\"InterfacePictures24475_gordawg_256\"/>\r\n</BODY>\r\n</HTML>' WHERE entry = 2944;
-- End of changeset for - table itempages (WhyDB changeset creator)

-- Generated by WhyDB changeset creator - table npc_text
UPDATE npc_text SET text7_0 = '' WHERE entry = 1079;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1080;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1081;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1082;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1083;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1084;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1085;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1086;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1087;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1088;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1089;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1090;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1091;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1092;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1093;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1094;
UPDATE npc_text SET lang7 = '0' WHERE entry = 1118;
UPDATE npc_text SET prob1 = '100', text1_0 = 'I sell only the finest arcane gear, made by the crafters and mages here in the city of Stormwind.', em7_0 = '0' WHERE entry = 1234;
UPDATE npc_text SET lang7 = '0' WHERE entry = 1255;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1516;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1519;
UPDATE npc_text SET em0_0 = '0', em0_1 = '1', em0_2 = '0', em0_3 = '5' WHERE entry = 1934;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1953;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1954;
UPDATE npc_text SET text7_0 = '' WHERE entry = 1955;
UPDATE npc_text SET text7_0 = '' WHERE entry = 2038;
UPDATE npc_text SET text7_0 = '' WHERE entry = 2175;
UPDATE npc_text SET text7_0 = '' WHERE entry = 2193;
UPDATE npc_text SET text7_0 = '' WHERE entry = 2279;
UPDATE npc_text SET text7_0 = '' WHERE entry = 3566;
UPDATE npc_text SET em0_0 = '0', em0_1 = '4' WHERE entry = 3945;
UPDATE npc_text SET lang7 = '0' WHERE entry = 4799;
UPDATE npc_text SET em0_0 = '0', em0_1 = '1' WHERE entry = 4878;
UPDATE npc_text SET lang7 = '0' WHERE entry = 5561;
UPDATE npc_text SET em0_0 = '1', em0_1 = '0' WHERE entry = 5840;
UPDATE npc_text SET em0_0 = '1', em0_1 = '0' WHERE entry = 5843;
UPDATE npc_text SET text7_0 = '' WHERE entry = 6353;
UPDATE npc_text SET prob0 = '1' WHERE entry = 6379;
UPDATE npc_text SET text7_0 = '' WHERE entry = 7095;
UPDATE npc_text SET text7_0 = '' WHERE entry = 8123;
UPDATE npc_text SET text0_1 = 'Certainly, $N. You only need to tell me what reputation you would like to know about.\r\n' WHERE entry = 8498;
UPDATE npc_text SET text0_1 = 'Certainly, $N.$B$BAdventurers that the Dawn views as friendly must submit a combined total of 60 insignias to access superior items. To access items of even greater power, they would be required to submit a total of 220 insignias.$B$BI must admit, the price is quite high for adventurers not favored by the Dawn.\r\n' WHERE entry = 8503;
UPDATE npc_text SET text0_0 = 'Ah, another $c looking to be a gladiator, eh? Good!\r\n\r\nI sell the arena team charters you\'ll need to participate in ranking Steamwheedle Fighting Circuit matches.', text0_1 = 'Ah, another $c looking to be a gladiator, eh? Good!\r\n\r\nI sell the arena team charters you\'ll need to participate in ranking Steamwheedle Fighting Circuit matches.' WHERE entry = 10608;
UPDATE npc_text SET text0_0 = 'My axe will see to the end of those that attack us.$B$BAnd if not my axe, then surely you will finish them.' WHERE entry = 13234;
UPDATE npc_text SET text0_0 = 'Varos Cloudstrider and his ring guardians protect the second ring.  Your drakes are more than a match for the Ring Guardians, but Varos stands behind an impenetrable shield created from the energy of the Oculus itself.  Ten Centrifuge Constructs power the shield from the ring and platforms above.  Destroy them and Varos will be vulnerable.\r\n\r\nI can grant you the power to call upon a drake from the Red Fight.  Speak to Eternos or Verdisa if you prefer to draw on the power of the Bronze or the Green.' WHERE entry = 12916;
UPDATE npc_text SET text0_0 = 'Belgaristrasz speaks the truth; time is running out!\r\n\r\nI can grant you the power to call upon a drake from the Bronze Fight.  Speak to Belgaristrasz or Verdisa if you prefer to draw on the power of the Red or the Green.' WHERE entry = 12917;
UPDATE npc_text SET text0_0 = 'Ruby Drakes excel at mitigating damage and protecting their allies.\r\n\r\nUsing Searing Wrath, they can breathe streams of liquid fire that jump from target to target, dealing increasing damage with each jump.\r\n\r\nWhenever a Ruby drake is damaged by an enemy attack, it gains an Evasive charge.  These charges can be used to perform a series of evasive maneuvers, allowing the drake to dodge incoming attacks and spells for a time.' WHERE entry = 13254;
UPDATE npc_text SET text0_0 = 'Greetings, hero. I craft and sell Crimson Acolyte armor for priests.\r\n', text0_1 = 'Greetings, hero. I craft and sell Crimson Acolyte armor for priests.\r\n' WHERE entry = 15452;
INSERT INTO npc_text VALUES ('13091','1','You\'re no death knight. Away with you.','You\'re no death knight. Away with you.','0','0','1','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('14785','1','This tear in the fabric of time and space looks ominous.  Different scenes flash by at terrifying speed.  A very brave person might try to jump through at the right time...','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('14791','1','Greetings, $c.$B$BThe Alliance currently control Wintergrasp Fortress, but the next battle starts soon.   Get ready to head to Wintergrasp and support our forces!$B$BThe next battle begins in $4354k.','Greetings, $c.$B$BThe Alliance currently control Wintergrasp Fortress, but the next battle starts soon.   Get ready to head to Wintergrasp and support our forces!$B$BThe next battle begins in $4354k.','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('14738','1','You\'ve impressed everyone here today with your skills in the arena.  It is now time to be recognized before all as a champion of the tournament.','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('15615','1','Looks just powerful enough to carry one gnome.  Maybe two.','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('15578','1','At last it is time for the exiled gnomes to return.$B$BOnce again Gnomeregan will be our home!','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('15580','1','The dwarves have kept us safe in their home for some time now, and for that we thank them.  However, the traitorous Thermaplugg\'s occupation of our home must at last come to an end.$B$BGnomeregan has festered beneath the atomic weight of our ill-conceived plan for too long. The detonation of the radiation bombs drove us from our city, but we now possess the technology to take it back!$B$BWe will regain what is ours... and bring Thermaplugg to justice!','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
INSERT INTO npc_text VALUES ('15581','1','Operation: Gnomeregan is divided into a number of phases:$B$BFirst, we must retake the air tower.  This will allow our planes give us air support as we move towards Gnomeregan\'s main entrance.$B$BIn addition, a cache of mechanized Battle Suits was discovered in one of the nearby buildings.  Once we have those suits, our assault on the entrance should be unstoppable.$B$BThen, we go straight for Thermaplugg in the heart of Gnomeregan!','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0','0','','','0','0','0','0','0','0','0');
-- End of changeset for - table npc_text (WhyDB changeset creator)

-- delete some rare spawns (they have multiple spawn points, but only one should be spawned at a time)
DELETE FROM `creature_spawns` WHERE `id` IN (299,300,301,302,303,304,305,592,593,594,595,2162,2163,2164,2165,2166,2167,2168,2169,2170,2171,2172,2173,2175,2176,2177,2185,2186,2188,2436,2437,2438,2439,2441,2442,2498,2499,2500,2501,2502,2503,2504,2578,2579,2580,2581,2582,2583,2584,2585,2586,2587,2588,2589,2591,2592,2593,2817,2818,3035,3036,3037,3039,3040,3041,3042,3043,3044,3045,3046,3047,3048,3049,3050,3051,3052,3053,3054,3055,3056,3057,3058,3059,3060,3061,3062,3063,3064,3065,3066,3067,3069,3070,3071,3072,3073,3074,3075,3076,3077,3078,3079,3080,3123,3125,3126,3370,3371,3372,3373,3375,3376,3377,3378,3379,3380,3381,3382,3383,5289,5290,5291,5292,5429,5430,5431,5432,5433,5434,5436,5437,5438,6544,6545,6546,6547,6548,6549,6550,6551,6552,6553,6554,6556,7463,7700,7701,7703,7704,7705,8264,8266,8267,8293,8294,9418,9420,9421,9422,11938,11939,11940,19384,19558,21726,21727,21728,21731,21732,21733,21734,21735,21737,21738,21739,21740,21741,21742,21743,21744,21745,21746,21748,21749,21751,21754,21905,21906,21907,22817,22818,138200,138201,48480,48482,48483,48484,48486,48487,48489,48490,48493,48495,48496,48497,48499,48500,48501,48502,48504,48506,48507,48508,48509,48510,48511,48512,48513,48514,48515,48516,48519,48520,48521,48522,48523,48524,48525,48526,48527,48528,48529,48531,48532,48533,48534,48535,48536,48537,48538,48539,48540,48541,48542,48543,48544,48546,48547,48548,48549,48550,48551,48552,48553,48554,48555,48556,48557,48558,48560,48561,48562,48563,48564,48565,48566,48567,48568,48569,48570,48571,48572,48573,48574,48576,48577,48578,48579,48580,48581,48582,48583,48584,48585,48586,48587,48588,48589,48590,48591,48592,48593,48594,48595,48596,48597,48598,48599,48600,48601,48861,48862,51564,51565,51566,51567,51568,51570,51571,51572,51573,51574,51575,51576,51577,51579,51580,51581,51582,51584,52532,52533,52534,52536,52537,52539,52540,53117,53118,53119,53120,53121,53123,53124,53125,53126,53127,136766,54175,54222,54226,55496,55497,55498,60978,60979,60980,60981,60982,60984,137107,141907,141908,141910,137109,141912,61011,61012,61014,61016,61017,61018,61019,61020,61021,61022,61023,61024,61025,61026,61027,61028,61029,61030,61031,61032,61033,61034,61035,61036,61037,61038,61039,61040,61042,61043,61044,61045,61046,61047,61048,61049,61050,61051,61052,61053,61054,61055,61056,61057,61059,61060,61061,61062,61063,61064,61065,61066,61067,61068,61069,61070,61071,61073,61074,61075,61247,61248,61249,61250,61251,61252,61253,61254,61255,61256,61257,61258,61259,61260,61261,61262,61263,61264,61265,61267,61268,61269,61270,61272,61273,61274,61289,61290,61291,61292,61293,61294,61296,61297,61298,61299,61300,61301,61302,61303,61304,61305,61306,61307,61308,61309,61310,61312,61313,61315,61316,61317,61318,61319,61320,61321,61322,61323,61324,61325,61326,61328,61329,61330,61331,61332,61333,61396,61407,61409,61410,61411,61412,61413,61415,61416,61418,61419,61420,61421,61422,61424,61425,61426,61427,61428,61429,61430,61431,61432,61434,61435,138834,138835,138836,138837,138838,138839,138840,138396,138740,138750,138752,141889,138748,141890,141891,141892,78919,78921,138739,141893,141894,78922,78924,78925,138301,141895,141896,141898,138440,138742,138743,141888,141900,138753,141901,141902,141903,138262,141914,138755,141904,141905,90950,138242,141915,141916,141162,141165,130436,130438,130439,130440,130441,130443,135561,135562,135563,135565,135566,135567,135569,135570,135572,130450,130451,130453,130455,130457,130458,130459,130460,130461,130462,130468,130470,135573,135574,135576,135578,141095,141096,141097,141105,141107,141108,141081,141082,141083,141084,141085,135794,137922,137923,137924,137925,137926,137927,137928,137929,137930,137931,137932,137933,137935,137936,137937,138443,138534,141023,141024,141025,137406,137407,140983,137409,137410,140929,137411,140984,141086,141088,141089,141090,141091,141092,135650,139777,134758);

-- Delete bad waypoints (for non existant creatures)
DELETE cw FROM creature_waypoints cw LEFT JOIN creature_spawns cs ON (cw.spawnid = cs.id) WHERE cw.spawnid != 0 AND cs.id IS NULL;

-- delete some event specific spawns
DELETE FROM `creature_spawns` WHERE `entry` IN (15905,15906,18927,19169,19171,19176,20102);

-- Fixed death state for Ruby Dragon
UPDATE creature_spawns SET death_state = 2 WHERE entry = 40870;

-- Fixed 1 go to have blizzlike GO ID
UPDATE gameobject_spawns SET entry = 203624 WHERE entry = 203010;
DELETE FROM gameobject_names WHERE entry = 203010;

-- deleting waypoints, it useless to have it in DB
DELETE FROM creature_names WHERE entry = 1;
DELETE FROM creature_proto WHERE entry = 1;

-- Fix minlevel for 46 maps.
UPDATE `worldmap_info` SET `minlevel` = '8' WHERE `entry` = '389';
UPDATE `worldmap_info` SET `minlevel` = '10' WHERE `entry` IN ('33', '36', '43');
UPDATE `worldmap_info` SET `minlevel` = '15' WHERE `entry` IN ('34', '47', '90');
UPDATE `worldmap_info` SET `minlevel` = '20' WHERE `entry` = '189';
UPDATE `worldmap_info` SET `minlevel` = '25' WHERE `entry` = '129';
UPDATE `worldmap_info` SET `minlevel` = '30' WHERE `entry` IN ('70', '349');
UPDATE `worldmap_info` SET `minlevel` = '35' WHERE `entry` IN ('109', '209');
UPDATE `worldmap_info` SET `minlevel` = '40' WHERE `entry` = '230';
UPDATE `worldmap_info` SET `minlevel` = '45' WHERE `entry` IN ('229', '289', '329', '429');
UPDATE `worldmap_info` SET `minlevel` = '50' WHERE `entry` IN ('309', '409', '509', '531');
UPDATE `worldmap_info` SET `minlevel` = '58' WHERE `entry` = '530';
UPDATE `worldmap_info` SET `minlevel` = '65' WHERE `entry` IN ('552', '585');
UPDATE `worldmap_info` SET `minlevel` = '66' WHERE `entry` IN ('269', '560', '576');
UPDATE `worldmap_info` SET `minlevel` = '67' WHERE `entry` IN ('553', '554', '601');
UPDATE `worldmap_info` SET `minlevel` = '68' WHERE `entry` IN ('532', '571', '619');
UPDATE `worldmap_info` SET `minlevel` = '69' WHERE `entry` = '600';
UPDATE `worldmap_info` SET `minlevel` = '70' WHERE `entry` IN ('550', '568', '608');
UPDATE `worldmap_info` SET `minlevel` = '71' WHERE `entry` = '604';
UPDATE `worldmap_info` SET `minlevel` = '72' WHERE `entry` = '599';
UPDATE `worldmap_info` SET `minlevel` = '75' WHERE `entry` IN ('575', '578', '595', '602', '658', '668');

-- Repair quest: Buying Some Time, missing kill requirement:
-- NOTE: The quest counter might not show the progress correctly unless the client cache is cleared!
UPDATE quests SET ReqKillMobOrGOId1 = '26195', ReqKillMobOrGOCount1 = '20' WHERE entry = '11938';

-- Update  'Pioneer Buckler'
UPDATE `items` SET `randomprop`=-1 WHERE (`entry`=7109);

-- Update  'Grimoire of Blood Pact (Rank 3)'
UPDATE `items` SET `allowableclass`=31488,`itemstatscount`=0,`spellid_1`=20319 WHERE (`entry`=16323);

-- Update  'Everglowing Robe'
UPDATE `items` SET `range`=0.00,`spellcooldown_4`=-1,`spellcategorycooldown_4`=-1,`spellcooldown_5`=-1,`spellcategorycooldown_5`=-1 WHERE (`entry`=19129);

-- Update  'Grimoire of Devour Magic (Rank 6)'
UPDATE `items` SET `allowableclass`=31488 WHERE (`entry`=22189);

-- Update  'Boots of Ferocity'
UPDATE `items` SET `buyprice`=97501,`sellprice`=19500 WHERE (`entry`=22472);

-- Update  'Grimoire of Intercept (Rank 2)'
UPDATE `items` SET `allowableclass`=31488,`itemstatscount`=0 WHERE (`entry`=23730);

-- Update  'Grimoire of Anguish (Rank 2)'
UPDATE `items` SET `allowableclass`=31488 WHERE (`entry`=28072);

-- Update  'General's Scaled Greaves'
UPDATE `items` SET `flags`=36864,`allowableclass`=262143,`allowablerace`=32767 WHERE (`entry`=28645);

UPDATE `db_version` SET `revision` = '142', `changeset` = '98', `arcemu_rev` = '3662';
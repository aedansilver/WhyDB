UPDATE db_version SET revision = 44, changeset = 74 WHERE db_name LIKE 'WhyDB';
DELETE FROM `vendors` WHERE `entry`=32216;
DELETE FROM `creature_formations` WHERE `spawn_id`=84537;
DELETE FROM `creature_formations` WHERE `spawn_id`=84599;
DELETE FROM `creature_formations` WHERE `spawn_id`=84607;
DELETE FROM `creature_formations` WHERE `spawn_id`=84354;
DELETE FROM `creature_formations` WHERE `spawn_id`=84586;
DELETE FROM `creature_formations` WHERE `spawn_id`=84603;
DELETE FROM `creature_waypoints` WHERE `spawnid`=1401061;
DELETE FROM `creature_waypoints` WHERE `spawnid`=83045;
DELETE FROM `creature_waypoints` WHERE `spawnid`=83046;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84579;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84635;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84637;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84772;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84792;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84794;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84810;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84816;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84840;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84854;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84855;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84864;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84865;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84867;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84871;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84873;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84876;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84881;
DELETE FROM `creature_waypoints` WHERE `spawnid`=84882;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86412;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86416;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86489;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86490;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86491;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86653;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86654;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86655;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86656;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86675;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86679;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86682;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86695;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86781;
DELETE FROM `creature_waypoints` WHERE `spawnid`=86782;
DELETE FROM `creature_waypoints` WHERE `spawnid`=1401061;
DELETE FROM `creature_waypoints` WHERE `spawnid`=1401068;



UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 26369;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 24673;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 23945;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 26838;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 26174;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 23959;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 28086;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 27608;
UPDATE `creature_spawns` SET canfly = 1 WHERE entry = 23680;



REPLACE INTO `loot_items` VALUES (6765, 45986, 36429, 13.2841, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6766, 45986, 36430, 12.9151, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6767, 45986, 36428, 11.4391, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6768, 45986, 45862, 9.59409, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6769, 45986, 36442, 7.01107, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6770, 45986, 45987, 9.22509, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6771, 45986, 45881, 5.16605, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6772, 45986, 36444, 4.05904, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6773, 45986, 36443, 3.69003, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6774, 45986, 45882, 3.32103, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6775, 45986, 45859, 1.47601, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6776, 45986, 45995, 16.6051, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6777, 45986, 45880, 20.6642, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6778, 45986, 45883, 21.4022, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6779, 45986, 45994, 21.4022, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6780, 45986, 45879, 23.2472, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6781, 45986, 36933, 24.3542, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6782, 45986, 36921, 28.0442, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6783, 45986, 36930, 31.3653, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6784, 45986, 36918, 32.1033, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6785, 45986, 36924, 34.6863, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6786, 45986, 36927, 38.7453, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6787, 45986, 11940, 91.8819, 0, 1, 1, 0 );
REPLACE INTO `loot_items` VALUES (6788, 45986, 9355, 92.2509, 0, 1, 2, 0 );


INSERT INTO `vendors` VALUES (32216, 44231, 1, 0, 0, 2550);
INSERT INTO `vendors` VALUES (32216, 44230, 1, 0, 0, 2550);
INSERT INTO `vendors` VALUES (32216, 44690, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 44689, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 44225, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 44226, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 44234, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 44235, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25473, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25528, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25531, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25529, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25533, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25527, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25477, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25532, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25475, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25471, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25470, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25476, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25472, 1, 0, 0, 0);
INSERT INTO `vendors` VALUES (32216, 25474, 1, 0, 0, 0);


UPDATE creature_names SET male_displayid = 25252 WHERE entry = 25716;
UPDATE creature_spawns SET displayid = 25252 WHERE entry = 25716;
UPDATE creature_names SET subname = '' WHERE entry = 25716;


UPDATE creature_names SET male_displayid = 26483 WHERE entry = 25988;
UPDATE creature_spawns SET displayid = 26483 WHERE entry = 25988;
UPDATE creature_names SET subname = '' WHERE entry = 25988;


UPDATE creature_names SET male_displayid = 27077 WHERE entry = 26620;
UPDATE creature_spawns SET displayid = 27077 WHERE entry = 26620;
UPDATE creature_names SET subname = '' WHERE entry = 26620;


UPDATE creature_names SET male_displayid = 19732 WHERE entry = 26628;
UPDATE creature_spawns SET displayid = 19732 WHERE entry = 26628;
UPDATE creature_names SET subname = '' WHERE entry = 26628;


UPDATE creature_names SET male_displayid = 27058 WHERE entry = 26635;
UPDATE creature_spawns SET displayid = 27058 WHERE entry = 26635;
UPDATE creature_names SET subname = '' WHERE entry = 26635;


UPDATE creature_names SET male_displayid = 26857 WHERE entry = 26636;
UPDATE creature_spawns SET displayid = 26857 WHERE entry = 26636;
UPDATE creature_names SET subname = '' WHERE entry = 26636;


UPDATE creature_names SET male_displayid = 26860 WHERE entry = 26637;
UPDATE creature_spawns SET displayid = 26860 WHERE entry = 26637;
UPDATE creature_names SET subname = '' WHERE entry = 26637;


UPDATE creature_names SET male_displayid = 27056 WHERE entry = 26638;
UPDATE creature_spawns SET displayid = 27056 WHERE entry = 26638;
UPDATE creature_names SET subname = '' WHERE entry = 26638;


UPDATE creature_names SET male_displayid = 27083 WHERE entry = 26639;
UPDATE creature_spawns SET displayid = 27083 WHERE entry = 26639;
UPDATE creature_names SET subname = '' WHERE entry = 26639;


UPDATE creature_names SET male_displayid = 19734 WHERE entry = 26641;
UPDATE creature_spawns SET displayid = 19734 WHERE entry = 26641;
UPDATE creature_names SET subname = '' WHERE entry = 26641;


UPDATE creature_names SET male_displayid = 27419 WHERE entry = 26687;
UPDATE creature_spawns SET displayid = 27419 WHERE entry = 26687;
UPDATE creature_names SET subname = '' WHERE entry = 26687;


UPDATE creature_names SET male_displayid = 27172 WHERE entry = 26705;
UPDATE creature_spawns SET displayid = 27172 WHERE entry = 26705;
UPDATE creature_names SET subname = '' WHERE entry = 26705;


UPDATE creature_names SET male_displayid = 27062 WHERE entry = 26830;
UPDATE creature_spawns SET displayid = 27062 WHERE entry = 26830;
UPDATE creature_names SET subname = '' WHERE entry = 26830;


UPDATE creature_names SET male_displayid = 27229 WHERE entry = 26871;
UPDATE creature_spawns SET displayid = 27229 WHERE entry = 26871;
UPDATE creature_names SET subname = '' WHERE entry = 26871;


UPDATE creature_names SET male_displayid = 26856 WHERE entry = 26946;
UPDATE creature_spawns SET displayid = 26856 WHERE entry = 26946;
UPDATE creature_names SET subname = '' WHERE entry = 26946;


UPDATE creature_names SET male_displayid = 24443 WHERE entry = 26965;
UPDATE creature_spawns SET displayid = 24443 WHERE entry = 26965;
UPDATE creature_names SET subname = '' WHERE entry = 26965;


UPDATE creature_names SET male_displayid = 27172 WHERE entry = 27171;
UPDATE creature_spawns SET displayid = 27172 WHERE entry = 27171;
UPDATE creature_names SET subname = '' WHERE entry = 27171;


UPDATE creature_names SET male_displayid = 27173 WHERE entry = 27278;
UPDATE creature_spawns SET displayid = 27173 WHERE entry = 27278;
UPDATE creature_names SET subname = '' WHERE entry = 27278;


UPDATE creature_names SET male_displayid = 26381 WHERE entry = 27382;
UPDATE creature_spawns SET displayid = 26381 WHERE entry = 27382;
UPDATE creature_names SET subname = '' WHERE entry = 27382;


UPDATE creature_names SET male_displayid = 24617 WHERE entry = 27401;
UPDATE creature_spawns SET displayid = 24617 WHERE entry = 27401;
UPDATE creature_names SET subname = '' WHERE entry = 27401;


UPDATE creature_names SET male_displayid = 26787 WHERE entry = 27417;
UPDATE creature_spawns SET displayid = 26787 WHERE entry = 27417;
UPDATE creature_names SET subname = '' WHERE entry = 27417;


UPDATE creature_names SET male_displayid = 27075 WHERE entry = 27431;
UPDATE creature_spawns SET displayid = 27075 WHERE entry = 27431;
UPDATE creature_names SET subname = '' WHERE entry = 27431;


UPDATE creature_names SET male_displayid = 24741 WHERE entry = 27681;
UPDATE creature_spawns SET displayid = 24741 WHERE entry = 27681;
UPDATE creature_names SET subname = '' WHERE entry = 27681;


UPDATE creature_names SET male_displayid = 27174 WHERE entry = 27701;
UPDATE creature_spawns SET displayid = 27174 WHERE entry = 27701;
UPDATE creature_names SET subname = '' WHERE entry = 27701;


UPDATE creature_names SET male_displayid = 27079 WHERE entry = 27709;
UPDATE creature_spawns SET displayid = 27079 WHERE entry = 27709;
UPDATE creature_names SET subname = '' WHERE entry = 27709;


UPDATE creature_names SET male_displayid = 25331 WHERE entry = 27714;
UPDATE creature_spawns SET displayid = 25331 WHERE entry = 27714;
UPDATE creature_names SET subname = '' WHERE entry = 27714;


UPDATE creature_names SET male_displayid = 27079 WHERE entry = 27753;
UPDATE creature_spawns SET displayid = 27079 WHERE entry = 27753;
UPDATE creature_names SET subname = '' WHERE entry = 27753;


UPDATE creature_names SET male_displayid = 24831 WHERE entry = 27821;
UPDATE creature_spawns SET displayid = 24831 WHERE entry = 27821;
UPDATE creature_names SET subname = '' WHERE entry = 27821;


UPDATE creature_names SET male_displayid = 24830 WHERE entry = 27822;
UPDATE creature_spawns SET displayid = 24830 WHERE entry = 27822;
UPDATE creature_names SET subname = '' WHERE entry = 27822;


UPDATE creature_names SET male_displayid = 24807 WHERE entry = 27839;
UPDATE creature_spawns SET displayid = 24807 WHERE entry = 27839;
UPDATE creature_names SET subname = '' WHERE entry = 27839;


UPDATE creature_names SET male_displayid = 28132 WHERE entry = 27969;
UPDATE creature_spawns SET displayid = 28132 WHERE entry = 27969;
UPDATE creature_names SET subname = '' WHERE entry = 27969;


UPDATE creature_names SET male_displayid = 26146 WHERE entry = 27970;
UPDATE creature_spawns SET displayid = 26146 WHERE entry = 27970;
UPDATE creature_names SET subname = '' WHERE entry = 27970;


UPDATE creature_names SET male_displayid = 26146 WHERE entry = 27970;
UPDATE creature_spawns SET displayid = 26146 WHERE entry = 27970;
UPDATE creature_names SET subname = '' WHERE entry = 27970;


UPDATE creature_names SET male_displayid = 26154 WHERE entry = 27971;
UPDATE creature_spawns SET displayid = 26154 WHERE entry = 27971;
UPDATE creature_names SET subname = '' WHERE entry = 27971;


UPDATE creature_names SET male_displayid = 27483 WHERE entry = 27978;
UPDATE creature_spawns SET displayid = 27483 WHERE entry = 27978;
UPDATE creature_names SET subname = '' WHERE entry = 27978;


UPDATE creature_names SET male_displayid = 26140 WHERE entry = 27972;
UPDATE creature_spawns SET displayid = 26140 WHERE entry = 27972;
UPDATE creature_names SET subname = '' WHERE entry = 27972;


UPDATE creature_names SET male_displayid = 26148 WHERE entry = 27985;
UPDATE creature_spawns SET displayid = 26148 WHERE entry = 27985;
UPDATE creature_names SET subname = '' WHERE entry = 27985;


UPDATE creature_names SET male_displayid = 25013 WHERE entry = 27996;
UPDATE creature_spawns SET displayid = 25013 WHERE entry = 27996;
UPDATE creature_names SET subname = '' WHERE entry = 27996;
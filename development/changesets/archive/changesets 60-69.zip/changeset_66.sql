UPDATE db_version SET revision = 21, changeset = 66 WHERE db_name LIKE 'WhyDB';

DELETE FROM `gameobject_spawns` WHERE `Entry` = 3000003; -- Extra door before Illidan in BT
INSERT INTO `creature_spawns` VALUES (NULL, 22917, 564, 705.732, 304.988, 354.025, 0, 0, 21135, 1882, 768, 16777472, 0, 4096, 0, 0, 0, 0, 0, 0, 0, 32632, 32633, 0); -- Illidan

DELETE FROM `gameobject_spawns` WHERE `Entry` >= 190000 AND `Entry` <= 190006; -- A bunch of custom GOs from a private server ended up in our lovely DB somehow

REPLACE INTO `gameobject_names` (`entry`, `Type`, `DisplayID`, `Name`, `spellfocus`, `sound1`) VALUES (184803, 8, 7227, "Mana Loom", 1426, 10);
INSERT INTO `gameobject_spawns` VALUES (NULL, 184803, 530, 9748.92, -7075.64, 16.7537, -1.85005, 1259722, 0, 0, 0, 1, 0, 0, 2, 0); -- Mana Loom

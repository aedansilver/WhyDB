/* changeset 69

Fixed: (patch > 3.1)

 * Xazi Smolderpipe's vendor's template
 * Nargle Lashcord's vendor's template
 * Valerie Langrom's vendor's template
 * Bragund Brightlink's vendor's template
 * All Alchemy Trainers (thx to chaostoy)
 * All Blacksmith Trainers (thx to chaostoy)
 * All Cooking Trainers (thx to chaostoy)
 * All Enchanting Trainers (thx to chaostoy)
 * All Engineering Trainers (thx to chaostoy)
 * Updated NAxxramas' worldmap_info
 * Some NPC fixes (thanks to Lich)


*/

UPDATE db_version SET revision = 28, changeset = 69 WHERE db_name LIKE 'WhyDB';


DELETE FROM vendors WHERE entry = 33922;

/* 

12000 h & 700 a :

helm - 2612
legg - 2610
body - 2611

9600 h & 550 a - 2613
7200 h & 400 a - 2609
6400 h & 350 a - 2608


*/

INSERT INTO vendors VALUES
-- Deadly Gladiator's Chain
(33922, 41086, 1, 0, 0, 2611),
(33922, 41156, 1, 0, 0, 2612),
(33922, 41204, 1, 0, 0, 2610),
-- Deadly Gladiator's Dragonhide
(33922, 41660, 1, 0, 0, 2611),
(33922, 41677, 1, 0, 0, 2612),
(33922, 41666, 1, 0, 0, 2610),
-- Deadly Gladiator's Dreadplate
(33922, 40784, 1, 0, 0, 2611),
(33922, 40824, 1, 0, 0, 2612),
(33922, 40845, 1, 0, 0, 2610),
-- Deadly Gladiator's Felweave
(33922, 41992, 1, 0, 0, 2612),
(33922, 41997, 1, 0, 0, 2611),
(33922, 42004, 1, 0, 0, 2610),
-- Deadly Gladiator's Kodohide
(33922, 41320, 1, 0, 0, 2612),
(33922, 41297, 1, 0, 0, 2610),
(33922, 41309, 1, 0, 0, 2611),
-- Deadly Gladiator's Leather
(33922, 41671, 1, 0, 0, 2612),
(33922, 41654, 1, 0, 0, 2610),
(33922, 41649, 1, 0, 0, 2611),
-- Deadly Gladiator's Linked
(33922, 41080, 1, 0, 0, 2611),
(33922, 41150, 1, 0, 0, 2612),
(33922, 41198, 1, 0, 0, 2610),
-- Deadly Gladiator's Mail
(33922, 40991, 1, 0, 0, 2611),
(33922, 41018, 1, 0, 0, 2612),
(33922, 41032, 1, 0, 0, 2610),
-- Deadly Gladiator's Mooncloth
(33922, 41853, 1, 0, 0, 2612),
(33922, 41863, 1, 0, 0, 2610),
(33922, 41858, 1, 0, 0, 2611),
-- Deadly Gladiator's Ornamented
(33922, 40905, 1, 0, 0, 2611),
(33922, 40932, 1, 0, 0, 2612),
(33922, 40938, 1, 0, 0, 2610),
-- Deadly Gladiator's Plate
(33922, 40786, 1, 0, 0, 2611),
(33922, 40823, 1, 0, 0, 2612),
(33922, 40844, 1, 0, 0, 2610),
-- Deadly Gladiator's Ringmail
(33922, 40990, 1, 0, 0, 2611),
(33922, 41012, 1, 0, 0, 2612),
(33922, 41026, 1, 0, 0, 2610),
-- Deadly Gladiator's Satin
(33922, 41914, 1, 0, 0, 2612),
(33922, 41926, 1, 0, 0, 2610),
(33922, 41920, 1, 0, 0, 2611),
-- Deadly Gladiator's Scaled
(33922, 40785, 1, 0, 0, 2611),
(33922, 40825, 1, 0, 0, 2612),
(33922, 40846, 1, 0, 0, 2610),
-- Deadly Gladiator's Silk
(33922, 41945, 1, 0, 0, 2612),
(33922, 41951, 1, 0, 0, 2611),
(33922, 41958, 1, 0, 0, 2610),
-- Deadly Gladiator's Wyrmhide
(33922, 41326, 1, 0, 0, 2612),
(33922, 41303, 1, 0, 0, 2610),
(33922, 41315, 1, 0, 0, 2611),
-- Spaulders
(33922, 41216, 1, 0, 0, 2613),
(33922, 41714, 1, 0, 0, 2613),
(33922, 40863, 1, 0, 0, 2613),
(33922, 42010, 1, 0, 0, 2613),
(33922, 41274, 1, 0, 0, 2613),
(33922, 41682, 1, 0, 0, 2613),
(33922, 41210, 1, 0, 0, 2613),
(33922, 41043, 1, 0, 0, 2613),
(33922, 41868, 1, 0, 0, 2613),
(33922, 40962, 1, 0, 0, 2613),
(33922, 40862, 1, 0, 0, 2613),
(33922, 41037, 1, 0, 0, 2613),
(33922, 41933, 1, 0, 0, 2613),
(33922, 40864, 1, 0, 0, 2613),
(33922, 41964, 1, 0, 0, 2613),
(33922, 41280, 1, 0, 0, 2613),
-- Gloves
(33922, 41142, 1, 0, 0, 2609),
(33922, 41772, 1, 0, 0, 2609),
(33922, 40806, 1, 0, 0, 2609),
(33922, 42016, 1, 0, 0, 2609),
(33922, 41286, 1, 0, 0, 2609),
(33922, 41766, 1, 0, 0, 2609),
(33922, 41136, 1, 0, 0, 2609),
(33922, 41006, 1, 0, 0, 2609),
(33922, 41873, 1, 0, 0, 2609),
(33922, 40926, 1, 0, 0, 2609),
(33922, 40804, 1, 0, 0, 2609),
(33922, 41000, 1, 0, 0, 2609),
(33922, 41939, 1, 0, 0, 2609),
(33922, 40805, 1, 0, 0, 2609),
(33922, 41970, 1, 0, 0, 2609),
(33922, 41292, 1, 0, 0, 2609),
-- Relics
(33922, 42588, 1, 0, 0, 2608),
(33922, 42583, 1, 0, 0, 2608),
(33922, 42578, 1, 0, 0, 2608),
(33922, 42852, 1, 0, 0, 2608),
(33922, 42614, 1, 0, 0, 2608),
(33922, 42620, 1, 0, 0, 2608),
(33922, 42607, 1, 0, 0, 2608),
(33922, 42602, 1, 0, 0, 2608),
(33922, 42597, 1, 0, 0, 2608),
-- Commendation of Bravery
(33922, 45706, 1, 0, 0, 2596);

DELETE FROM vendors WHERE entry IN (29523, 28992, 33921);

INSERT INTO `vendors` SET `entry`='29523', item='40736', amount='1', max_amount='-1', extended_cost='2535';
INSERT INTO `vendors` SET `entry`='29523', item='40693', amount='1', max_amount='-1', extended_cost='2524';
INSERT INTO `vendors` SET `entry`='29523', item='45827', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='29523', item='46142', amount='1', max_amount='-1', extended_cost='2651';
INSERT INTO `vendors` SET `entry`='29523', item='46143', amount='1', max_amount='-1', extended_cost='2659';
INSERT INTO `vendors` SET `entry`='29523', item='46144', amount='1', max_amount='-1', extended_cost='2655';
INSERT INTO `vendors` SET `entry`='29523', item='46145', amount='1', max_amount='-1', extended_cost='2653';
INSERT INTO `vendors` SET `entry`='29523', item='46141', amount='1', max_amount='-1', extended_cost='2657';
INSERT INTO `vendors` SET `entry`='29523', item='46205', amount='1', max_amount='-1', extended_cost='2657';
INSERT INTO `vendors` SET `entry`='29523', item='46212', amount='1', max_amount='-1', extended_cost='2659';
INSERT INTO `vendors` SET `entry`='29523', item='46207', amount='1', max_amount='-1', extended_cost='2651';
INSERT INTO `vendors` SET `entry`='29523', item='46200', amount='1', max_amount='-1', extended_cost='2651';
INSERT INTO `vendors` SET `entry`='29523', item='46199', amount='1', max_amount='-1', extended_cost='2651';
INSERT INTO `vendors` SET `entry`='29523', item='46206', amount='1', max_amount='-1', extended_cost='2657';
INSERT INTO `vendors` SET `entry`='29523', item='46201', amount='1', max_amount='-1', extended_cost='2659';
INSERT INTO `vendors` SET `entry`='29523', item='46209', amount='1', max_amount='-1', extended_cost='2659';
INSERT INTO `vendors` SET `entry`='29523', item='46210', amount='1', max_amount='-1', extended_cost='2655';
INSERT INTO `vendors` SET `entry`='29523', item='46202', amount='1', max_amount='-1', extended_cost='2655';
INSERT INTO `vendors` SET `entry`='29523', item='46203', amount='1', max_amount='-1', extended_cost='2653';
INSERT INTO `vendors` SET `entry`='29523', item='46211', amount='1', max_amount='-1', extended_cost='2653';
INSERT INTO `vendors` SET `entry`='29523', item='46204', amount='1', max_amount='-1', extended_cost='2653';
INSERT INTO `vendors` SET `entry`='29523', item='46198', amount='1', max_amount='-1', extended_cost='2657';
INSERT INTO `vendors` SET `entry`='29523', item='46208', amount='1', max_amount='-1', extended_cost='2655';
INSERT INTO `vendors` SET `entry`='29523', item='45837', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='29523', item='45836', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='29523', item='39582', amount='1', max_amount='-1', extended_cost='2496';
INSERT INTO `vendors` SET `entry`='29523', item='39578', amount='1', max_amount='-1', extended_cost='2497';
INSERT INTO `vendors` SET `entry`='29523', item='39580', amount='1', max_amount='-1', extended_cost='2498';
INSERT INTO `vendors` SET `entry`='29523', item='39581', amount='1', max_amount='-1', extended_cost='2499';
INSERT INTO `vendors` SET `entry`='29523', item='39579', amount='1', max_amount='-1', extended_cost='2495';
INSERT INTO `vendors` SET `entry`='29523', item='39597', amount='1', max_amount='-1', extended_cost='2495';
INSERT INTO `vendors` SET `entry`='29523', item='39602', amount='1', max_amount='-1', extended_cost='2497';
INSERT INTO `vendors` SET `entry`='29523', item='39593', amount='1', max_amount='-1', extended_cost='2496';
INSERT INTO `vendors` SET `entry`='29523', item='39601', amount='1', max_amount='-1', extended_cost='2496';
INSERT INTO `vendors` SET `entry`='29523', item='39591', amount='1', max_amount='-1', extended_cost='2496';
INSERT INTO `vendors` SET `entry`='29523', item='39592', amount='1', max_amount='-1', extended_cost='2495';
INSERT INTO `vendors` SET `entry`='29523', item='39583', amount='1', max_amount='-1', extended_cost='2497';
INSERT INTO `vendors` SET `entry`='29523', item='39594', amount='1', max_amount='-1', extended_cost='2497';
INSERT INTO `vendors` SET `entry`='29523', item='39595', amount='1', max_amount='-1', extended_cost='2498';
INSERT INTO `vendors` SET `entry`='29523', item='39589', amount='1', max_amount='-1', extended_cost='2498';
INSERT INTO `vendors` SET `entry`='29523', item='39604', amount='1', max_amount='-1', extended_cost='2499';
INSERT INTO `vendors` SET `entry`='29523', item='39596', amount='1', max_amount='-1', extended_cost='2499';
INSERT INTO `vendors` SET `entry`='29523', item='39590', amount='1', max_amount='-1', extended_cost='2499';
INSERT INTO `vendors` SET `entry`='29523', item='39588', amount='1', max_amount='-1', extended_cost='2495';
INSERT INTO `vendors` SET `entry`='29523', item='39603', amount='1', max_amount='-1', extended_cost='2498';
INSERT INTO `vendors` SET `entry`='29523', item='45844', amount='1', max_amount='-1', extended_cost='2630';
INSERT INTO `vendors` SET `entry`='29523', item='45845', amount='1', max_amount='-1', extended_cost='2630';
INSERT INTO `vendors` SET `entry`='29523', item='40746', amount='1', max_amount='-1', extended_cost='2536';
INSERT INTO `vendors` SET `entry`='29523', item='40737', amount='1', max_amount='-1', extended_cost='2535';
INSERT INTO `vendors` SET `entry`='29523', item='40747', amount='1', max_amount='-1', extended_cost='2536';
INSERT INTO `vendors` SET `entry`='29523', item='40504', amount='1', max_amount='-1', extended_cost='2510';
INSERT INTO `vendors` SET `entry`='29523', item='40505', amount='1', max_amount='-1', extended_cost='2509';
INSERT INTO `vendors` SET `entry`='29523', item='40506', amount='1', max_amount='-1', extended_cost='2511';
INSERT INTO `vendors` SET `entry`='29523', item='40507', amount='1', max_amount='-1', extended_cost='2512';
INSERT INTO `vendors` SET `entry`='29523', item='40503', amount='1', max_amount='-1', extended_cost='2508';
INSERT INTO `vendors` SET `entry`='29523', item='40523', amount='1', max_amount='-1', extended_cost='2508';
INSERT INTO `vendors` SET `entry`='29523', item='40521', amount='1', max_amount='-1', extended_cost='2509';
INSERT INTO `vendors` SET `entry`='29523', item='40515', amount='1', max_amount='-1', extended_cost='2510';
INSERT INTO `vendors` SET `entry`='29523', item='40520', amount='1', max_amount='-1', extended_cost='2510';
INSERT INTO `vendors` SET `entry`='29523', item='40509', amount='1', max_amount='-1', extended_cost='2510';
INSERT INTO `vendors` SET `entry`='29523', item='40514', amount='1', max_amount='-1', extended_cost='2508';
INSERT INTO `vendors` SET `entry`='29523', item='40510', amount='1', max_amount='-1', extended_cost='2509';
INSERT INTO `vendors` SET `entry`='29523', item='40516', amount='1', max_amount='-1', extended_cost='2509';
INSERT INTO `vendors` SET `entry`='29523', item='40517', amount='1', max_amount='-1', extended_cost='2511';
INSERT INTO `vendors` SET `entry`='29523', item='40512', amount='1', max_amount='-1', extended_cost='2511';
INSERT INTO `vendors` SET `entry`='29523', item='40524', amount='1', max_amount='-1', extended_cost='2512';
INSERT INTO `vendors` SET `entry`='29523', item='40518', amount='1', max_amount='-1', extended_cost='2512';
INSERT INTO `vendors` SET `entry`='29523', item='40513', amount='1', max_amount='-1', extended_cost='2512';
INSERT INTO `vendors` SET `entry`='29523', item='40508', amount='1', max_amount='-1', extended_cost='2508';
INSERT INTO `vendors` SET `entry`='29523', item='40522', amount='1', max_amount='-1', extended_cost='2511';
INSERT INTO `vendors` SET `entry`='29523', item='45360', amount='1', max_amount='-1', extended_cost='2650';
INSERT INTO `vendors` SET `entry`='29523', item='45361', amount='1', max_amount='-1', extended_cost='2658';
INSERT INTO `vendors` SET `entry`='29523', item='45362', amount='1', max_amount='-1', extended_cost='2654';
INSERT INTO `vendors` SET `entry`='29523', item='45363', amount='1', max_amount='-1', extended_cost='2652';
INSERT INTO `vendors` SET `entry`='29523', item='45364', amount='1', max_amount='-1', extended_cost='2656';
INSERT INTO `vendors` SET `entry`='29523', item='45413', amount='1', max_amount='-1', extended_cost='2656';
INSERT INTO `vendors` SET `entry`='29523', item='45412', amount='1', max_amount='-1', extended_cost='2658';
INSERT INTO `vendors` SET `entry`='29523', item='45406', amount='1', max_amount='-1', extended_cost='2650';
INSERT INTO `vendors` SET `entry`='29523', item='45414', amount='1', max_amount='-1', extended_cost='2650';
INSERT INTO `vendors` SET `entry`='29523', item='45401', amount='1', max_amount='-1', extended_cost='2650';
INSERT INTO `vendors` SET `entry`='29523', item='45411', amount='1', max_amount='-1', extended_cost='2656';
INSERT INTO `vendors` SET `entry`='29523', item='45402', amount='1', max_amount='-1', extended_cost='2658';
INSERT INTO `vendors` SET `entry`='29523', item='45408', amount='1', max_amount='-1', extended_cost='2658';
INSERT INTO `vendors` SET `entry`='29523', item='45409', amount='1', max_amount='-1', extended_cost='2654';
INSERT INTO `vendors` SET `entry`='29523', item='45403', amount='1', max_amount='-1', extended_cost='2654';
INSERT INTO `vendors` SET `entry`='29523', item='45415', amount='1', max_amount='-1', extended_cost='2652';
INSERT INTO `vendors` SET `entry`='29523', item='45410', amount='1', max_amount='-1', extended_cost='2652';
INSERT INTO `vendors` SET `entry`='29523', item='45404', amount='1', max_amount='-1', extended_cost='2652';
INSERT INTO `vendors` SET `entry`='29523', item='45405', amount='1', max_amount='-1', extended_cost='2656';
INSERT INTO `vendors` SET `entry`='29523', item='45416', amount='1', max_amount='-1', extended_cost='2654';
INSERT INTO `vendors` SET `entry`='29523', item='40692', amount='1', max_amount='-1', extended_cost='2524';
INSERT INTO `vendors` SET `entry`='29523', item='45828', amount='1', max_amount='-1', extended_cost='2607'; 

INSERT INTO `vendors` SET `entry`='28992', item='40739', amount='1', max_amount='-1', extended_cost='2535';
INSERT INTO `vendors` SET `entry`='28992', item='45830', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='28992', item='45829', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='28992', item='40748', amount='1', max_amount='-1', extended_cost='2536';
INSERT INTO `vendors` SET `entry`='28992', item='46191', amount='1', max_amount='-1', extended_cost='2669';
INSERT INTO `vendors` SET `entry`='28992', item='46189', amount='1', max_amount='-1', extended_cost='2661';
INSERT INTO `vendors` SET `entry`='28992', item='46158', amount='1', max_amount='-1', extended_cost='2661';
INSERT INTO `vendors` SET `entry`='28992', item='46183', amount='1', max_amount='-1', extended_cost='2661';
INSERT INTO `vendors` SET `entry`='28992', item='46161', amount='1', max_amount='-1', extended_cost='2669';
INSERT INTO `vendors` SET `entry`='28992', item='46184', amount='1', max_amount='-1', extended_cost='2669';
INSERT INTO `vendors` SET `entry`='28992', item='46185', amount='1', max_amount='-1', extended_cost='2665';
INSERT INTO `vendors` SET `entry`='28992', item='46160', amount='1', max_amount='-1', extended_cost='2665';
INSERT INTO `vendors` SET `entry`='28992', item='46196', amount='1', max_amount='-1', extended_cost='2663';
INSERT INTO `vendors` SET `entry`='28992', item='46159', amount='1', max_amount='-1', extended_cost='2667';
INSERT INTO `vendors` SET `entry`='28992', item='46186', amount='1', max_amount='-1', extended_cost='2667';
INSERT INTO `vendors` SET `entry`='28992', item='46157', amount='1', max_amount='-1', extended_cost='2663';
INSERT INTO `vendors` SET `entry`='28992', item='46187', amount='1', max_amount='-1', extended_cost='2663';
INSERT INTO `vendors` SET `entry`='28992', item='46192', amount='1', max_amount='-1', extended_cost='2665';
INSERT INTO `vendors` SET `entry`='28992', item='46194', amount='1', max_amount='-1', extended_cost='2667';
INSERT INTO `vendors` SET `entry`='28992', item='46123', amount='1', max_amount='-1', extended_cost='2667';
INSERT INTO `vendors` SET `entry`='28992', item='46124', amount='1', max_amount='-1', extended_cost='2661';
INSERT INTO `vendors` SET `entry`='28992', item='46125', amount='1', max_amount='-1', extended_cost='2669';
INSERT INTO `vendors` SET `entry`='28992', item='46126', amount='1', max_amount='-1', extended_cost='2665';
INSERT INTO `vendors` SET `entry`='28992', item='46127', amount='1', max_amount='-1', extended_cost='2663';
INSERT INTO `vendors` SET `entry`='28992', item='45838', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='28992', item='45839', amount='1', max_amount='-1', extended_cost='2607';
INSERT INTO `vendors` SET `entry`='28992', item='39558', amount='1', max_amount='-1', extended_cost='2485';
INSERT INTO `vendors` SET `entry`='28992', item='39560', amount='1', max_amount='-1', extended_cost='2486';
INSERT INTO `vendors` SET `entry`='28992', item='39561', amount='1', max_amount='-1', extended_cost='2487';
INSERT INTO `vendors` SET `entry`='28992', item='39564', amount='1', max_amount='-1', extended_cost='2488';
INSERT INTO `vendors` SET `entry`='28992', item='39565', amount='1', max_amount='-1', extended_cost='2489';
INSERT INTO `vendors` SET `entry`='28992', item='39545', amount='1', max_amount='-1', extended_cost='2487';
INSERT INTO `vendors` SET `entry`='28992', item='39544', amount='1', max_amount='-1', extended_cost='2486';
INSERT INTO `vendors` SET `entry`='28992', item='39557', amount='1', max_amount='-1', extended_cost='2486';
INSERT INTO `vendors` SET `entry`='28992', item='39543', amount='1', max_amount='-1', extended_cost='2486';
INSERT INTO `vendors` SET `entry`='28992', item='39553', amount='1', max_amount='-1', extended_cost='2487';
INSERT INTO `vendors` SET `entry`='28992', item='39531', amount='1', max_amount='-1', extended_cost='2487';
INSERT INTO `vendors` SET `entry`='28992', item='39539', amount='1', max_amount='-1', extended_cost='2488';
INSERT INTO `vendors` SET `entry`='28992', item='39555', amount='1', max_amount='-1', extended_cost='2488';
INSERT INTO `vendors` SET `entry`='28992', item='39548', amount='1', max_amount='-1', extended_cost='2489';
INSERT INTO `vendors` SET `entry`='28992', item='39554', amount='1', max_amount='-1', extended_cost='2485';
INSERT INTO `vendors` SET `entry`='28992', item='39538', amount='1', max_amount='-1', extended_cost='2485';
INSERT INTO `vendors` SET `entry`='28992', item='39556', amount='1', max_amount='-1', extended_cost='2489';
INSERT INTO `vendors` SET `entry`='28992', item='39542', amount='1', max_amount='-1', extended_cost='2489';
INSERT INTO `vendors` SET `entry`='28992', item='39546', amount='1', max_amount='-1', extended_cost='2488';
INSERT INTO `vendors` SET `entry`='28992', item='39547', amount='1', max_amount='-1', extended_cost='2485';
INSERT INTO `vendors` SET `entry`='28992', item='40694', amount='1', max_amount='-1', extended_cost='2524';
INSERT INTO `vendors` SET `entry`='28992', item='45846', amount='1', max_amount='-1', extended_cost='2630';
INSERT INTO `vendors` SET `entry`='28992', item='40749', amount='1', max_amount='-1', extended_cost='2536';
INSERT INTO `vendors` SET `entry`='28992', item='40495', amount='1', max_amount='-1', extended_cost='2513';
INSERT INTO `vendors` SET `entry`='28992', item='40496', amount='1', max_amount='-1', extended_cost='2515';
INSERT INTO `vendors` SET `entry`='28992', item='40499', amount='1', max_amount='-1', extended_cost='2514';
INSERT INTO `vendors` SET `entry`='28992', item='40500', amount='1', max_amount='-1', extended_cost='2516';
INSERT INTO `vendors` SET `entry`='28992', item='40502', amount='1', max_amount='-1', extended_cost='2517';
INSERT INTO `vendors` SET `entry`='28992', item='40467', amount='1', max_amount='-1', extended_cost='2514';
INSERT INTO `vendors` SET `entry`='28992', item='40466', amount='1', max_amount='-1', extended_cost='2515';
INSERT INTO `vendors` SET `entry`='28992', item='40472', amount='1', max_amount='-1', extended_cost='2515';
INSERT INTO `vendors` SET `entry`='28992', item='40460', amount='1', max_amount='-1', extended_cost='2515';
INSERT INTO `vendors` SET `entry`='28992', item='40473', amount='1', max_amount='-1', extended_cost='2514';
INSERT INTO `vendors` SET `entry`='28992', item='40461', amount='1', max_amount='-1', extended_cost='2514';
INSERT INTO `vendors` SET `entry`='28992', item='40462', amount='1', max_amount='-1', extended_cost='2516';
INSERT INTO `vendors` SET `entry`='28992', item='40493', amount='1', max_amount='-1', extended_cost='2516';
INSERT INTO `vendors` SET `entry`='28992', item='40470', amount='1', max_amount='-1', extended_cost='2517';
INSERT INTO `vendors` SET `entry`='28992', item='40471', amount='1', max_amount='-1', extended_cost='2513';
INSERT INTO `vendors` SET `entry`='28992', item='40463', amount='1', max_amount='-1', extended_cost='2513';
INSERT INTO `vendors` SET `entry`='28992', item='40494', amount='1', max_amount='-1', extended_cost='2517';
INSERT INTO `vendors` SET `entry`='28992', item='40465', amount='1', max_amount='-1', extended_cost='2517';
INSERT INTO `vendors` SET `entry`='28992', item='40468', amount='1', max_amount='-1', extended_cost='2516';
INSERT INTO `vendors` SET `entry`='28992', item='40469', amount='1', max_amount='-1', extended_cost='2513';
INSERT INTO `vendors` SET `entry`='28992', item='46313', amount='1', max_amount='-1', extended_cost='2668';
INSERT INTO `vendors` SET `entry`='28992', item='45351', amount='1', max_amount='-1', extended_cost='2660';
INSERT INTO `vendors` SET `entry`='28992', item='45355', amount='1', max_amount='-1', extended_cost='2660';
INSERT INTO `vendors` SET `entry`='28992', item='45345', amount='1', max_amount='-1', extended_cost='2660';
INSERT INTO `vendors` SET `entry`='28992', item='45356', amount='1', max_amount='-1', extended_cost='2668';
INSERT INTO `vendors` SET `entry`='28992', item='45346', amount='1', max_amount='-1', extended_cost='2668';
INSERT INTO `vendors` SET `entry`='28992', item='45347', amount='1', max_amount='-1', extended_cost='2664';
INSERT INTO `vendors` SET `entry`='28992', item='45357', amount='1', max_amount='-1', extended_cost='2664';
INSERT INTO `vendors` SET `entry`='28992', item='45352', amount='1', max_amount='-1', extended_cost='2662';
INSERT INTO `vendors` SET `entry`='28992', item='45358', amount='1', max_amount='-1', extended_cost='2666';
INSERT INTO `vendors` SET `entry`='28992', item='45348', amount='1', max_amount='-1', extended_cost='2666';
INSERT INTO `vendors` SET `entry`='28992', item='45359', amount='1', max_amount='-1', extended_cost='2662';
INSERT INTO `vendors` SET `entry`='28992', item='45349', amount='1', max_amount='-1', extended_cost='2662';
INSERT INTO `vendors` SET `entry`='28992', item='45353', amount='1', max_amount='-1', extended_cost='2664';
INSERT INTO `vendors` SET `entry`='28992', item='45354', amount='1', max_amount='-1', extended_cost='2666';
INSERT INTO `vendors` SET `entry`='28992', item='45396', amount='1', max_amount='-1', extended_cost='2666';
INSERT INTO `vendors` SET `entry`='28992', item='45397', amount='1', max_amount='-1', extended_cost='2660';
INSERT INTO `vendors` SET `entry`='28992', item='45398', amount='1', max_amount='-1', extended_cost='2668';
INSERT INTO `vendors` SET `entry`='28992', item='45399', amount='1', max_amount='-1', extended_cost='2664';
INSERT INTO `vendors` SET `entry`='28992', item='45400', amount='1', max_amount='-1', extended_cost='2662';
INSERT INTO `vendors` SET `entry`='28992', item='40695', amount='1', max_amount='-1', extended_cost='2524';
INSERT INTO `vendors` SET `entry`='28992', item='45847', amount='1', max_amount='-1', extended_cost='2630';
INSERT INTO `vendors` SET `entry`='28992', item='40738', amount='1', max_amount='-1', extended_cost='2535';



INSERT INTO `vendors` SET `entry`='33921', item='45706', amount='1', max_amount='-1', extended_cost='2596';
INSERT INTO `vendors` SET `entry`='33921', item='42565', amount='1', max_amount='-1', extended_cost='2628';
INSERT INTO `vendors` SET `entry`='33921', item='42514', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42364', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42281', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42323', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='41087', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41143', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41157', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41205', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41217', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42233', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42209', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42318', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='41773', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41678', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41667', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41661', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41715', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='40787', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='40809', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='40827', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='40848', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='40868', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42526', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42385', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42011', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41993', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='42017', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41998', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='42005', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='44422', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42353', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42333', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42538', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42228', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42496', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42589', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42584', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42579', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='41287', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41321', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41298', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41310', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41275', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41767', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41672', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41655', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41683', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41650', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='42266', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42271', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42853', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42615', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='41081', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41137', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41151', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41199', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41211', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42491', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='40993', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41007', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41019', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41033', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41044', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41874', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41854', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41864', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41869', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41859', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='42256', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='40907', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='40927', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='40933', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='40939', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='40963', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42520', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42328', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='40789', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='40807', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='40826', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='40847', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='40866', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42276', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42291', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42571', amount='1', max_amount='-1', extended_cost='2628';
INSERT INTO `vendors` SET `entry`='33921', item='42532', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42486', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='42261', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='40992', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41001', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41013', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41027', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41038', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41940', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41915', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41927', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41934', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41921', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='40788', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='40808', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='40828', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='40849', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='40869', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='42243', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42560', amount='1', max_amount='-1', extended_cost='2628';
INSERT INTO `vendors` SET `entry`='33921', item='42249', amount='1', max_amount='-1', extended_cost='2626';
INSERT INTO `vendors` SET `entry`='33921', item='42621', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='41965', amount='1', max_amount='-1', extended_cost='2470';
INSERT INTO `vendors` SET `entry`='33921', item='41946', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41971', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41953', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41959', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='42286', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42347', amount='1', max_amount='-1', extended_cost='2624';
INSERT INTO `vendors` SET `entry`='33921', item='42391', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='45983', amount='1', max_amount='-1', extended_cost='[0,500],0';
INSERT INTO `vendors` SET `entry`='33921', item='42608', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42603', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42598', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42503', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='42451', amount='1', max_amount='-1', extended_cost='2384';
INSERT INTO `vendors` SET `entry`='33921', item='44421', amount='1', max_amount='-1', extended_cost='2623';
INSERT INTO `vendors` SET `entry`='33921', item='41293', amount='1', max_amount='-1', extended_cost='2621';
INSERT INTO `vendors` SET `entry`='33921', item='41327', amount='1', max_amount='-1', extended_cost='2629';
INSERT INTO `vendors` SET `entry`='33921', item='41304', amount='1', max_amount='-1', extended_cost='2340';
INSERT INTO `vendors` SET `entry`='33921', item='41316', amount='1', max_amount='-1', extended_cost='2622';
INSERT INTO `vendors` SET `entry`='33921', item='41281', amount='1', max_amount='-1', extended_cost='2470';


/* 

    Well i wanna thanks for this great job to chaostoy :)
    i only added DELETE queries.

*/



-- Alchemy Trainer Spells

DELETE FROM trainer_spells WHERE cast_spell IN (2275, 2280, 3465, 11612, 28597, 51303);

INSERT INTO `trainer_spells` VALUES ('1215', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1215', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1215', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1215', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3603', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3603', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3603', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3603', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('17215', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17215', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17215', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17215', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16741', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16741', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16741', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16741', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1470', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1470', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1470', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1470', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5499', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5499', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5499', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5499', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11041', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11041', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11041', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11041', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5500', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5500', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5500', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5500', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1246', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1246', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1246', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1246', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16161', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16161', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16161', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16161', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2132', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2132', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2132', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2132', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11044', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11044', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11044', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11044', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11047', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11047', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11047', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11047', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3184', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3184', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3184', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3184', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16643', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16643', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16643', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16643', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11046', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11046', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11046', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11046', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4900', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4900', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4900', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4900', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2837', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2837', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2837', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2837', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3964', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3964', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3964', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3964', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16723', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16723', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16723', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16723', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11042', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11042', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11042', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11042', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5177', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5177', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5177', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5177', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3009', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3009', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3009', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3009', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16642', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16642', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16642', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16642', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4609', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4609', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4609', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4609', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2391', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2391', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2391', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2391', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3347', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3347', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3347', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3347', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4160', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4160', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4160', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4160', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4611', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4611', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4611', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4611', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('7948', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7948', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7948', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7948', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1386', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1386', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1386', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1386', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33630', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33630', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33630', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33630', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33630', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33674', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33674', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33674', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33674', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33674', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');


INSERT INTO `trainer_spells` VALUES ('18802', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18802', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18802', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18802', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18802', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19052', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19052', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19052', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19052', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19052', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16588', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16588', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16588', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16588', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16588', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26987', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26987', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26987', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26987', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26987', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26987', '51303', '0', '350000', '0', '171', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26975', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26975', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26975', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26975', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26975', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26975', '51303', '0', '350000', '0', '171', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26951', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26951', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26951', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26951', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26951', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26951', '51303', '0', '350000', '0', '171', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33588', '2275', '0', '10', '0', '171', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33588', '2280', '0', '500', '0', '171', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33588', '3465', '0', '5000', '0', '171', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33588', '11612', '0', '50000', '0', '171', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33588', '28597', '0', '100000', '0', '171', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33588', '51303', '0', '350000', '0', '171', '350', '65', '0', '1');


-- Blacksmith Trainer Spells

DELETE FROM trainer_spells WHERE cast_spell IN (2020,2021,3539,9786,29845,51298);

INSERT INTO `trainer_spells` VALUES ('17245', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17245', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17245', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17245', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('957', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('957', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('957', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('957', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('6299', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('6299', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('6299', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('6299', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16740', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16740', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16740', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16740', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('10277', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10277', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10277', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10277', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('514', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('514', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('514', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('514', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1241', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1241', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1241', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1241', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('15400', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('15400', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('15400', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('15400', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4605', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4605', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4605', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4605', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3174', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3174', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3174', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3174', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3557', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3557', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3557', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3557', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16671', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16671', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16671', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16671', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('10278', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10278', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10278', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10278', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('10266', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10266', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10266', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10266', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3136', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3136', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3136', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3136', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16724', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16724', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16724', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16724', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('10276', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10276', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10276', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10276', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5511', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5511', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5511', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5511', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16669', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16669', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16669', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16669', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4596', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4596', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4596', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4596', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2998', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2998', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2998', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2998', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1383', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1383', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1383', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1383', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3478', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3478', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3478', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3478', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4258', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4258', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4258', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4258', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('7802', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7802', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7802', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7802', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3355', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3355', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3355', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3355', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2836', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2836', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2836', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2836', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5164', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5164', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5164', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5164', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11146', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11146', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11146', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11146', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11177', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11177', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11177', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11177', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11178', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11178', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11178', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11178', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('21209', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('21209', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('21209', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('21209', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('21209', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16823', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16823', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16823', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16823', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16823', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19341', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19341', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19341', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19341', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19341', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16583', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16583', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16583', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16583', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16583', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33631', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33631', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33631', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33631', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33631', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33675', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33675', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33675', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33675', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33675', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26988', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26988', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26988', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26988', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26988', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26988', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26904', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26904', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26904', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26904', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26904', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26904', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('29924', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('29924', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('29924', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('29924', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('29924', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('29924', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26952', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26952', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26952', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26952', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26952', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26952', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('27034', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('27034', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('27034', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('27034', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('27034', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('27034', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26564', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26564', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26564', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26564', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26564', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26564', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26981', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26981', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26981', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26981', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26981', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26981', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('28694', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28694', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28694', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28694', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28694', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28694', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33591', '2020', '0', '10', '0', '164', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33591', '2021', '0', '500', '0', '164', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33591', '3539', '0', '5000', '0', '164', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33591', '9786', '0', '50000', '0', '164', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33591', '29845', '0', '100000', '0', '164', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33591', '51298', '0', '350000', '0', '164', '350', '65', '0', '1');


-- Cooking Trainer Spells

DELETE FROM trainer_spells WHERE cast_spell IN (2551,3412,51295);

INSERT INTO `trainer_spells` VALUES ('1355', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('1355', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('1430', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('1430', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('6286', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('6286', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('8306', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('8306', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('1382', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('1382', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('19185', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('19185', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('19369', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('19369', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('16719', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('16719', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('16676', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('16676', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('3067', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('3067', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('3087', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('3087', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('5159', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('5159', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('1699', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('1699', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('5482', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('5482', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('4210', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('4210', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('17246', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('17246', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('16253', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('16253', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('16277', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('16277', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('3026', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('3026', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('4552', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('4552', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('3399', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('3399', '3412', '0', '500', '0', '185', '50', '0', '0', '0');

INSERT INTO `trainer_spells` VALUES ('26989', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26989', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26989', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('26972', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26972', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26972', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('26905', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26905', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26905', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('26953', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26953', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26953', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('26931', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26931', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('26931', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('33587', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('33587', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('33587', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');

INSERT INTO `trainer_spells` VALUES ('28705', '2551', '0', '100', '0', '185', '0', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('28705', '3412', '0', '500', '0', '185', '50', '0', '0', '0');
INSERT INTO `trainer_spells` VALUES ('28705', '51295', '0', '350000', '0', '185', '350', '65', '0', '0');


-- Enchanting Trainer Spells

DELETE FROM trainer_spells WHERE cast_spell IN (7414,7415,7416,13921,28030,51312);

INSERT INTO `trainer_spells` VALUES ('3606', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3606', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3606', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3606', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11068', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11068', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11068', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11068', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19248', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19248', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19248', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19248', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16742', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16742', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16742', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16742', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11070', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11070', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11070', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11070', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11065', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11065', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11065', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11065', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16634', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16634', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16634', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16634', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11066', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11066', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11066', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11066', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16160', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16160', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16160', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16160', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11067', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11067', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11067', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11067', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11071', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11071', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11071', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11071', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5695', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5695', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5695', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5695', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19249', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19249', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19249', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19249', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5157', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5157', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5157', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5157', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1317', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1317', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1317', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1317', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16725', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16725', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16725', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16725', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4213', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4213', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4213', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4213', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('7949', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7949', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7949', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('7949', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3345', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3345', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3345', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3345', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4616', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4616', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4616', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4616', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16633', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16633', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16633', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16633', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3011', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3011', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3011', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3011', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19250', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19250', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19250', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19250', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11072', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11072', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11072', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11072', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11074', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11074', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11074', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11074', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11073', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11073', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11073', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11073', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19251', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19251', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19251', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19251', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19540', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19540', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19540', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19540', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19540', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19552', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19552', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19552', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19552', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19252', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('18773', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18773', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18773', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18773', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18773', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('18753', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18753', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18753', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18753', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18753', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33633', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33633', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33633', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33633', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33633', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33676', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33676', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33676', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33676', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33676', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26990', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26990', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26990', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26990', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26990', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26990', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26906', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26906', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26906', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26906', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26906', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26906', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26954', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26954', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26954', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26954', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26954', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26954', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('28693', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28693', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28693', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28693', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28693', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28693', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33583', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33583', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33583', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33583', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33583', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33583', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26980', '7414', '0', '10', '0', '333', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26980', '7415', '0', '500', '0', '333', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26980', '7416', '0', '5000', '0', '333', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26980', '13921', '0', '50000', '0', '333', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26980', '28030', '0', '100000', '0', '333', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26980', '51312', '0', '350000', '0', '333', '350', '65', '0', '1');

-- Engineering Trainer Spells

DELETE FROM trainer_spells WHERE cast_spell IN (4039,4040,4041,12657,30351,51305);

INSERT INTO `trainer_spells` VALUES ('17222', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17222', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17222', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17222', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1702', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1702', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1702', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1702', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3290', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3290', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3290', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3290', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16743', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16743', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16743', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16743', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11028', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11028', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11028', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11028', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11026', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11026', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11026', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11026', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3494', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3494', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3494', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3494', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11025', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11025', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11025', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11025', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11037', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11037', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11037', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11037', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('10993', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10993', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10993', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('10993', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('2857', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2857', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2857', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('2857', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('4586', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4586', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4586', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('4586', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16668', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16668', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16668', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16668', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('3412', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3412', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3412', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('3412', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16667', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16667', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16667', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16667', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('1676', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1676', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1676', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('1676', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5518', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5518', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5518', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5518', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('16726', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16726', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16726', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('16726', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11029', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11029', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11029', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11029', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11031', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11031', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11031', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11031', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('5174', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5174', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5174', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('5174', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('11017', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11017', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11017', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('11017', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('8736', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('8736', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('8736', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('8736', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');

INSERT INTO `trainer_spells` VALUES ('17634', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17634', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17634', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17634', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17634', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('18752', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18752', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18752', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18752', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18752', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('18775', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18775', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18775', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18775', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('18775', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('19576', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19576', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19576', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19576', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('19576', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('24868', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('24868', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('24868', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('24868', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('24868', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('25099', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('25099', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('25099', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('25099', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('25099', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('17637', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17637', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17637', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17637', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('17637', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33677', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33677', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33677', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33677', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33677', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26991', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26991', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26991', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26991', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26991', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26991', '51305', '0', '350000', '0', '202', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26907', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26907', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26907', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26907', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26907', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26907', '51305', '0', '350000', '0', '202', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('28697', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28697', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28697', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28697', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28697', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('28697', '51305', '0', '350000', '0', '202', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('33586', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33586', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33586', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33586', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33586', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('33586', '51305', '0', '350000', '0', '202', '350', '65', '0', '1');

INSERT INTO `trainer_spells` VALUES ('26955', '4039', '0', '10', '0', '202', '0', '5', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26955', '4040', '0', '500', '0', '202', '50', '10', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26955', '4041', '0', '5000', '0', '202', '125', '20', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26955', '12657', '0', '50000', '0', '202', '200', '35', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26955', '30351', '0', '100000', '0', '202', '275', '50', '0', '1');
INSERT INTO `trainer_spells` VALUES ('26955', '51305', '0', '350000', '0', '202', '350', '65', '0', '1');

UPDATE `worldmap_info` SET maxplayers=25 , minlevel=80 , required_quest=0 WHERE entry=533 ; 

/* NPC FIXES */

-- Sartharion
UPDATE `creature_proto` SET minlevel=83 , maxlevel=83 , minhealth=2510100 , maxhealth=2510100 , respawntime=0 WHERE entry=28860;

-- Vesperon
UPDATE `creature_proto` SET minlevel=83 , maxlevel=83 , minhealth=976150 , maxhealth=976150 , respawntime=0 WHERE entry=30449; 

-- Shadron
UPDATE `creature_proto` SET minlevel=83 , maxlevel=83 , minhealth=976150 , maxhealth=976150 , respawntime=0 WHERE entry=30451; 

-- Tenebron 
UPDATE `creature_proto` SET minlevel=83 , maxlevel=83 , minhealth=976150 , maxhealth=976150 , respawntime=0 WHERE entry=30452; 

-- Dragonflayer Handler
UPDATE `creature_proto` SET `minhealth` = '7984', `maxhealth` = '8982' WHERE `entry` =23871 LIMIT 1 ; 


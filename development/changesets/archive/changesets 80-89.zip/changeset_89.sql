/*
 ================================
 == Changeset # 89 Information ==
 ==       by ClaudeNegm        ==
 ================================'

$ Rev.: 98 | Changeset: 89 | game_version: 3.2.2a | arcemu_rev: 3055 | latest_update: 3055_ah.sql $

Fixed the limit time since it's supposed to be in millisecond not in second.
Redone Skinning Trainers.
Redone NPC Flags, supposed to work good now.
Fixed console errors.
Fixed "Old world triggers".
Rocket Car Parts quest loots fixed.
Fixed training dummies.
Added 6 Missed items.
Updated all the tables to arcemu rev 3055.
Set NPC `Ebon Blade Gargoyle` to fly.

$$ Released 25/12/2009 { Merry Christmas! } $$

*/

/* ======================
=== NPC Flags redone  ===
===   by ClaudeNegm   ===
====================== */
# UNIT_NPC_FLAG_NONE {Reset npc flags}
UPDATE `creature_proto` SET `npcflags` = 0;

# UNIT_NPC_FLAG_GOSSIP
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 1 WHERE (`entry` IN (SELECT `creatureid` FROM `npc_gossip_textid`)) OR (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `info_str` = 'Directions'));

# UNIT_NPC_FLAG_QUESTGIVER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 2 WHERE (`entry` IN (SELECT DISTINCT `id` FROM `creature_quest_starter`)) OR (`entry` IN (SELECT DISTINCT `id` FROM `creature_quest_finisher`));

# UNIT_NPC_FLAG_TRAINER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 16 WHERE (`entry` IN (SELECT `entry` FROM `trainer_defs`)) AND (`entry` IN (SELECT `entry` FROM `trainer_spells`));

# UNIT_NPC_FLAG_TRAINER_CLASS
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 32 WHERE (`entry` IN (SELECT `entry` FROM `trainer_defs` WHERE `req_class` > 0)) AND (`npcflags` = `npcflags` | 16) /*(`entry` IN (SELECT `entry` FROM `trainer_spells`))*/;

# UNIT_NPC_FLAG_TRAINER_PROF
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 64 WHERE (`entry` IN (SELECT `entry` FROM `trainer_defs` WHERE `trainer_type` = 2)) AND (`npcflags` = `npcflags` | 16) /*(`entry` IN (SELECT `entry` FROM `trainer_spells`))*/;

# UNIT_NPC_FLAG_VENDOR
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 128 WHERE `entry` IN (SELECT DISTINCT `entry` FROM `vendors`);

# UNIT_NPC_FLAG_VENDOR_AMMO
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 256 WHERE (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Ammunition%')) AND (`npcflags` = `npcflags` | 128);;

# UNIT_NPC_FLAG_VENDOR_FOOD
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 512 WHERE (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE "%food%" OR `subname` LIKE "%drink%")) AND (`npcflags` = `npcflags` | 128);

# UNIT_NPC_FLAG_VENDOR_POISON
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 1024 WHERE (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE "%poison%" OR `subname` LIKE "%potion%")) AND (`npcflags` = `npcflags` | 128);

# UNIT_NPC_FLAG_VENDOR_REAGENT
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 2048 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Reagent%');

# UNIT_NPC_FLAG_ARMORER [Thanks to MesoX for the armorers ids]
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 4096 WHERE (`entry` IN (3,6,40,43,46,54,66,68,69,74,78,79,80,89,92,94,95,97,98,103,113,115,116,117,118,119,121,124,125,126,127,151,167,190,222,225,226,228,789,793,836,896,945,954,956,959,980,981,984,1104,1146,1147,1198,1213,1214,1238,1240,1243,1249,1273,1287,1289,1291,1294,1295,1296,1297,1298,1299,1309,1310,1312,1314,1315,1319,1320,1322,1323,1324,1333,1339,1341,1348,1349,1350,1362,1381,1407,1441,1450,1454,1459,1461,1462,1469,1471,1645,1668,1669,1686,1687,1690,1695,1698,2046,2113,2116,2117,2135,2136,2137,2482,2483,2679,2839,2840,2843,2844,2845,2847,2849,2997,2999,3000,3015,3018,3019,3020,3021,3022,3023,3053,3073,3074,3075,3077,3078,3079,3080,3088,3092,3093,3095,3097,3159,3160,3161,3162,3163,3165,3166,3167,3177,3314,3315,3316,3317,3319,3321,3322,3330,3331,3343,3349,3356,3359,3360,3361,3392,3409,3410,3477,3479,3483,3486,3488,3491,3492,3493,3522,3528,3530,3532,3534,3536,3537,3539,3543,3552,3553,3554,3588,3589,3590,3591,3592,3609,3610,3611,3612,3613,3658,3682,3683,3684,3951,3952,3953,4043,4085,4086,4164,4171,4172,4173,4175,4177,4180,4183,4184,4185,4186,4187,4188,4203,4231,4232,4233,4234,4235,4236,4240,4257,4259,4556,4557,4558,4559,4560,4569,4570,4580,4592,4597,4600,4601,4602,4603,4604,4883,4884,4886,4888,4889,4890,4892,5102,5103,5106,5107,5108,5119,5120,5121,5122,5123,5125,5126,5129,5133,5152,5155,5156,5170,5411,5508,5509,5510,5512,5754,5812,5816,5819,5820,5821,6028,6300,7852,7976,8129,8131,8159,8161,8176,8358,8359,8360,8398,8878,9179,9544,9548,9549,9551,9552,9553,9555,10293,10361,10369,10379,10380,10856,10857,11137,11182,11183,11184,11278,11703,12023,12024,12029,12045,12777,12778,12782,12784,12785,12788,12792,12799,12942,13216,13217,13218,13219,14301,14337,14371,14581,14624,14737,14753,14754,14921,15126,15127,15176,15289,15291,15292,15315,15400,16186,16257,16258,16260,16261,16263,16274,16376,16388,16528,16583,16619,16620,16623,16625,16626,16631,16632,16636,16637,16666,16670,16678,16691,16693,16714,16715,16716,16735,16747,16750,16753,16762,16765,16823,16917,16918,16919,17245,17412,17518,17655,17667,17904,17929,17930,18010,18011,18278,18382,18426,18672,18926,18962,18997,19001,19011,19012,19043,19047,19056,19236,19238,19239,19240,19314,19315,19333,19339,19342,19351,19370,19373,19383,19436,19452,19473,19479,19499,19517,19520,19526,19530,19536,19561,19575,19662,19694,19879,20082,20112,20231,20242,20463,20613,20616,20890,20917,21086,21112,21183,21474,21485,21685,22099,22225,22227,22476,22491,23367,23381,23373,19,31,15909,22264,23007,23144,23159,23571,23724,23897,24780,24843,24935,24995,25010,25019,25051,25082,25196,25046,26301,26304,26305,26306,26308,26309,26393,26394,26396,26397,27667,27711,28344,32639,28500,27011,23735,23862,23908,24028,24052,24188,24330,24347,25206,25274,25314,26081,26229,26599,26600,26697,26707,26898,26901,26934,27019,27037,27045,27055,27062,27067,27134,27139,27151,27185,27188,27267,27943,28040,28716,28722,28760,28796,28797,28800,28813,28855,28871,28943,28989,28990,28991,28992,28994,28995,28997,29014,29035,29252,29253,29288,29476,29491,29493,29494,29496,29497,29499,29523,29538,29539,29540,29541,29688,29702,29703,29907,29923,29945,29964,29969,30006,30067,30241,30253,30336,30345,30434,30436,30572,30825,31024,31027,31115,31776,31781,31804,31805,31863,31864,31865,32253,32381,32382,32383,32385,32477,32594,32641,32832,32834,33594,33599,33669,33921,33922,33923,33925,33926,33927,34036,34037,34058,34059,34061,34062,34073,34074,34077,34082,34083,34087,34092,34252,26051,26053,26059,26068,26107,26108)) AND (`npcflags` = `npcflags` | 128);

# UNIT_NPC_FLAG_TAXIVENDOR
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 8192 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Bat Handler%' OR `subname` LIKE '%Wind Rider Master%' OR subname LIKE '%Hippogryph Master%' OR subname LIKE '%Gryphon Master%' OR subname LIKE '%Dragonhawk Master%' OR subname LIKE '%Flight Master%' OR subname LIKE '%Emerald Circle Flight Master%');

# UNIT_NPC_FLAG_SPIRITHEALER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 16384 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `name` = 'Spirit Healer');

# UNIT_NPC_FLAG_INNKEEPER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 65536 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Innkeeper%');

# UNIT_NPC_FLAG_BANKER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 131072 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Banker%');

# UNIT_NPC_FLAG_ARENACHARTER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 262144 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Arena Organizer%' OR `name` LIKE '%Arena Organizer%');

# UNIT_NPC_FLAG_TABARDCHANGER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 524288 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` = 'Guild Master');

# UNIT_NPC_FLAG_BATTLEFIELDPERSON
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 1048576 WHERE (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` LIKE '%Battlemaster%' OR `info_str` = 'Interact'));

# UNIT_NPC_FLAG_AUCTIONEER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 2097152 WHERE (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `name` LIKE '%Auctioneer%' OR `subname` LIKE '%Auctioneer%'))/* AND (npcflags != npcflags | 2097152)*/;

# UNIT_NPC_FLAG_STABLEMASTER
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 4194304 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` = 'Stable Master');

# UNIT_NPC_FLAG_GUILD_BANK
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 8388608 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `subname` = 'Guild Banker');

# UNIT_NPC_FLAG_SPELLCLICK
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 16777216 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `info_str` = 'vehichleCursor');

# Add gossip flag to NPCs having `trainers` and `vendors` flags.
UPDATE `creature_proto` SET `npcflags` = `npcflags` + 1  WHERE  (npcflags = npcflags | 16) AND (npcflags = npcflags | 128) AND (npcflags != npcflags | 1) AND (`entry` NOT IN (SELECT `creatureid` FROM `npc_gossip_textid`));
# UPDATE `creature_proto` SET `npcflags` = `npcflags` + 1  WHERE  (npcflags = npcflags | 65536) AND (npcflags != npcflags | 1);


# Set NPC `Ebon Blade Gargoyle` to fly
UPDATE `creature_spawns` SET `CanFly` = 1 WHERE `entry` = 32472;

/*
== ======================= ==
==  Skinning Trainers Fix  ==
==       By ClaudeNegm     ==
== ======================= ==

Please report any bug on `http://whydb.org`
*/

DELETE FROM `trainer_spells` WHERE `entry` IN (1292, 6287, 6288, 6289, 6290, 6291, 6292, 6295, 6306, 6387, 7087, 7088, 7089, 8144, 12030, 16273, 16692, 16763, 17441, 18755, 18777, 19180, 6242, 8777, 27000, 26913, 26963, 26986, 28696, 33641, 33683);

-- `Maris Granger` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('1292','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('1292','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('1292','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('1292','8619','0','500','8613','393','50','0','8613','0');

-- `Radnaal Maneweaver` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6287','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6287','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6287','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6287','8619','0','500','8613','393','50','0','8613','0');

-- `Jayla` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6288','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6288','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6288','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6288','8619','0','500','8613','393','50','0','8613','0');

-- `Rand Rhobart` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6289','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6289','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6289','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6289','8619','0','500','8613','393','50','0','8613','0');

-- `Yonn Deepcut` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6290','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6290','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6290','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6290','8619','0','500','8613','393','50','0','8613','0');

-- `Balthus Stoneflayer` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6291','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6291','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6291','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6291','8619','0','500','8613','393','50','0','8613','0');

-- `Eladriel` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6292','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6292','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6292','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6292','8619','0','500','8613','393','50','0','8613','0');

-- `Wilma Ranthal` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6295','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6295','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6295','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6295','8619','0','500','8613','393','50','0','8613','0');

-- `Helene Peltskinner` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6306','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6306','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6306','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6306','8619','0','500','8613','393','50','0','8613','0');

-- `Dranh` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('6387','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('6387','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('6387','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('6387','8619','0','500','8613','393','50','0','8613','0');

-- `Killian Hagey` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('7087','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('7087','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('7087','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('7087','8619','0','500','8613','393','50','0','8613','0');

-- `Thuwd` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('7088','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('7088','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('7088','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('7088','8619','0','500','8613','393','50','0','8613','0');

-- `Mooranta` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('7089','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('7089','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('7089','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('7089','8619','0','500','8613','393','50','0','8613','0');

-- `Kulleg Stonehorn` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('8144','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('8144','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('8144','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('8144','8619','0','500','8613','393','50','0','8613','0');

-- `Malux` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('12030','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('12030','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('12030','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('12030','8619','0','500','8613','393','50','0','8613','0');

-- `Mathreyn` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('16273','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('16273','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('16273','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('16273','8619','0','500','8613','393','50','0','8613','0');

-- `Tyn` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('16692','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('16692','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('16692','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('16692','8619','0','500','8613','393','50','0','8613','0');

-- `Remere` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('16763','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('16763','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('16763','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('16763','8619','0','500','8613','393','50','0','8613','0');

-- `Gurf` - `Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('17441','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('17441','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('17441','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('17441','8619','0','500','8613','393','50','0','8613','0');

-- `Moorutu` - `Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('18755','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('18755','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('18755','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('18755','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('18755','32679','0','100000','10768','393','275','40','10768','0');

-- `Jelena Nightsky` - `Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('18777','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('18777','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('18777','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('18777','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('18777','32679','0','100000','10768','393','275','40','10768','0');

-- `Seymour` - `Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('19180','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('19180','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('19180','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('19180','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('19180','32679','0','100000','10768','393','275','40','10768','0');

-- `Trapper Jack` - `Grand Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('27000','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('27000','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('27000','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('27000','50307','0','350000','32678','393','350','55','32678','0');
REPLACE INTO `trainer_spells` VALUES ('27000','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('27000','32679','0','100000','10768','393','275','40','10768','0');

-- `Frederic Burrhus` - `Grand Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('26913','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('26913','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('26913','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('26913','50307','0','350000','32678','393','350','55','32678','0');
REPLACE INTO `trainer_spells` VALUES ('26913','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('26913','32679','0','100000','10768','393','275','40','10768','0');

-- `Roberta Jacks` - `Grand Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('26963','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('26963','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('26963','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('26963','50307','0','350000','32678','393','350','55','32678','0');
REPLACE INTO `trainer_spells` VALUES ('26963','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('26963','32679','0','100000','10768','393','275','40','10768','0');

-- `Tiponi Stormwhisper` - `Grand Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('26986','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('26986','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('26986','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('26986','50307','0','350000','32678','393','350','55','32678','0');
REPLACE INTO `trainer_spells` VALUES ('26986','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('26986','32679','0','100000','10768','393','275','40','10768','0');

-- `Derik Marks` - `Grand Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('28696','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('28696','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('28696','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('28696','50307','0','350000','32678','393','350','55','32678','0');
REPLACE INTO `trainer_spells` VALUES ('28696','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('28696','32679','0','100000','10768','393','275','40','10768','0');

-- `Dremm` - `Master Skinning Trainer`
REPLACE INTO `trainer_spells` VALUES ('33683','8615','0','10','0','0','0','0','0','1');
REPLACE INTO `trainer_spells` VALUES ('33683','10769','0','50000','8618','393','200','25','8618','0');
REPLACE INTO `trainer_spells` VALUES ('33683','8620','0','5000','8617','393','125','10','8617','0');
REPLACE INTO `trainer_spells` VALUES ('33683','8619','0','500','8613','393','50','0','8613','0');
REPLACE INTO `trainer_spells` VALUES ('33683','32679','0','100000','10768','393','275','40','10768','0');

# Add some items needed for that quest: <http://www.wowhead.com/?quest=1110 {Rocket Car Parts}>
REPLACE INTO loot_gameobjects VALUES (NULL, 19869, 5798, 100, 0, 0, 0, 1, 1, 0);
REPLACE INTO loot_gameobjects VALUES (NULL, 19870, 5798, 100, 0, 0, 0, 1, 1, 0);
REPLACE INTO loot_gameobjects VALUES (NULL, 19871, 5798, 100, 0, 0, 0, 1, 1, 0);
REPLACE INTO loot_gameobjects VALUES (NULL, 19872, 5798, 100, 0, 0, 0, 1, 1, 0);
REPLACE INTO loot_gameobjects VALUES (NULL, 19873, 5798, 100, 0, 0, 0, 1, 1, 0);

# OldWorld Trigger (DO NOT DELETE) { Fixed, set them as invisible and friendly }
UPDATE `creature_spawns` SET `flags` = 33554434, `faction` = 35 WHERE `entry` = 15384;

-- Limit Time is totally destroyed in the current table, let's fix it up a bit...
UPDATE `quests` SET `LimitTime`='7200000' WHERE `LimitTime`='7200'; -- 2hrs
UPDATE `quests` SET `LimitTime`='3600000' WHERE `LimitTime`='3600'; -- 1hr
UPDATE `quests` SET `LimitTime`='2700000' WHERE `LimitTime`='2700'; -- 45mins
UPDATE `quests` SET `LimitTime`='1800000' WHERE `LimitTime`='1800'; -- 30mins
UPDATE `quests` SET `LimitTime`='1500000' WHERE `LimitTime`='1500'; -- 25mins
UPDATE `quests` SET `LimitTime`='900000' WHERE `LimitTime`='900'; -- 15mins
UPDATE `quests` SET `LimitTime`='720000' WHERE `LimitTime`='720'; -- 12mins
UPDATE `quests` SET `LimitTime`='600000' WHERE `LimitTime`='60000'; -- 10 mins
UPDATE `quests` SET `LimitTime`='540000' WHERE `LimitTime`='540'; -- 9mins
UPDATE `quests` SET `LimitTime`='360000' WHERE `LimitTime`='360'; -- 6mins
UPDATE `quests` SET `LimitTime`='300000' WHERE `LimitTime`='300'; -- 5mins
UPDATE `quests` SET `LimitTime`='300000' WHERE `entry`='3364';  -- 5mins
UPDATE `quests` SET `LimitTime`='240000' WHERE `LimitTime`='240'; -- 4mins
UPDATE `quests` SET `LimitTime`='90000' WHERE `LimitTime`='90'; -- 1.5mins
UPDATE `quests` SET `LimitTime`='45000' WHERE `LimitTime`='45'; -- 0.75mins

# Training Dummy fixes
UPDATE `creature_proto` SET `isTrainingDummy` = '1' WHERE (`entry` IN (4952, 1921, 24792, 32542, 25297, 32546, 32666, 31144, 17059, 17060, 17578, 31146, 32547, 32541, 32545, 32667, 33229, 19139, 16211, 25225, 18504, 30527, 5652, 32543, 5723, 2674, 12426, 12385, 11875, 2673, 32542, 32546, 32666, 31144, 31146, 32545, 32541, 32667, 30527, 32543, 32547)) AND (`entry` IN (SELECT `entry` FROM `creature_names` WHERE `male_displayid` = '3019'));

-- Fix errors displayed on console <Thanks to Kinetic>
DELETE FROM `trainer_spells` WHERE (`learn_spell`='47861');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='47862');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='57595');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='704');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='11717');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18879');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18880');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18881');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18930');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18931');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='18932');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='27226');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='27264');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='30911');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='30912');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='47828');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='47829');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='7659');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='27266');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='47951');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='60931');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='2870');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='8166');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='778');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='9749');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='9907');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='17390');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='17391');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='17392');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='26993');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='27011');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='48475');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='48476');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='51376');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='51378');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='51379');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='51408');
DELETE FROM `trainer_spells` WHERE (`learn_spell`='07658');
DELETE FROM `trainer_spells` WHERE (`entry`='18804') AND (`cast_spell`='51377') AND (`learn_spell`='0') LIMIT 1;

# Add some missing items
REPLACE INTO `items` VALUES ('49312', '4', '0', '-1', 'Purified Onyxia Blood Talisman', '30764', '4', '0', '0', '184123', '46030', '12', '-1', '-1', '232', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '3', '14', '95', '12', '60', '46', '89', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '15', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '-1', '0', '-1', '0', '1', '0', '-1', '0', '-1', '0', '1', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', '', '0', '0', '0', '0', '0', '3', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '375', '0', '0', '0', '0');
REPLACE INTO `items` VALUES ('49343', '15', '2', '-1', 'Spectral Tiger Cub', '63022', '3', '64', '0', '0', '0', '0', '-1', '-1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '55884', '0', '-1', '-1', '0', '-1', '68810', '6', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', 'Teaches you how to summon this companion.', '0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '4096', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0');
REPLACE INTO `items` VALUES ('49362', '15', '2', '-1', 'Onyxian Whelpling', '51621', '1', '134217792', '0', '0', '0', '0', '-1', '-1', '30', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '55884', '0', '0', '-1', '0', '-1', '69002', '6', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', 'Teaches you how to summon this companion.', '0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '4096', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0');
REPLACE INTO `items` VALUES ('49665', '15', '2', '-1', 'Pandaren Monk', '62969', '3', '134250560', '0', '0', '0', '0', '-1', '-1', '20', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '55884', '0', '0', '-1', '0', '-1', '69541', '6', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', 'Teaches you how to summon this companion.', '0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '4096', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0');
REPLACE INTO `items` VALUES ('49693', '15', '2', '-1', 'Lil\' Phylactery', '31577', '3', '134250560', '0', '0', '0', '0', '-1', '-1', '20', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '55884', '0', '0', '-1', '0', '-1', '69677', '6', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', 'Teaches you how to summon this companion.', '0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '4096', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0');
REPLACE INTO `items` VALUES ('49703', '15', '0', '-1', 'Perpetual Purple Firework', '34282', '4', '0', '0', '0', '0', '0', '-1', '-1', '20', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '30161', '0', '0', '30000', '0', '0', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '0', '0', '0', '-1', '0', '-1', '1', '', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '0', '0');

# Found this update in arcemu sqls
UPDATE `items` SET `flags` = '268435520' WHERE `name1` LIKE '%Scroll of Enchant%';
UPDATE `items` SET `bagfamily` = 0 WHERE `bagfamily` = 8192;
UPDATE `items` SET `bagfamily` = 8192 WHERE `entry` IN (37836, 43308, 44990, 43589, 20558, 42425, 29024, 41596, 43016, 20559, 20560, 43228, 40753, 40752, 45624, 29434 );

/* Structure updates to 3055 */

# auctionhouse
ALTER TABLE `auctionhouse` CHANGE `group` `ahgroup` INT(32) DEFAULT '0' NOT NULL;

# ai_agents
ALTER TABLE `ai_agents` DROP PRIMARY KEY, ADD PRIMARY KEY (`entry`,`type`,`spell`);

# creature_names
ALTER TABLE `creature_names` CHANGE `killcredit2` `killcredit2` int(10) unsigned NOT NULL DEFAULT '0';

# creature_proto
ALTER TABLE `creature_proto` 
DROP COLUMN `FlagsExtra`, 
ADD COLUMN `summonguard` int UNSIGNED DEFAULT '0' NOT NULL after `guardtype`, 
CHANGE `attacktype` `attacktype` int(4) NOT NULL DEFAULT '0', 
CHANGE `combat_reach` `combat_reach` float NOT NULL DEFAULT '0', 
CHANGE `bounding_radius` `bounding_radius` float NOT NULL DEFAULT '0', 
CHANGE `money` `money` int(30) NOT NULL DEFAULT '0', 
CHANGE `invisibility_type` `invisibility_type` int(30) unsigned NOT NULL, 
CHANGE `death_state` `death_state` int(30) unsigned NOT NULL, 
CHANGE `extra_a9_flags` `extra_a9_flags` int(30) NOT NULL DEFAULT '0', 
CHANGE `spell1` `spell1` int(30) NOT NULL DEFAULT '0', 
CHANGE `spell2` `spell2` int(30) NOT NULL DEFAULT '0', 
CHANGE `spell3` `spell3` int(30) NOT NULL DEFAULT '0', 
CHANGE `spell4` `spell4` int(30) NOT NULL DEFAULT '0', 
CHANGE `spell_flags` `spell_flags` int(30) NOT NULL DEFAULT '0';
/* Some records */
REPLACE  INTO `creature_proto`(`entry`,`minlevel`,`maxlevel`,`faction`,`minhealth`,`maxhealth`,`mana`,`scale`,`npcflags`,`attacktime`,`attacktype`,`mindamage`,`maxdamage`,`can_ranged`,`rangedattacktime`,`rangedmindamage`,`rangedmaxdamage`,`respawntime`,`armor`,`resistance1`,`resistance2`,`resistance3`,`resistance4`,`resistance5`,`resistance6`,`combat_reach`,`bounding_radius`,`auras`,`boss`,`money`,`invisibility_type`,`death_state`,`walk_speed`,`run_speed`,`fly_speed`,`extra_a9_flags`,`spell1`,`spell2`,`spell3`,`spell4`,`spell_flags`,`modImmunities`,`isTrainingDummy`,`guardtype`) values (32775,1,80,35,5,5,0,0,0,1500,0,0,0,0,0,0,0,360000,0,0,0,0,0,0,0,1,2.5,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(32776,1,80,35,5,5,0,0,0,1500,0,0,0,0,0,0,0,360000,0,0,0,0,0,0,0,1,2.5,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31897,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31896,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31895,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31894,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31893,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0),(31883,1,1,35,64,64,0,1,16777216,2000,0,1,1,0,0,0,0,360000,1,0,0,0,0,0,0,1,0,'0',0,0,0,0,2.5,8,14,0,0,0,0,0,0,0,0,0);

# creature_spawns
ALTER TABLE `creature_spawns`
CHANGE `entry` `entry` int(30) NOT NULL, CHANGE `map` `map` int(30) NOT NULL, 
CHANGE `movetype` `movetype` int(30) NOT NULL DEFAULT '0',
CHANGE `faction` `faction` int(30) NOT NULL DEFAULT '14',
CHANGE `flags` `flags` int(30) NOT NULL DEFAULT '0',
CHANGE `bytes0` `bytes0` int(30) NOT NULL DEFAULT '0',
CHANGE `bytes1` `bytes1` int(30) NOT NULL DEFAULT '0',
CHANGE `bytes2` `bytes2` int(30) NOT NULL DEFAULT '0',
CHANGE `emote_state` `emote_state` int(30) NOT NULL DEFAULT '0',
CHANGE `npc_respawn_link` `npc_respawn_link` int(30) NOT NULL DEFAULT '0',
CHANGE `channel_spell` `channel_spell` int(30) NOT NULL DEFAULT '0', 
CHANGE `channel_target_sqlid` `channel_target_sqlid` int(30) NOT NULL DEFAULT '0',
CHANGE `channel_target_sqlid_creature` `channel_target_sqlid_creature` int(30) NOT NULL DEFAULT '0',
CHANGE `standstate` `standstate` int(10) NOT NULL DEFAULT '0',
CHANGE `CanFly` `CanFly` smallint(3) NOT NULL DEFAULT '0';

# creature_staticspawns
DROP TABLE IF EXISTS `creature_staticspawns`;
CREATE TABLE `creature_staticspawns` (
  `id` int(30) unsigned NOT NULL AUTO_INCREMENT,
  `entry` int(30) NOT NULL,
  `Map` int(30) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `o` float NOT NULL,
  `movetype` int(30) NOT NULL DEFAULT '0',
  `displayid` int(30) unsigned NOT NULL DEFAULT '0',
  `factionid` int(30) NOT NULL DEFAULT '35',
  `flags` int(30) NOT NULL DEFAULT '0',
  `bytes0` int(30) NOT NULL DEFAULT '0',
  `bytes1` int(30) NOT NULL DEFAULT '0',
  `bytes2` int(30) NOT NULL DEFAULT '0',
  `emote_state` int(30) NOT NULL DEFAULT '0',
  `npc_respawn_link` int(30) NOT NULL DEFAULT '0',
  `channel_spell` int(30) NOT NULL DEFAULT '0',
  `channel_target_sqlid` int(30) NOT NULL DEFAULT '0',
  `channel_target_sqlid_creature` int(30) NOT NULL DEFAULT '0',
  `standstate` int(10) NOT NULL DEFAULT '0',
  `mountdisplayid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot1item` int(10) unsigned NOT NULL DEFAULT '0',
  `slot2item` int(10) unsigned NOT NULL DEFAULT '0',
  `slot3item` int(10) unsigned NOT NULL DEFAULT '0',
  `CanFly` smallint(3) NOT NULL DEFAULT '0',
  `phase` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Spawn System';

# db_version
DROP TABLE IF EXISTS `db_version`;
CREATE TABLE `db_version` (
  `db_name` varchar(255) COLLATE latin1_general_ci NOT NULL COMMENT 'Name of the database',
  `revision` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'svn revision number',
  `changeset` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'changeset number',
  `game_version` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `arcemu_rev` int(10) unsigned NOT NULL,
  `latest_update` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `last_changeset_by` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT ''  COMMENT 'last changeset creator',
  KEY `db_name` (`db_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
INSERT INTO `db_version` VALUES ('WhyDB', '98', '89', '3.2.2a', '3055', '3055_ah.sql','ClaudeNegm');

# gameobject_names {Some records}
REPLACE INTO `gameobject_names` VALUES ('186812', '22', '7537', 'Refreshment Table', '', '', '', '43988', '50', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0');
REPLACE INTO `gameobject_names` VALUES ('186811', '18', '7620', 'Refreshment Portal', '', '', '', '3', '43985', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0');
REPLACE INTO `gameobject_names` VALUES ('181622', '18', '7358', 'Soul Portal', '', '', '', '3', '29886', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0');
REPLACE INTO `gameobject_names` VALUES ('181621', '22', '7359', 'Soulwell', '', '', '', '34130', '10', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0');
REPLACE INTO `gameobject_names` VALUES ('194675', '11', '8587', 'UL_TRAM', '', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0');

# gameobject_quest_item_binding
ALTER TABLE `gameobject_quest_item_binding` 
DROP PRIMARY KEY, 
CHANGE `entry` `entry` int(11) NOT NULL DEFAULT '0',
CHANGE `quest` `quest` int(11) NOT NULL DEFAULT '0',
CHANGE `item` `item` int(11) NOT NULL DEFAULT '0',
CHANGE `item_count` `item_count` int(11) NOT NULL DEFAULT '0',
ADD PRIMARY KEY (`entry`,`item`,`quest`);

# gameobject_quest_pickup_binding
ALTER TABLE `gameobject_quest_pickup_binding`   
CHANGE `entry` `entry` int(11) NOT NULL DEFAULT '0',
CHANGE `quest` `quest` int(11) NOT NULL DEFAULT '0',
CHANGE `required_count` `required_count` int(11) NOT NULL DEFAULT '0';

# gameobject_spawns
ALTER TABLE `gameobject_spawns` CHANGE `id` `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
DELETE FROM `gameobject_spawns` WHERE `id` IN (50337, 50338, 50339) AND `entry` = 194675;

# gameobject_staticspawns
DROP TABLE IF EXISTS `gameobject_staticspawns`;
CREATE TABLE `gameobject_staticspawns` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `entry` int(30) NOT NULL,
  `map` int(11) NOT NULL DEFAULT '0',
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `facing` float NOT NULL,
  `o` float NOT NULL,
  `o1` float NOT NULL,
  `o2` float NOT NULL,
  `o3` float NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `flags` int(30) NOT NULL DEFAULT '0',
  `faction` int(11) NOT NULL DEFAULT '0',
  `scale` float NOT NULL,
  `respawnNpcLink` int(11) NOT NULL DEFAULT '0',
  `phase` int(10) unsigned NOT NULL DEFAULT '1',
  `overrides` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Spawn System';

# item_quest_association
ALTER TABLE `item_quest_association`
CHANGE `item` `item` int(11) NOT NULL DEFAULT '0',
CHANGE `quest` `quest` int(11) NOT NULL DEFAULT '0',
CHANGE `item_count` `item_count` int(11) NOT NULL DEFAULT '0';

# item_randomprop_groups
ALTER TABLE `item_randomprop_groups`
CHANGE `entry_id` `entry_id` int(30) NOT NULL,
CHANGE `randomprops_entryid` `randomprops_entryid` int(30) NOT NULL;

# item_randomprop_groups
ALTER TABLE `item_randomsuffix_groups`
CHANGE `entry_id` `entry_id` int(30) NOT NULL,
CHANGE `randomsuffix_entryid` `randomsuffix_entryid` int(30) NOT NULL;

# itempages_localized
DROP TABLE IF EXISTS `itempages_localized`;
CREATE TABLE `itempages_localized` (
  `entry` int(30) NOT NULL,
  `language_code` varchar(5) CHARACTER SET latin1 NOT NULL,
  `text` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`entry`,`language_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

# itempetfood
ALTER TABLE `itempetfood`
CHANGE `entry` `entry` int(11) NOT NULL,
CHANGE `food_type` `food_type` int(11) NOT NULL;

# items
CREATE TABLE `items_temp` (
  `entry` int(255) unsigned NOT NULL DEFAULT '0',
  `class` int(30) NOT NULL DEFAULT '0',
  `subclass` int(30) NOT NULL DEFAULT '0',
  `field4` int(10) NOT NULL DEFAULT '-1',
  `name1` varchar(255) NOT NULL,
  `displayid` int(70) unsigned NOT NULL DEFAULT '0',
  `quality` int(30) NOT NULL DEFAULT '0',
  `flags` int(30) NOT NULL DEFAULT '0',
  `faction` int(11) unsigned NOT NULL DEFAULT '0',
  `buyprice` int(30) NOT NULL DEFAULT '0',
  `sellprice` int(30) NOT NULL DEFAULT '0',
  `inventorytype` int(30) NOT NULL DEFAULT '0',
  `allowableclass` int(30) NOT NULL DEFAULT '0',
  `allowablerace` int(30) NOT NULL DEFAULT '0',
  `itemlevel` int(30) NOT NULL DEFAULT '0',
  `requiredlevel` int(30) NOT NULL DEFAULT '0',
  `RequiredSkill` int(30) NOT NULL DEFAULT '0',
  `RequiredSkillRank` int(30) NOT NULL DEFAULT '0',
  `RequiredSpell` int(30) NOT NULL DEFAULT '0',
  `RequiredPlayerRank1` int(30) NOT NULL DEFAULT '0',
  `RequiredPlayerRank2` int(30) NOT NULL DEFAULT '0',
  `RequiredFaction` int(30) NOT NULL DEFAULT '0',
  `RequiredFactionStanding` int(30) NOT NULL DEFAULT '0',
  `Unique` int(30) NOT NULL DEFAULT '0',
  `maxcount` int(30) NOT NULL DEFAULT '0',
  `ContainerSlots` int(30) NOT NULL DEFAULT '0',
  `itemstatscount` int(10) unsigned NOT NULL DEFAULT '10',
  `stat_type1` int(30) NOT NULL DEFAULT '0',
  `stat_value1` int(30) NOT NULL DEFAULT '0',
  `stat_type2` int(30) NOT NULL DEFAULT '0',
  `stat_value2` int(30) NOT NULL DEFAULT '0',
  `stat_type3` int(30) NOT NULL DEFAULT '0',
  `stat_value3` int(30) NOT NULL DEFAULT '0',
  `stat_type4` int(30) NOT NULL DEFAULT '0',
  `stat_value4` int(30) NOT NULL DEFAULT '0',
  `stat_type5` int(30) NOT NULL DEFAULT '0',
  `stat_value5` int(30) NOT NULL DEFAULT '0',
  `stat_type6` int(30) NOT NULL DEFAULT '0',
  `stat_value6` int(30) NOT NULL DEFAULT '0',
  `stat_type7` int(30) NOT NULL DEFAULT '0',
  `stat_value7` int(30) NOT NULL DEFAULT '0',
  `stat_type8` int(30) NOT NULL DEFAULT '0',
  `stat_value8` int(30) NOT NULL DEFAULT '0',
  `stat_type9` int(30) NOT NULL DEFAULT '0',
  `stat_value9` int(30) NOT NULL DEFAULT '0',
  `stat_type10` int(30) NOT NULL DEFAULT '0',
  `stat_value10` int(30) NOT NULL DEFAULT '0',
  `ScaledStatsDistributionId` int(32) unsigned NOT NULL DEFAULT '0',
  `ScaledStatsDistributionFlags` int(32) unsigned NOT NULL DEFAULT '0',
  `dmg_min1` float NOT NULL DEFAULT '0',
  `dmg_max1` float NOT NULL DEFAULT '0',
  `dmg_type1` int(30) NOT NULL DEFAULT '0',
  `dmg_min2` float NOT NULL DEFAULT '0',
  `dmg_max2` float NOT NULL DEFAULT '0',
  `dmg_type2` int(30) NOT NULL DEFAULT '0',
  `armor` int(30) NOT NULL DEFAULT '0',
  `holy_res` int(30) NOT NULL DEFAULT '0',
  `fire_res` int(30) NOT NULL DEFAULT '0',
  `nature_res` int(30) NOT NULL DEFAULT '0',
  `frost_res` int(30) NOT NULL DEFAULT '0',
  `shadow_res` int(30) NOT NULL DEFAULT '0',
  `arcane_res` int(30) NOT NULL DEFAULT '0',
  `delay` int(30) NOT NULL DEFAULT '0',
  `ammo_type` int(30) NOT NULL DEFAULT '0',
  `range` float NOT NULL DEFAULT '0',
  `spellid_1` int(30) NOT NULL DEFAULT '0',
  `spelltrigger_1` int(30) NOT NULL DEFAULT '0',
  `spellcharges_1` int(30) NOT NULL DEFAULT '0',
  `spellcooldown_1` int(30) NOT NULL DEFAULT '0',
  `spellcategory_1` int(30) NOT NULL DEFAULT '0',
  `spellcategorycooldown_1` int(30) NOT NULL DEFAULT '0',
  `spellid_2` int(30) NOT NULL DEFAULT '0',
  `spelltrigger_2` int(30) NOT NULL DEFAULT '0',
  `spellcharges_2` int(30) NOT NULL DEFAULT '0',
  `spellcooldown_2` int(30) NOT NULL DEFAULT '0',
  `spellcategory_2` int(30) NOT NULL DEFAULT '0',
  `spellcategorycooldown_2` int(30) NOT NULL DEFAULT '0',
  `spellid_3` int(30) NOT NULL DEFAULT '0',
  `spelltrigger_3` int(30) NOT NULL DEFAULT '0',
  `spellcharges_3` int(30) NOT NULL DEFAULT '0',
  `spellcooldown_3` int(30) NOT NULL DEFAULT '0',
  `spellcategory_3` int(30) NOT NULL DEFAULT '0',
  `spellcategorycooldown_3` int(30) NOT NULL DEFAULT '0',
  `spellid_4` int(30) NOT NULL DEFAULT '0',
  `spelltrigger_4` int(30) NOT NULL DEFAULT '0',
  `spellcharges_4` int(30) NOT NULL DEFAULT '0',
  `spellcooldown_4` int(30) NOT NULL DEFAULT '0',
  `spellcategory_4` int(30) NOT NULL DEFAULT '0',
  `spellcategorycooldown_4` int(30) NOT NULL DEFAULT '0',
  `spellid_5` int(30) NOT NULL DEFAULT '0',
  `spelltrigger_5` int(30) NOT NULL DEFAULT '0',
  `spellcharges_5` int(30) NOT NULL DEFAULT '0',
  `spellcooldown_5` int(30) NOT NULL DEFAULT '0',
  `spellcategory_5` int(30) NOT NULL DEFAULT '0',
  `spellcategorycooldown_5` int(30) NOT NULL DEFAULT '0',
  `bonding` int(30) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL DEFAULT '',
  `page_id` int(30) NOT NULL DEFAULT '0',
  `page_language` int(30) NOT NULL DEFAULT '0',
  `page_material` int(30) NOT NULL DEFAULT '0',
  `quest_id` int(30) NOT NULL DEFAULT '0',
  `lock_id` int(30) NOT NULL DEFAULT '0',
  `lock_material` int(30) NOT NULL DEFAULT '0',
  `sheathID` int(30) NOT NULL DEFAULT '0',
  `randomprop` int(30) NOT NULL DEFAULT '0',
  `randomsuffix` int(30) NOT NULL DEFAULT '0',
  `block` int(30) NOT NULL DEFAULT '0',
  `itemset` int(30) NOT NULL DEFAULT '0',
  `MaxDurability` int(30) NOT NULL DEFAULT '0',
  `ZoneNameID` int(30) NOT NULL DEFAULT '0',
  `mapid` int(30) DEFAULT NULL,
  `bagfamily` int(30) NOT NULL DEFAULT '0',
  `TotemCategory` int(30) DEFAULT NULL,
  `socket_color_1` int(30) DEFAULT NULL,
  `unk201_3` int(30) NOT NULL DEFAULT '0',
  `socket_color_2` int(30) DEFAULT NULL,
  `unk201_5` int(30) NOT NULL DEFAULT '0',
  `socket_color_3` int(30) DEFAULT NULL,
  `unk201_7` int(30) NOT NULL DEFAULT '0',
  `socket_bonus` int(30) DEFAULT NULL,
  `GemProperties` int(30) DEFAULT NULL,
  `ReqDisenchantSkill` int(30) NOT NULL DEFAULT '-1',
  `ArmorDamageModifier` int(30) NOT NULL DEFAULT '0',
  `existingduration` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemLimitCategoryId` int(32) unsigned NOT NULL DEFAULT '0',
  `HolidayId` int(32) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Item System';
INSERT INTO `items_temp` (SELECT * FROM `items`);
DROP TABLE IF EXISTS `items`;
RENAME TABLE `items_temp` TO `items`;

# items_extendedcost
DROP TABLE IF EXISTS `items_extendedcost`;
CREATE TABLE `items_extendedcost` (
  `ItemId` int(30) NOT NULL,
  `CostId` int(30) NOT NULL,
  PRIMARY KEY (`ItemId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# items_localized
ALTER TABLE `items_localized`
CHANGE `entry` `entry` int(30) NOT NULL,
CHANGE `language_code` `language_code` varchar(5) NOT NULL,
CHANGE `name` `name` varchar(255) NOT NULL,
CHANGE `description` `description` varchar(255) NOT NULL;

# loot_creatures
ALTER TABLE `loot_creatures`
DROP PRIMARY KEY, 
ADD PRIMARY KEY (`entryid`,`itemid`),
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `itemid` `itemid` int(11) NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1';

# loot_fishing
ALTER TABLE `loot_fishing`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`itemid`,`entryid`),
DROP KEY `UNIQUE`,
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `entryid` `entryid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `itemid` `itemid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `ffa_loot` `ffa_loot` int(10) unsigned NOT NULL DEFAULT '0';

# loot_gameobjects
ALTER TABLE `loot_gameobjects`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`entryid`,`itemid`),
DROP KEY `UNIQUE`,
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `entryid` `entryid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `itemid` `itemid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `ffa_loot` `ffa_loot` int(10) unsigned NOT NULL DEFAULT '0';

# loot_items
ALTER TABLE `loot_items`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`entryid`,`itemid`),
DROP KEY `UNIQUE`,
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `entryid` `entryid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `itemid` `itemid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `ffa_loot` `ffa_loot` int(10) unsigned NOT NULL DEFAULT '0';

# loot_pickpocketing
ALTER TABLE `loot_pickpocketing`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`entryid`,`itemid`),
DROP KEY `UNIQUE`,
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `entryid` `entryid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `itemid` `itemid` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `ffa_loot` `ffa_loot` int(10) unsigned NOT NULL DEFAULT '0';

# loot_skinning
ALTER TABLE `loot_skinning`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`itemid`,`entryid`),
DROP KEY `UNIQUE`,
ADD UNIQUE KEY `index` (`index`),
CHANGE `index` `index` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `entryid` `entryid` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `itemid` `itemid` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `mincount` `mincount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `maxcount` `maxcount` int(30) unsigned NOT NULL DEFAULT '1',
CHANGE `ffa_loot` `ffa_loot` int(10) unsigned NOT NULL DEFAULT '0';

# map_checkpoint
DROP TABLE IF EXISTS `map_checkpoint`;
CREATE TABLE `map_checkpoint` (
  `entry` int(30) NOT NULL,
  `prereq_checkpoint_id` int(30) NOT NULL,
  `creature_id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Map System';

# npc_monstersay
ALTER TABLE `npc_monstersay`
DROP KEY `entry`,
ADD PRIMARY KEY (`entry`,`event`);

# npc_text
ALTER TABLE `npc_text`
DROP KEY `entry`,
ADD PRIMARY KEY (`entry`);

# petdefaultspells
ALTER TABLE `petdefaultspells`
DROP KEY `entry`,
CHANGE `entry` `entry` int(11) NOT NULL DEFAULT '0',
CHANGE `spell` `spell` int(11) NOT NULL DEFAULT '0';

# playercreateinfo_items
ALTER TABLE `playercreateinfo_items` ADD PRIMARY KEY (`indexid`,`protoid`,`slotid`);

# playercreateinfo_skills
/* ALTER TABLE `playercreateinfo_skills` ADD PRIMARY KEY (`indexid`,`skillid`); */

# playercreateinfo_spells
ALTER TABLE `playercreateinfo_spells` DROP KEY `indexid`, ADD PRIMARY KEY (`indexid`,`spellid`);

# quests
ALTER TABLE `quests`
CHANGE `ReqKillMobOrGOId1` `ReqKillMobOrGOId1` int(10) NOT NULL DEFAULT '0',
CHANGE `ReqKillMobOrGOId2` `ReqKillMobOrGOId2` int(10) NOT NULL DEFAULT '0',
CHANGE `ReqKillMobOrGOId3` `ReqKillMobOrGOId3` int(10) NOT NULL DEFAULT '0',
CHANGE `ReqKillMobOrGOId4` `ReqKillMobOrGOId4` int(10) NOT NULL DEFAULT '0',
CHANGE `RewRepLimit` `RewRepLimit` int(10) unsigned NOT NULL DEFAULT '0';

# quests_localized
ALTER TABLE `quests_localized`
CHANGE `entry` `entry` int(30) NOT NULL,
DROP KEY `lol`;

# recall
ALTER TABLE `recall` CHANGE `id` `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;

# reputation_creature_onkill
ALTER TABLE `reputation_creature_onkill`
CHANGE `creature_id` `creature_id` int(30) NOT NULL,
CHANGE `faction_change_alliance` `faction_change_alliance` int(30) NOT NULL,
CHANGE `faction_change_horde` `faction_change_horde` int(30) NOT NULL,
CHANGE `change_value` `change_value` int(30) NOT NULL,
CHANGE `rep_limit` `rep_limit` int(30) NOT NULL;

# reputation_faction_onkill {Duplicate problem}
/*
ALTER TABLE `reputation_faction_onkill`
DROP KEY `factindex`,
ADD PRIMARY KEY (`faction_id`),
CHANGE `faction_id` `faction_id` int(30) NOT NULL,
CHANGE `change_factionid_alliance` `change_factionid_alliance` int(30) NOT NULL,
CHANGE `change_deltamin_alliance` `change_deltamin_alliance` int(30) NOT NULL,
CHANGE `change_deltamax_alliance` `change_deltamax_alliance` int(30) NOT NULL,
CHANGE `change_factionid_horde` `change_factionid_horde` int(30) NOT NULL,
CHANGE `change_deltamin_horde` `change_deltamin_horde` int(30) NOT NULL,
CHANGE `change_deltamax_horde` `change_deltamax_horde` int(30) NOT NULL;
*/

# spell_coef_override
DROP TABLE IF EXISTS `spell_coef_override`;
CREATE TABLE `spell_coef_override` (
  `id` double DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `Dspell_coef_override` float DEFAULT NULL,
  `OTspell_coef_override` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
INSERT INTO `spell_coef_override` VALUES ('8400', 'Fireball Rank 5', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('8401', 'Fireball Rank 6', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('8402', 'Fireball Rank 7', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('10148', 'Fireball Rank 8', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('10149', 'Fireball Rank 9', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('10150', 'Fireball Rank 10', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('10151', 'Fireball Rank 11', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('25306', 'Fireball Rank 12', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('27070', 'Fireball Rank 13', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('38692', 'Fireball Rank 14', '1', '0');
INSERT INTO `spell_coef_override` VALUES ('30455', 'Ice Lance', '0.1429', '0');
INSERT INTO `spell_coef_override` VALUES ('603', 'Curse of Doom Rank 1', '0', '2');
INSERT INTO `spell_coef_override` VALUES ('30910', 'Curse of Doom Rank 2', '0', '2');
INSERT INTO `spell_coef_override` VALUES ('980', 'Curse of Agony Rank 1', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('1014', 'Curse of Agony Rank 2', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('6217', 'Curse of Agony Rank 3', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('11711', 'Curse of Agony Rank 4', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('11712', 'Curse of Agony Rank 5', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('11713', 'Curse of Agony Rank 6', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('27218', 'Curse of Agony Rank 7', '0', '1.2');
INSERT INTO `spell_coef_override` VALUES ('33763', 'Libebloom', '0.4286', '0.518');
INSERT INTO `spell_coef_override` VALUES ('139', 'Renew Rank 1', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('6074', 'Renew Rank 2', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('6075', 'Renew Rank 3', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('6076', 'Renew Rank 4', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('6077', 'Renew Rank 5', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('6078', 'Renew Rank 6', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('10927', 'Renew Rank 7', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('10928', 'Renew Rank 8', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('10929', 'Renew Rank 9', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('25315', 'Renew Rank 10', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('25221', 'Renew Rank 11', '0', '1');
INSERT INTO `spell_coef_override` VALUES ('21084', 'Seal of Righteousness Rank 1', '0.1', '0');
INSERT INTO `spell_coef_override` VALUES ('20424', 'Seal of Command', '0.2', '0');
INSERT INTO `spell_coef_override` VALUES ('17', 'Power Word: Shield Rank 1', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('592', 'Power Word: Shield Rank 2', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('600', 'Power Word: Shield Rank 3', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('3747', 'Power Word: Shield Rank 4', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('6065', 'Power Word: Shield Rank 5', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('6066', 'Power Word: Shield Rank 6', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('10898', 'Power Word: Shield Rank 7', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('10899', 'Power Word: Shield Rank 8', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('10900', 'Power Word: Shield Rank 9', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('10901', 'Power Word: Shield Rank 10', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('25217', 'Power Word: Shield Rank 11', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('25218', 'Power Word: Shield Rank 12', '0.3', '-1');
INSERT INTO `spell_coef_override` VALUES ('11426', 'Ice Barrier Rank 1', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('13031', 'Ice Barrier Rank 2', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('13032', 'Ice Barrier Rank 3', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('13033', 'Ice Barrier Rank 4', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('27134', 'Ice Barrier Rank 5', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('33405', 'Ice Barrier Rank 6', '-1', '0.1');
INSERT INTO `spell_coef_override` VALUES ('6143', 'Frost Ward Rank 1', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('8461', 'Frost Ward Rank 2', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('8462', 'Frost Ward Rank 3', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('10177', 'Frost Ward Rank 4', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('28609', 'Frost Ward Rank 5', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('32796', 'Frost Ward Rank 6', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('543', 'Fire Ward Rank 1', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('8457', 'Fire Ward Rank 2', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('8458', 'Fire Ward Rank 3', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('10223', 'Fire Ward Rank 4', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('10225', 'Fire Ward Rank 5', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('27128', 'Fire Ward Rank 6', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('6229', 'Shadow Ward Rank 1', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('11739', 'Shadow Ward Rank 2', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('11740', 'Shadow Ward Rank 3', '-1', '0.3');
INSERT INTO `spell_coef_override` VALUES ('28610', 'Shadow Ward Rank 4', '-1', '0.3');

# spell_proc
/*
DROP TABLE IF EXISTS `spell_proc`;
CREATE TABLE `spell_proc` (
  `spellID` int(30) NOT NULL DEFAULT '0',
  `ProcOnNameHash` int(30) unsigned NOT NULL DEFAULT '0',
  `ProcFlag` int(30) NOT NULL DEFAULT '0',
  `TargetSelf` tinyint(1) NOT NULL DEFAULT '0',
  `ProcChance` int(30) NOT NULL DEFAULT '-1',
  `ProcCharges` smallint(30) NOT NULL DEFAULT '-1',
  `ProcInterval` int(30) NOT NULL DEFAULT '0',
  `EffectTriggerSpell[0]` int(10) NOT NULL DEFAULT '-1',
  `EffectTriggerSpell[1]` int(10) NOT NULL DEFAULT '-1',
  `EffectTriggerSpell[2]` int(10) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`spellID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
*/
INSERT IGNORE INTO `spell_proc` VALUES (23920,0,134348800,0,100,1,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (30482,0,10792,0,-1,0,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (43045,0,10792,0,-1,0,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (324,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (325,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (905,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (945,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (8134,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (10431,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (10432,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (25469,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (25472,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (49280,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (49281,0,666152,0,100,3,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (43046,0,10792,0,-1,-1,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (37982,0,4,0,1,0,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (27521,0,16,0,5,0,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (38394,0,1024,0,-1,-1,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (64976,0,16,0,-1,-1,0,-1,-1,-1);
INSERT IGNORE INTO `spell_proc` VALUES (65156,3808755873,0,0,-1,-1,0,-1,-1,-1);

# spelloverride
DROP TABLE IF EXISTS `spelloverride`;
CREATE TABLE `spelloverride` (
  `overrideId` int(10) unsigned NOT NULL DEFAULT '0',
  `spellId` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `overrideId` (`overrideId`,`spellId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Spell System';

INSERT INTO `spelloverride` VALUES ('836', '10');
INSERT INTO `spelloverride` VALUES ('836', '6141');
INSERT INTO `spelloverride` VALUES ('836', '8427');
INSERT INTO `spelloverride` VALUES ('836', '10185');
INSERT INTO `spelloverride` VALUES ('836', '10186');
INSERT INTO `spelloverride` VALUES ('836', '10187');
INSERT INTO `spelloverride` VALUES ('836', '27085');
INSERT INTO `spelloverride` VALUES ('836', '27618');
INSERT INTO `spelloverride` VALUES ('850', '5246');
INSERT INTO `spelloverride` VALUES ('850', '12730');
INSERT INTO `spelloverride` VALUES ('850', '19134');
INSERT INTO `spelloverride` VALUES ('850', '20511');
INSERT INTO `spelloverride` VALUES ('850', '29544');
INSERT INTO `spelloverride` VALUES ('850', '33789');
INSERT INTO `spelloverride` VALUES ('850', '38945');
INSERT INTO `spelloverride` VALUES ('850', '38946');
INSERT INTO `spelloverride` VALUES ('968', '5246');
INSERT INTO `spelloverride` VALUES ('968', '12730');
INSERT INTO `spelloverride` VALUES ('968', '19134');
INSERT INTO `spelloverride` VALUES ('968', '20511');
INSERT INTO `spelloverride` VALUES ('968', '29544');
INSERT INTO `spelloverride` VALUES ('968', '33789');
INSERT INTO `spelloverride` VALUES ('968', '38945');
INSERT INTO `spelloverride` VALUES ('968', '38946');
INSERT INTO `spelloverride` VALUES ('969', '5246');
INSERT INTO `spelloverride` VALUES ('969', '12730');
INSERT INTO `spelloverride` VALUES ('969', '19134');
INSERT INTO `spelloverride` VALUES ('969', '20511');
INSERT INTO `spelloverride` VALUES ('969', '29544');
INSERT INTO `spelloverride` VALUES ('969', '33789');
INSERT INTO `spelloverride` VALUES ('969', '38945');
INSERT INTO `spelloverride` VALUES ('969', '38946');
INSERT INTO `spelloverride` VALUES ('988', '10');
INSERT INTO `spelloverride` VALUES ('988', '6141');
INSERT INTO `spelloverride` VALUES ('988', '8427');
INSERT INTO `spelloverride` VALUES ('988', '10185');
INSERT INTO `spelloverride` VALUES ('988', '10186');
INSERT INTO `spelloverride` VALUES ('988', '10187');
INSERT INTO `spelloverride` VALUES ('988', '27085');
INSERT INTO `spelloverride` VALUES ('988', '27618');
INSERT INTO `spelloverride` VALUES ('989', '10');
INSERT INTO `spelloverride` VALUES ('989', '6141');
INSERT INTO `spelloverride` VALUES ('989', '8427');
INSERT INTO `spelloverride` VALUES ('989', '10185');
INSERT INTO `spelloverride` VALUES ('989', '10186');
INSERT INTO `spelloverride` VALUES ('989', '10187');
INSERT INTO `spelloverride` VALUES ('989', '27085');
INSERT INTO `spelloverride` VALUES ('989', '27618');
INSERT INTO `spelloverride` VALUES ('2188', '1949');
INSERT INTO `spelloverride` VALUES ('2188', '5740');
INSERT INTO `spelloverride` VALUES ('2188', '6219');
INSERT INTO `spelloverride` VALUES ('2188', '6353');
INSERT INTO `spelloverride` VALUES ('2188', '11677');
INSERT INTO `spelloverride` VALUES ('2188', '11678');
INSERT INTO `spelloverride` VALUES ('2188', '11683');
INSERT INTO `spelloverride` VALUES ('2188', '11684');
INSERT INTO `spelloverride` VALUES ('2188', '17924');
INSERT INTO `spelloverride` VALUES ('2188', '19474');
INSERT INTO `spelloverride` VALUES ('2188', '27211');
INSERT INTO `spelloverride` VALUES ('2188', '27212');
INSERT INTO `spelloverride` VALUES ('2188', '27213');
INSERT INTO `spelloverride` VALUES ('2188', '30545');
INSERT INTO `spelloverride` VALUES ('2188', '30859');
INSERT INTO `spelloverride` VALUES ('2188', '34659');
INSERT INTO `spelloverride` VALUES ('2188', '34660');
INSERT INTO `spelloverride` VALUES ('2188', '39131');
INSERT INTO `spelloverride` VALUES ('2188', '39132');
INSERT INTO `spelloverride` VALUES ('2188', '39273');
INSERT INTO `spelloverride` VALUES ('2189', '1949');
INSERT INTO `spelloverride` VALUES ('2189', '5740');
INSERT INTO `spelloverride` VALUES ('2189', '6219');
INSERT INTO `spelloverride` VALUES ('2189', '6353');
INSERT INTO `spelloverride` VALUES ('2189', '11677');
INSERT INTO `spelloverride` VALUES ('2189', '11678');
INSERT INTO `spelloverride` VALUES ('2189', '11683');
INSERT INTO `spelloverride` VALUES ('2189', '11684');
INSERT INTO `spelloverride` VALUES ('2189', '17924');
INSERT INTO `spelloverride` VALUES ('2189', '19474');
INSERT INTO `spelloverride` VALUES ('2189', '27211');
INSERT INTO `spelloverride` VALUES ('2189', '27212');
INSERT INTO `spelloverride` VALUES ('2189', '27213');
INSERT INTO `spelloverride` VALUES ('2189', '30545');
INSERT INTO `spelloverride` VALUES ('2189', '30859');
INSERT INTO `spelloverride` VALUES ('2189', '34659');
INSERT INTO `spelloverride` VALUES ('2189', '34660');
INSERT INTO `spelloverride` VALUES ('2189', '39131');
INSERT INTO `spelloverride` VALUES ('2189', '39132');
INSERT INTO `spelloverride` VALUES ('2189', '39273');
INSERT INTO `spelloverride` VALUES ('2388', '3043');
INSERT INTO `spelloverride` VALUES ('2389', '3043');
INSERT INTO `spelloverride` VALUES ('2390', '3043');
INSERT INTO `spelloverride` VALUES ('3736', '8004');
INSERT INTO `spelloverride` VALUES ('3736', '8008');
INSERT INTO `spelloverride` VALUES ('3736', '8010');
INSERT INTO `spelloverride` VALUES ('3736', '10466');
INSERT INTO `spelloverride` VALUES ('3736', '10467');
INSERT INTO `spelloverride` VALUES ('3736', '10468');
INSERT INTO `spelloverride` VALUES ('3736', '25420');
INSERT INTO `spelloverride` VALUES ('3736', '27624');
INSERT INTO `spelloverride` VALUES ('3736', '28849');
INSERT INTO `spelloverride` VALUES ('3736', '49275');
INSERT INTO `spelloverride` VALUES ('3736', '49276');
INSERT INTO `spelloverride` VALUES ('4086', '136');
INSERT INTO `spelloverride` VALUES ('4086', '3111');
INSERT INTO `spelloverride` VALUES ('4086', '3661');
INSERT INTO `spelloverride` VALUES ('4086', '3662');
INSERT INTO `spelloverride` VALUES ('4086', '13542');
INSERT INTO `spelloverride` VALUES ('4086', '13543');
INSERT INTO `spelloverride` VALUES ('4086', '13544');
INSERT INTO `spelloverride` VALUES ('4086', '27046');
INSERT INTO `spelloverride` VALUES ('4086', '33976');
INSERT INTO `spelloverride` VALUES ('4087', '136');
INSERT INTO `spelloverride` VALUES ('4087', '3111');
INSERT INTO `spelloverride` VALUES ('4087', '3661');
INSERT INTO `spelloverride` VALUES ('4087', '3662');
INSERT INTO `spelloverride` VALUES ('4087', '13542');
INSERT INTO `spelloverride` VALUES ('4087', '13543');
INSERT INTO `spelloverride` VALUES ('4087', '13544');
INSERT INTO `spelloverride` VALUES ('4087', '27046');
INSERT INTO `spelloverride` VALUES ('4087', '33976');
INSERT INTO `spelloverride` VALUES ('4235', '10');
INSERT INTO `spelloverride` VALUES ('4235', '6141');
INSERT INTO `spelloverride` VALUES ('4235', '8427');
INSERT INTO `spelloverride` VALUES ('4235', '10185');
INSERT INTO `spelloverride` VALUES ('4235', '10186');
INSERT INTO `spelloverride` VALUES ('4235', '10187');
INSERT INTO `spelloverride` VALUES ('4235', '27085');
INSERT INTO `spelloverride` VALUES ('4235', '27618');
INSERT INTO `spelloverride` VALUES ('4415', '774');
INSERT INTO `spelloverride` VALUES ('4415', '1058');
INSERT INTO `spelloverride` VALUES ('4415', '1430');
INSERT INTO `spelloverride` VALUES ('4415', '2090');
INSERT INTO `spelloverride` VALUES ('4415', '2091');
INSERT INTO `spelloverride` VALUES ('4415', '3627');
INSERT INTO `spelloverride` VALUES ('4415', '8910');
INSERT INTO `spelloverride` VALUES ('4415', '9839');
INSERT INTO `spelloverride` VALUES ('4415', '9840');
INSERT INTO `spelloverride` VALUES ('4415', '9841');
INSERT INTO `spelloverride` VALUES ('4415', '25299');
INSERT INTO `spelloverride` VALUES ('4415', '26981');
INSERT INTO `spelloverride` VALUES ('4415', '26982');
INSERT INTO `spelloverride` VALUES ('4415', '28716');
INSERT INTO `spelloverride` VALUES ('4418', '8042');
INSERT INTO `spelloverride` VALUES ('4418', '8044');
INSERT INTO `spelloverride` VALUES ('4418', '8045');
INSERT INTO `spelloverride` VALUES ('4418', '8046');
INSERT INTO `spelloverride` VALUES ('4418', '8050');
INSERT INTO `spelloverride` VALUES ('4418', '8052');
INSERT INTO `spelloverride` VALUES ('4418', '8053');
INSERT INTO `spelloverride` VALUES ('4418', '8056');
INSERT INTO `spelloverride` VALUES ('4418', '8058');
INSERT INTO `spelloverride` VALUES ('4418', '10412');
INSERT INTO `spelloverride` VALUES ('4418', '10413');
INSERT INTO `spelloverride` VALUES ('4418', '10414');
INSERT INTO `spelloverride` VALUES ('4418', '10447');
INSERT INTO `spelloverride` VALUES ('4418', '10448');
INSERT INTO `spelloverride` VALUES ('4418', '10472');
INSERT INTO `spelloverride` VALUES ('4418', '10473');
INSERT INTO `spelloverride` VALUES ('4418', '25454');
INSERT INTO `spelloverride` VALUES ('4418', '25457');
INSERT INTO `spelloverride` VALUES ('4418', '25464');
INSERT INTO `spelloverride` VALUES ('4418', '29228');
INSERT INTO `spelloverride` VALUES ('4533', '774');
INSERT INTO `spelloverride` VALUES ('4533', '1058');
INSERT INTO `spelloverride` VALUES ('4533', '1430');
INSERT INTO `spelloverride` VALUES ('4533', '2090');
INSERT INTO `spelloverride` VALUES ('4533', '2091');
INSERT INTO `spelloverride` VALUES ('4533', '3627');
INSERT INTO `spelloverride` VALUES ('4533', '8910');
INSERT INTO `spelloverride` VALUES ('4533', '9839');
INSERT INTO `spelloverride` VALUES ('4533', '9840');
INSERT INTO `spelloverride` VALUES ('4533', '9841');
INSERT INTO `spelloverride` VALUES ('4533', '25299');
INSERT INTO `spelloverride` VALUES ('4533', '26981');
INSERT INTO `spelloverride` VALUES ('4533', '26982');
INSERT INTO `spelloverride` VALUES ('4533', '28716');
INSERT INTO `spelloverride` VALUES ('4537', '8936');
INSERT INTO `spelloverride` VALUES ('4537', '8938');
INSERT INTO `spelloverride` VALUES ('4537', '8939');
INSERT INTO `spelloverride` VALUES ('4537', '8940');
INSERT INTO `spelloverride` VALUES ('4537', '8941');
INSERT INTO `spelloverride` VALUES ('4537', '9750');
INSERT INTO `spelloverride` VALUES ('4537', '9856');
INSERT INTO `spelloverride` VALUES ('4537', '9857');
INSERT INTO `spelloverride` VALUES ('4537', '9858');
INSERT INTO `spelloverride` VALUES ('4537', '26980');
INSERT INTO `spelloverride` VALUES ('4537', '28744');
INSERT INTO `spelloverride` VALUES ('4554', '403');
INSERT INTO `spelloverride` VALUES ('4554', '421');
INSERT INTO `spelloverride` VALUES ('4554', '529');
INSERT INTO `spelloverride` VALUES ('4554', '548');
INSERT INTO `spelloverride` VALUES ('4554', '915');
INSERT INTO `spelloverride` VALUES ('4554', '930');
INSERT INTO `spelloverride` VALUES ('4554', '943');
INSERT INTO `spelloverride` VALUES ('4554', '2860');
INSERT INTO `spelloverride` VALUES ('4554', '6041');
INSERT INTO `spelloverride` VALUES ('4554', '10391');
INSERT INTO `spelloverride` VALUES ('4554', '10392');
INSERT INTO `spelloverride` VALUES ('4554', '10605');
INSERT INTO `spelloverride` VALUES ('4554', '15207');
INSERT INTO `spelloverride` VALUES ('4554', '15208');
INSERT INTO `spelloverride` VALUES ('4554', '25439');
INSERT INTO `spelloverride` VALUES ('4554', '25442');
INSERT INTO `spelloverride` VALUES ('4554', '25448');
INSERT INTO `spelloverride` VALUES ('4554', '25449');
INSERT INTO `spelloverride` VALUES ('4554', '37661');
INSERT INTO `spelloverride` VALUES ('4555', '8921');
INSERT INTO `spelloverride` VALUES ('4555', '8924');
INSERT INTO `spelloverride` VALUES ('4555', '8925');
INSERT INTO `spelloverride` VALUES ('4555', '8926');
INSERT INTO `spelloverride` VALUES ('4555', '8927');
INSERT INTO `spelloverride` VALUES ('4555', '8928');
INSERT INTO `spelloverride` VALUES ('4555', '8929');
INSERT INTO `spelloverride` VALUES ('4555', '9833');
INSERT INTO `spelloverride` VALUES ('4555', '9834');
INSERT INTO `spelloverride` VALUES ('4555', '9835');
INSERT INTO `spelloverride` VALUES ('4555', '20690');
INSERT INTO `spelloverride` VALUES ('4555', '21669');
INSERT INTO `spelloverride` VALUES ('4555', '26987');
INSERT INTO `spelloverride` VALUES ('4555', '26988');
INSERT INTO `spelloverride` VALUES ('4953', '774');
INSERT INTO `spelloverride` VALUES ('4953', '1058');
INSERT INTO `spelloverride` VALUES ('4953', '1430');
INSERT INTO `spelloverride` VALUES ('4953', '2090');
INSERT INTO `spelloverride` VALUES ('4953', '2091');
INSERT INTO `spelloverride` VALUES ('4953', '3627');
INSERT INTO `spelloverride` VALUES ('4953', '8910');
INSERT INTO `spelloverride` VALUES ('4953', '9839');
INSERT INTO `spelloverride` VALUES ('4953', '9840');
INSERT INTO `spelloverride` VALUES ('4953', '9841');
INSERT INTO `spelloverride` VALUES ('4953', '25299');
INSERT INTO `spelloverride` VALUES ('4953', '26981');
INSERT INTO `spelloverride` VALUES ('4953', '26982');
INSERT INTO `spelloverride` VALUES ('4953', '28716');
INSERT INTO `spelloverride` VALUES ('4992', '689');
INSERT INTO `spelloverride` VALUES ('4992', '699');
INSERT INTO `spelloverride` VALUES ('4992', '709');
INSERT INTO `spelloverride` VALUES ('4992', '5138');
INSERT INTO `spelloverride` VALUES ('4992', '6226');
INSERT INTO `spelloverride` VALUES ('4992', '7651');
INSERT INTO `spelloverride` VALUES ('4992', '11699');
INSERT INTO `spelloverride` VALUES ('4992', '11700');
INSERT INTO `spelloverride` VALUES ('4992', '11703');
INSERT INTO `spelloverride` VALUES ('4992', '11704');
INSERT INTO `spelloverride` VALUES ('4992', '27219');
INSERT INTO `spelloverride` VALUES ('4992', '27220');
INSERT INTO `spelloverride` VALUES ('4992', '27221');
INSERT INTO `spelloverride` VALUES ('4992', '30412');
INSERT INTO `spelloverride` VALUES ('4992', '30908');
INSERT INTO `spelloverride` VALUES ('4992', '32554');
INSERT INTO `spelloverride` VALUES ('4993', '689');
INSERT INTO `spelloverride` VALUES ('4993', '699');
INSERT INTO `spelloverride` VALUES ('4993', '709');
INSERT INTO `spelloverride` VALUES ('4993', '5138');
INSERT INTO `spelloverride` VALUES ('4993', '6226');
INSERT INTO `spelloverride` VALUES ('4993', '7651');
INSERT INTO `spelloverride` VALUES ('4993', '11699');
INSERT INTO `spelloverride` VALUES ('4993', '11700');
INSERT INTO `spelloverride` VALUES ('4993', '11703');
INSERT INTO `spelloverride` VALUES ('4993', '11704');
INSERT INTO `spelloverride` VALUES ('4993', '27219');
INSERT INTO `spelloverride` VALUES ('4993', '27220');
INSERT INTO `spelloverride` VALUES ('4993', '27221');
INSERT INTO `spelloverride` VALUES ('4993', '30412');
INSERT INTO `spelloverride` VALUES ('4993', '30908');
INSERT INTO `spelloverride` VALUES ('4993', '32554');
INSERT INTO `spelloverride` VALUES ('4994', '172');
INSERT INTO `spelloverride` VALUES ('4994', '980');
INSERT INTO `spelloverride` VALUES ('4994', '1014');
INSERT INTO `spelloverride` VALUES ('4994', '6217');
INSERT INTO `spelloverride` VALUES ('4994', '6222');
INSERT INTO `spelloverride` VALUES ('4994', '6223');
INSERT INTO `spelloverride` VALUES ('4994', '7648');
INSERT INTO `spelloverride` VALUES ('4994', '11671');
INSERT INTO `spelloverride` VALUES ('4994', '11672');
INSERT INTO `spelloverride` VALUES ('4994', '11711');
INSERT INTO `spelloverride` VALUES ('4994', '11712');
INSERT INTO `spelloverride` VALUES ('4994', '11713');
INSERT INTO `spelloverride` VALUES ('4994', '18265');
INSERT INTO `spelloverride` VALUES ('4994', '18376');
INSERT INTO `spelloverride` VALUES ('4994', '18671');
INSERT INTO `spelloverride` VALUES ('4994', '18879');
INSERT INTO `spelloverride` VALUES ('4994', '18880');
INSERT INTO `spelloverride` VALUES ('4994', '18881');
INSERT INTO `spelloverride` VALUES ('4994', '21068');
INSERT INTO `spelloverride` VALUES ('4994', '23439');
INSERT INTO `spelloverride` VALUES ('4994', '23642');
INSERT INTO `spelloverride` VALUES ('4994', '25311');
INSERT INTO `spelloverride` VALUES ('4994', '27216');
INSERT INTO `spelloverride` VALUES ('4994', '27218');
INSERT INTO `spelloverride` VALUES ('4994', '27243');
INSERT INTO `spelloverride` VALUES ('4994', '27264');
INSERT INTO `spelloverride` VALUES ('4994', '27285');
INSERT INTO `spelloverride` VALUES ('4994', '28829');
INSERT INTO `spelloverride` VALUES ('4994', '30911');
INSERT INTO `spelloverride` VALUES ('4994', '30938');
INSERT INTO `spelloverride` VALUES ('4994', '31405');
INSERT INTO `spelloverride` VALUES ('4994', '32063');
INSERT INTO `spelloverride` VALUES ('4994', '32197');
INSERT INTO `spelloverride` VALUES ('4994', '32863');
INSERT INTO `spelloverride` VALUES ('4994', '32865');
INSERT INTO `spelloverride` VALUES ('4994', '35195');
INSERT INTO `spelloverride` VALUES ('4994', '36123');
INSERT INTO `spelloverride` VALUES ('4994', '37113');
INSERT INTO `spelloverride` VALUES ('4994', '38252');
INSERT INTO `spelloverride` VALUES ('4994', '39212');
INSERT INTO `spelloverride` VALUES ('4994', '39367');
INSERT INTO `spelloverride` VALUES ('5059', '585');
INSERT INTO `spelloverride` VALUES ('5059', '591');
INSERT INTO `spelloverride` VALUES ('5059', '598');
INSERT INTO `spelloverride` VALUES ('5059', '984');
INSERT INTO `spelloverride` VALUES ('5059', '1004');
INSERT INTO `spelloverride` VALUES ('5059', '6060');
INSERT INTO `spelloverride` VALUES ('5059', '8092');
INSERT INTO `spelloverride` VALUES ('5059', '8102');
INSERT INTO `spelloverride` VALUES ('5059', '8103');
INSERT INTO `spelloverride` VALUES ('5059', '8104');
INSERT INTO `spelloverride` VALUES ('5059', '8105');
INSERT INTO `spelloverride` VALUES ('5059', '8106');
INSERT INTO `spelloverride` VALUES ('5059', '10933');
INSERT INTO `spelloverride` VALUES ('5059', '10934');
INSERT INTO `spelloverride` VALUES ('5059', '10945');
INSERT INTO `spelloverride` VALUES ('5059', '10946');
INSERT INTO `spelloverride` VALUES ('5059', '10947');
INSERT INTO `spelloverride` VALUES ('5059', '25363');
INSERT INTO `spelloverride` VALUES ('5059', '25364');
INSERT INTO `spelloverride` VALUES ('5059', '25372');
INSERT INTO `spelloverride` VALUES ('5059', '25375');
INSERT INTO `spelloverride` VALUES ('5060', '585');
INSERT INTO `spelloverride` VALUES ('5060', '591');
INSERT INTO `spelloverride` VALUES ('5060', '598');
INSERT INTO `spelloverride` VALUES ('5060', '984');
INSERT INTO `spelloverride` VALUES ('5060', '1004');
INSERT INTO `spelloverride` VALUES ('5060', '6060');
INSERT INTO `spelloverride` VALUES ('5060', '8092');
INSERT INTO `spelloverride` VALUES ('5060', '8102');
INSERT INTO `spelloverride` VALUES ('5060', '8103');
INSERT INTO `spelloverride` VALUES ('5060', '8104');
INSERT INTO `spelloverride` VALUES ('5060', '8105');
INSERT INTO `spelloverride` VALUES ('5060', '8106');
INSERT INTO `spelloverride` VALUES ('5060', '10933');
INSERT INTO `spelloverride` VALUES ('5060', '10934');
INSERT INTO `spelloverride` VALUES ('5060', '10945');
INSERT INTO `spelloverride` VALUES ('5060', '10946');
INSERT INTO `spelloverride` VALUES ('5060', '10947');
INSERT INTO `spelloverride` VALUES ('5060', '25363');
INSERT INTO `spelloverride` VALUES ('5060', '25364');
INSERT INTO `spelloverride` VALUES ('5060', '25372');
INSERT INTO `spelloverride` VALUES ('5060', '25375');
INSERT INTO `spelloverride` VALUES ('5061', '17');
INSERT INTO `spelloverride` VALUES ('5061', '592');
INSERT INTO `spelloverride` VALUES ('5061', '600');
INSERT INTO `spelloverride` VALUES ('5061', '3747');
INSERT INTO `spelloverride` VALUES ('5061', '6065');
INSERT INTO `spelloverride` VALUES ('5061', '6066');
INSERT INTO `spelloverride` VALUES ('5061', '10898');
INSERT INTO `spelloverride` VALUES ('5061', '10899');
INSERT INTO `spelloverride` VALUES ('5061', '10900');
INSERT INTO `spelloverride` VALUES ('5061', '10901');
INSERT INTO `spelloverride` VALUES ('5061', '25217');
INSERT INTO `spelloverride` VALUES ('5061', '25218');
INSERT INTO `spelloverride` VALUES ('5061', '27607');
INSERT INTO `spelloverride` VALUES ('5062', '17');
INSERT INTO `spelloverride` VALUES ('5062', '592');
INSERT INTO `spelloverride` VALUES ('5062', '600');
INSERT INTO `spelloverride` VALUES ('5062', '3747');
INSERT INTO `spelloverride` VALUES ('5062', '6065');
INSERT INTO `spelloverride` VALUES ('5062', '6066');
INSERT INTO `spelloverride` VALUES ('5062', '10898');
INSERT INTO `spelloverride` VALUES ('5062', '10899');
INSERT INTO `spelloverride` VALUES ('5062', '10900');
INSERT INTO `spelloverride` VALUES ('5062', '10901');
INSERT INTO `spelloverride` VALUES ('5062', '25217');
INSERT INTO `spelloverride` VALUES ('5062', '25218');
INSERT INTO `spelloverride` VALUES ('5062', '27607');
INSERT INTO `spelloverride` VALUES ('5063', '17');
INSERT INTO `spelloverride` VALUES ('5063', '592');
INSERT INTO `spelloverride` VALUES ('5063', '600');
INSERT INTO `spelloverride` VALUES ('5063', '3747');
INSERT INTO `spelloverride` VALUES ('5063', '6065');
INSERT INTO `spelloverride` VALUES ('5063', '6066');
INSERT INTO `spelloverride` VALUES ('5063', '10898');
INSERT INTO `spelloverride` VALUES ('5063', '10899');
INSERT INTO `spelloverride` VALUES ('5063', '10900');
INSERT INTO `spelloverride` VALUES ('5063', '10901');
INSERT INTO `spelloverride` VALUES ('5063', '25217');
INSERT INTO `spelloverride` VALUES ('5063', '25218');
INSERT INTO `spelloverride` VALUES ('5063', '27607');
INSERT INTO `spelloverride` VALUES ('5064', '17');
INSERT INTO `spelloverride` VALUES ('5064', '592');
INSERT INTO `spelloverride` VALUES ('5064', '600');
INSERT INTO `spelloverride` VALUES ('5064', '3747');
INSERT INTO `spelloverride` VALUES ('5064', '6065');
INSERT INTO `spelloverride` VALUES ('5064', '6066');
INSERT INTO `spelloverride` VALUES ('5064', '10898');
INSERT INTO `spelloverride` VALUES ('5064', '10899');
INSERT INTO `spelloverride` VALUES ('5064', '10900');
INSERT INTO `spelloverride` VALUES ('5064', '10901');
INSERT INTO `spelloverride` VALUES ('5064', '25217');
INSERT INTO `spelloverride` VALUES ('5064', '25218');
INSERT INTO `spelloverride` VALUES ('5064', '27607');
INSERT INTO `spelloverride` VALUES ('5065', '17');
INSERT INTO `spelloverride` VALUES ('5065', '592');
INSERT INTO `spelloverride` VALUES ('5065', '600');
INSERT INTO `spelloverride` VALUES ('5065', '3747');
INSERT INTO `spelloverride` VALUES ('5065', '6065');
INSERT INTO `spelloverride` VALUES ('5065', '6066');
INSERT INTO `spelloverride` VALUES ('5065', '10898');
INSERT INTO `spelloverride` VALUES ('5065', '10899');
INSERT INTO `spelloverride` VALUES ('5065', '10900');
INSERT INTO `spelloverride` VALUES ('5065', '10901');
INSERT INTO `spelloverride` VALUES ('5065', '25217');
INSERT INTO `spelloverride` VALUES ('5065', '25218');
INSERT INTO `spelloverride` VALUES ('5065', '27607');
INSERT INTO `spelloverride` VALUES ('5066', '589');
INSERT INTO `spelloverride` VALUES ('5066', '594');
INSERT INTO `spelloverride` VALUES ('5066', '970');
INSERT INTO `spelloverride` VALUES ('5066', '992');
INSERT INTO `spelloverride` VALUES ('5066', '2767');
INSERT INTO `spelloverride` VALUES ('5066', '10892');
INSERT INTO `spelloverride` VALUES ('5066', '10893');
INSERT INTO `spelloverride` VALUES ('5066', '10894');
INSERT INTO `spelloverride` VALUES ('5066', '15407');
INSERT INTO `spelloverride` VALUES ('5066', '16568');
INSERT INTO `spelloverride` VALUES ('5066', '17165');
INSERT INTO `spelloverride` VALUES ('5066', '17311');
INSERT INTO `spelloverride` VALUES ('5066', '17312');
INSERT INTO `spelloverride` VALUES ('5066', '17313');
INSERT INTO `spelloverride` VALUES ('5066', '17314');
INSERT INTO `spelloverride` VALUES ('5066', '18807');
INSERT INTO `spelloverride` VALUES ('5066', '22919');
INSERT INTO `spelloverride` VALUES ('5066', '23953');
INSERT INTO `spelloverride` VALUES ('5066', '25367');
INSERT INTO `spelloverride` VALUES ('5066', '25368');
INSERT INTO `spelloverride` VALUES ('5066', '25387');
INSERT INTO `spelloverride` VALUES ('5066', '26044');
INSERT INTO `spelloverride` VALUES ('5066', '26143');
INSERT INTO `spelloverride` VALUES ('5066', '27605');
INSERT INTO `spelloverride` VALUES ('5066', '28310');
INSERT INTO `spelloverride` VALUES ('5066', '29407');
INSERT INTO `spelloverride` VALUES ('5066', '29570');
INSERT INTO `spelloverride` VALUES ('5066', '32417');
INSERT INTO `spelloverride` VALUES ('5066', '34914');
INSERT INTO `spelloverride` VALUES ('5066', '34916');
INSERT INTO `spelloverride` VALUES ('5066', '34917');
INSERT INTO `spelloverride` VALUES ('5066', '35507');
INSERT INTO `spelloverride` VALUES ('5066', '37276');
INSERT INTO `spelloverride` VALUES ('5066', '37330');
INSERT INTO `spelloverride` VALUES ('5066', '37621');
INSERT INTO `spelloverride` VALUES ('5066', '38243');
INSERT INTO `spelloverride` VALUES ('5142', '403');
INSERT INTO `spelloverride` VALUES ('5142', '421');
INSERT INTO `spelloverride` VALUES ('5142', '529');
INSERT INTO `spelloverride` VALUES ('5142', '548');
INSERT INTO `spelloverride` VALUES ('5142', '915');
INSERT INTO `spelloverride` VALUES ('5142', '930');
INSERT INTO `spelloverride` VALUES ('5142', '943');
INSERT INTO `spelloverride` VALUES ('5142', '2860');
INSERT INTO `spelloverride` VALUES ('5142', '6041');
INSERT INTO `spelloverride` VALUES ('5142', '10391');
INSERT INTO `spelloverride` VALUES ('5142', '10392');
INSERT INTO `spelloverride` VALUES ('5142', '10605');
INSERT INTO `spelloverride` VALUES ('5142', '15207');
INSERT INTO `spelloverride` VALUES ('5142', '15208');
INSERT INTO `spelloverride` VALUES ('5142', '25439');
INSERT INTO `spelloverride` VALUES ('5142', '25442');
INSERT INTO `spelloverride` VALUES ('5142', '25448');
INSERT INTO `spelloverride` VALUES ('5142', '25449');
INSERT INTO `spelloverride` VALUES ('5142', '37661');
INSERT INTO `spelloverride` VALUES ('5147', '20116');
INSERT INTO `spelloverride` VALUES ('5147', '20922');
INSERT INTO `spelloverride` VALUES ('5147', '20923');
INSERT INTO `spelloverride` VALUES ('5147', '20924');
INSERT INTO `spelloverride` VALUES ('5147', '26573');
INSERT INTO `spelloverride` VALUES ('5147', '27173');
INSERT INTO `spelloverride` VALUES ('5147', '32773');
INSERT INTO `spelloverride` VALUES ('5147', '33559');
INSERT INTO `spelloverride` VALUES ('5147', '36946');
INSERT INTO `spelloverride` VALUES ('5147', '37553');
INSERT INTO `spelloverride` VALUES ('5147', '38385');
INSERT INTO `spelloverride` VALUES ('5148', '2912');
INSERT INTO `spelloverride` VALUES ('5148', '8949');
INSERT INTO `spelloverride` VALUES ('5148', '8950');
INSERT INTO `spelloverride` VALUES ('5148', '8951');
INSERT INTO `spelloverride` VALUES ('5148', '9875');
INSERT INTO `spelloverride` VALUES ('5148', '9876');
INSERT INTO `spelloverride` VALUES ('5148', '21668');
INSERT INTO `spelloverride` VALUES ('5148', '25298');
INSERT INTO `spelloverride` VALUES ('5148', '26986');
INSERT INTO `spelloverride` VALUES ('5148', '35243');
INSERT INTO `spelloverride` VALUES ('5148', '38935');
INSERT INTO `spelloverride` VALUES ('5236', '1130');
INSERT INTO `spelloverride` VALUES ('5236', '14323');
INSERT INTO `spelloverride` VALUES ('5236', '14324');
INSERT INTO `spelloverride` VALUES ('5236', '14325');
INSERT INTO `spelloverride` VALUES ('5236', '31615');
INSERT INTO `spelloverride` VALUES ('5237', '1130');
INSERT INTO `spelloverride` VALUES ('5237', '14323');
INSERT INTO `spelloverride` VALUES ('5237', '14324');
INSERT INTO `spelloverride` VALUES ('5237', '14325');
INSERT INTO `spelloverride` VALUES ('5237', '31615');
INSERT INTO `spelloverride` VALUES ('5238', '1130');
INSERT INTO `spelloverride` VALUES ('5238', '14323');
INSERT INTO `spelloverride` VALUES ('5238', '14324');
INSERT INTO `spelloverride` VALUES ('5238', '14325');
INSERT INTO `spelloverride` VALUES ('5238', '31615');
INSERT INTO `spelloverride` VALUES ('5239', '1130');
INSERT INTO `spelloverride` VALUES ('5239', '14323');
INSERT INTO `spelloverride` VALUES ('5239', '14324');
INSERT INTO `spelloverride` VALUES ('5239', '14325');
INSERT INTO `spelloverride` VALUES ('5239', '31615');
INSERT INTO `spelloverride` VALUES ('5240', '1130');
INSERT INTO `spelloverride` VALUES ('5240', '14323');
INSERT INTO `spelloverride` VALUES ('5240', '14324');
INSERT INTO `spelloverride` VALUES ('5240', '14325');
INSERT INTO `spelloverride` VALUES ('5240', '31615');
INSERT INTO `spelloverride` VALUES ('5494', '1463');
INSERT INTO `spelloverride` VALUES ('5494', '8494');
INSERT INTO `spelloverride` VALUES ('5494', '8495');
INSERT INTO `spelloverride` VALUES ('5494', '10191');
INSERT INTO `spelloverride` VALUES ('5494', '10192');
INSERT INTO `spelloverride` VALUES ('5494', '10193');
INSERT INTO `spelloverride` VALUES ('5494', '17740');
INSERT INTO `spelloverride` VALUES ('5494', '17741');
INSERT INTO `spelloverride` VALUES ('5494', '27131');
INSERT INTO `spelloverride` VALUES ('5494', '29880');
INSERT INTO `spelloverride` VALUES ('5494', '30973');
INSERT INTO `spelloverride` VALUES ('5494', '31635');
INSERT INTO `spelloverride` VALUES ('5494', '35064');
INSERT INTO `spelloverride` VALUES ('5494', '38151');
INSERT INTO `spelloverride` VALUES ('5634', '17364');
INSERT INTO `spelloverride` VALUES ('5634', '32175');
INSERT INTO `spelloverride` VALUES ('5634', '32176');

# spell_proc_data
DROP TABLE IF EXISTS `spell_proc_data`;

# teleport_coords
ALTER TABLE `teleport_coords`
CHANGE `id` `id` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `mapId` `mapId` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `totrigger` `totrigger` int(10) unsigned NOT NULL DEFAULT '0';

# totemspells
ALTER TABLE `totemspells`
CHANGE `spell` `spell` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `castspell1` `castspell1` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `castspell2` `castspell2` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `castspell3` `castspell3` int(10) unsigned NOT NULL DEFAULT '0';
REPLACE INTO `totemspells` VALUES ('58737', '58738', '0', '0');
REPLACE INTO `totemspells` VALUES ('58739', '58740', '0', '0');
REPLACE INTO `totemspells` VALUES ('58741', '58742', '0', '0');
REPLACE INTO `totemspells` VALUES ('58745', '58744', '0', '0');
REPLACE INTO `totemspells` VALUES ('58746', '58748', '0', '0');
REPLACE INTO `totemspells` VALUES ('58749', '58750', '0', '0');
REPLACE INTO `totemspells` VALUES ('58731', '58732', '0', '0');
REPLACE INTO `totemspells` VALUES ('58734', '58735', '0', '0');
REPLACE INTO `totemspells` VALUES ('61649', '61651', '0', '0');
REPLACE INTO `totemspells` VALUES ('61657', '61660', '0', '0');
REPLACE INTO `totemspells` VALUES ('58580', '25513', '0', '0');
REPLACE INTO `totemspells` VALUES ('58581', '25513', '0', '0');
REPLACE INTO `totemspells` VALUES ('58582', '25513', '0', '0');
REPLACE INTO `totemspells` VALUES ('58699', '58700', '0', '0');
REPLACE INTO `totemspells` VALUES ('58703', '58701', '0', '0');
REPLACE INTO `totemspells` VALUES ('58704', '58702', '0', '0');

# trainer_defs
ALTER TABLE `trainer_defs`
DROP KEY `entry`,
CHANGE `entry` `entry` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `required_skill` `required_skill` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `required_skillvalue` `required_skillvalue` int(11) unsigned DEFAULT '0',
CHANGE `req_class` `req_class` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `RequiredRace` `RequiredRace` int(11) NOT NULL DEFAULT '0',
CHANGE `RequiredReputation` `RequiredReputation` int(11) NOT NULL DEFAULT '0',
CHANGE `RequiredReputationValue` `RequiredReputationValue` int(11) NOT NULL DEFAULT '0',
CHANGE `trainer_type` `trainer_type` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `can_train_gossip_textid` `can_train_gossip_textid` int(11) NOT NULL,
CHANGE `cannot_train_gossip_textid` `cannot_train_gossip_textid` int(11) NOT NULL,
ADD PRIMARY KEY (`entry`);

# trainer_spells
ALTER TABLE `trainer_spells`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`entry`,`cast_spell`,`learn_spell`),
CHANGE `entry` `entry` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `cast_spell` `cast_spell` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `learn_spell` `learn_spell` int(11) unsigned NOT NULL,
CHANGE `spellcost` `spellcost` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `reqspell` `reqspell` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `reqskill` `reqskill` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `reqskillvalue` `reqskillvalue` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `reqlevel` `reqlevel` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `deletespell` `deletespell` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `is_prof` `is_prof` tinyint(1) unsigned NOT NULL DEFAULT '0';

# trainerspelloverride
DROP TABLE IF EXISTS `trainerspelloverride`;
CREATE TABLE `trainerspelloverride` (
  `spellid` int(10) unsigned NOT NULL DEFAULT '0',
  `cost` int(10) unsigned NOT NULL DEFAULT '0',
  `requiredspell` int(10) unsigned NOT NULL DEFAULT '0',
  `deletespell` int(10) unsigned NOT NULL DEFAULT '0',
  `requiredskill` int(10) unsigned NOT NULL DEFAULT '0',
  `requiredskillvalue` int(10) unsigned NOT NULL DEFAULT '0',
  `reqlevel` int(10) unsigned NOT NULL DEFAULT '0',
  `requiredclass` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `spellid` (`spellid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Trainer System';

# transport_creatures
ALTER TABLE `transport_creatures` 
CHANGE `transport_entry` `transport_entry` int(10) unsigned NOT NULL,
CHANGE `creature_entry` `creature_entry` int(10) unsigned NOT NULL,
DROP PRIMARY KEY;

# unit_display_sizes
ALTER TABLE `unit_display_sizes`
CHANGE `DisplayID` `DisplayID` int(11) unsigned NOT NULL,
CHANGE `modelid` `modelid` int(11) unsigned NOT NULL DEFAULT '0';

# vendor_restrictions
ALTER TABLE `vendor_restrictions`
CHANGE `entry` `entry` int(10) unsigned NOT NULL,
CHANGE `racemask` `racemask` int(11) NOT NULL DEFAULT '-1',
CHANGE `reqrepfaction` `reqrepfaction` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `reqrepfactionvalue` `reqrepfactionvalue` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `canbuyattextid` `canbuyattextid` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `cannotbuyattextid` `cannotbuyattextid` int(10) unsigned NOT NULL DEFAULT '0';

# vendors
ALTER TABLE `vendors`
CHANGE `entry` `entry` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `item` `item` int(10) unsigned NOT NULL DEFAULT '0',
CHANGE `amount` `amount` int(11) NOT NULL DEFAULT '0',
CHANGE `max_amount` `max_amount` int(11) NOT NULL DEFAULT '0',
CHANGE `inctime` `inctime` bigint(20) NOT NULL DEFAULT '0',
CHANGE `extended_cost` `extended_cost` int(11) NOT NULL DEFAULT '0';

# weather
ALTER TABLE `weather`
CHANGE `zoneId` `zoneId` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `high_chance` `high_chance` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `high_type` `high_type` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `med_chance` `med_chance` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `med_type` `med_type` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `low_chance` `low_chance` int(11) unsigned NOT NULL DEFAULT '0',
CHANGE `low_type` `low_type` int(11) unsigned NOT NULL DEFAULT '0';

# wordfilter_character_names
ALTER TABLE `wordfilter_character_names`
CHANGE `regex_match` `regex_match` varchar(500) NOT NULL,
CHANGE `regex_ignore_if_matched` `regex_ignore_if_matched` varchar(500) NOT NULL DEFAULT '';

# wordfilter_chat
ALTER TABLE `wordfilter_chat`
CHANGE `regex_match` `regex_match` varchar(500) NOT NULL,
CHANGE `regex_ignore_if_matched` `regex_ignore_if_matched` varchar(500) NOT NULL DEFAULT '';

# worldbroadcast
ALTER TABLE `worldbroadcast`
CHANGE `entry` `entry` int(11) unsigned NOT NULL AUTO_INCREMENT,
CHANGE `text` `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
CHANGE `percent` `percent` int(3) NOT NULL DEFAULT '100';

# worldbroadcast_localized
ALTER TABLE `worldbroadcast_localized` CHANGE `entry` `entry` int(11) NOT NULL;

# worldmap_info
CREATE TABLE `worldmap_info_temp` (
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `screenid` int(10) unsigned DEFAULT '0',
  `type` int(10) unsigned DEFAULT '0',
  `maxplayers` int(10) unsigned DEFAULT '0',
  `minlevel` int(10) unsigned DEFAULT '1',
  `minlevel_heroic` int(10) unsigned NOT NULL DEFAULT '0',
  `repopx` float DEFAULT '0',
  `repopy` float DEFAULT '0',
  `repopz` float DEFAULT '0',
  `repopentry` int(10) unsigned DEFAULT '0',
  `area_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `cooldown` int(10) unsigned NOT NULL DEFAULT '0',
  `lvl_mod_a` int(10) unsigned NOT NULL DEFAULT '0',
  `required_quest` int(10) unsigned NOT NULL DEFAULT '0',
  `required_item` int(10) unsigned NOT NULL DEFAULT '0',
  `heroic_keyid_1` int(30) NOT NULL DEFAULT '0',
  `heroic_keyid_2` int(30) NOT NULL DEFAULT '0',
  `viewingDistance` float NOT NULL DEFAULT '80',
  `required_checkpoint` int(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='World System';
INSERT INTO `worldmap_info_temp` (SELECT * FROM `worldmap_info`);
DROP TABLE IF EXISTS `worldmap_info`;
RENAME TABLE `worldmap_info_temp` TO `worldmap_info`;

# worldmap_info_localized
ALTER TABLE `worldmap_info_localized` CHANGE `entry` `entry` int(11) NOT NULL;

# worldstring_tables
ALTER TABLE `worldstring_tables` CHANGE `entry` `entry` int(11) NOT NULL AUTO_INCREMENT;

# worldstring_tables_localized
ALTER TABLE `worldstring_tables_localized` CHANGE `entry` `entry` int(11) NOT NULL;

# zoneguards
CREATE TABLE `zoneguards_temp` (
  `zone` int(10) unsigned NOT NULL,
  `horde_entry` int(10) unsigned NOT NULL DEFAULT '0',
  `alliance_entry` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`alliance_entry`,`horde_entry`,`zone`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='World System';
INSERT INTO `zoneguards_temp` (SELECT * FROM `zoneguards`);
DROP TABLE IF EXISTS `zoneguards`;
RENAME TABLE `zoneguards_temp` TO `zoneguards`;

# Done, by ClaudeNegm #
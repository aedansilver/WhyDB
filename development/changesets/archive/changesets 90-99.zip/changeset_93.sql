/*
 * WhyDB changeset 93
 * 
 * enhancements to loot_gameobjects
 * fixed quests started by Beached Sea Creatures and Turtles in Darkshore
 * removed old epic mount replacement quests
 * fixed training dummies
 * fixed Death Knight quest If Chaos Drives, Let Suffering Hold The Reins
 *
 */

UPDATE `db_version` SET `revision`=121,`changeset`=93,`arcemu_rev`=3522,`last_db_update_by`='Black';

-- Giant Clams, only 2744 has loot on Wowhead
DELETE FROM `loot_gameobjects` WHERE `entryid` IN (19017,19018,179264);
INSERT INTO `loot_gameobjects` SELECT NULL,19017,`itemid`,`normal10percentchance`,`normal25percentchance`,`heroic10percentchance`,`heroic25percentchance`,`mincount`,`maxcount`,`ffa_loot` FROM `loot_gameobjects` WHERE `entryid`=2744;
INSERT INTO `loot_gameobjects` SELECT NULL,19018,`itemid`,`normal10percentchance`,`normal25percentchance`,`heroic10percentchance`,`heroic25percentchance`,`mincount`,`maxcount`,`ffa_loot` FROM `loot_gameobjects` WHERE `entryid`=2744;
INSERT INTO `loot_gameobjects` SELECT NULL,179264,`itemid`,`normal10percentchance`,`normal25percentchance`,`heroic10percentchance`,`heroic25percentchance`,`mincount`,`maxcount`,`ffa_loot` FROM `loot_gameobjects` WHERE `entryid`=2744;
-- Deepmoss Eggs, only 19541 has loot on Wowhead
DELETE FROM `loot_gameobjects` WHERE `entryid`=19542;
INSERT INTO `loot_gameobjects` SELECT NULL,19542,`itemid`,`normal10percentchance`,`normal25percentchance`,`heroic10percentchance`,`heroic25percentchance`,`mincount`,`maxcount`,`ffa_loot` FROM `loot_gameobjects` WHERE `entryid`=19541;
-- class tomes in A Dusty Tome
UPDATE `loot_gameobjects` SET `normal10percentchance`=20,`normal25percentchance`=20,`heroic10percentchance`=20,`heroic25percentchance`=20 WHERE `entryid`=179547 AND `itemid` IN (18356,18357,18358,18359,18360,18361,18362,18363,18364);
-- Silithid Eggs
UPDATE `loot_gameobjects` SET `normal25percentchance`=100,`heroic10percentchance`=100,`heroic25percentchance`=100,`maxcount`=3 WHERE `entryid`=3685;
-- missing drop rates for non-normal modes
UPDATE `loot_gameobjects` SET `normal25percentchance`=100,`heroic10percentchance`=100,`heroic25percentchance`=100 WHERE `entryid` IN (13360,13872,13873,177464,178105,178106,181589,181590,181593,19022,19869,19870,19871,19872,19873,20807) AND `itemid` IN (5273,5273,5329,15043,16581,23492,23495,23501,5464,5798,5869);

-- fix total mess for Beached Sea Turtle/Creature
DELETE FROM `gameobject_quest_starter` WHERE `quest` IN (4722,4723,4725,4727,4728,4730,4731,4732,4733);
INSERT INTO `gameobject_quest_starter` VALUES (176190, 4722);
INSERT INTO `gameobject_quest_starter` VALUES (175233, 4723);
INSERT INTO `gameobject_quest_starter` VALUES (176197, 4725);
INSERT INTO `gameobject_quest_starter` VALUES (176196, 4727);
INSERT INTO `gameobject_quest_starter` VALUES (175226, 4728);
INSERT INTO `gameobject_quest_starter` VALUES (175227, 4730);
INSERT INTO `gameobject_quest_starter` VALUES (176198, 4731);
INSERT INTO `gameobject_quest_starter` VALUES (176191, 4732);
INSERT INTO `gameobject_quest_starter` VALUES (175230, 4733);

-- drop old (pre 1.4) epic mount replacement quests
DELETE FROM `quests` WHERE `entry` IN (7660,7661,7662,7663,7664,7665,7671,7672,7673,7674,7675,7676,7677,7678);
DELETE FROM `creature_quest_starter` WHERE `quest` IN (7660,7661,7662,7663,7664,7665,7671,7672,7673,7674,7675,7676,7677,7678);
DELETE FROM `creature_quest_finisher` WHERE `quest` IN (7660,7661,7662,7663,7664,7665,7671,7672,7673,7674,7675,7676,7677,7678);
UPDATE `creature_proto` SET `npcflags`=`npcflags` & ~2 WHERE `entry` IN (384,1261,3362,3685,4730,7952,7955); -- remove quest flag

-- fix training dummies - credits to markg85, MesoX and Black
UPDATE `creature_proto` SET `isTrainingDummy` = 1 WHERE `entry` IN (SELECT `entry` FROM `creature_names` WHERE `name` LIKE '%training%' OR `name` LIKE '%combat dummy%' OR `name` LIKE '%practice dummy') OR `entry` IN (19139,25297,32547,33229);

-- If Chaos Drives, Let Suffering Hold The Reins - credits to nftbu
UPDATE `quests` SET `ReqKillMobOrGOId1`='28763',`ReqKillMobOrGOId2`='28764' WHERE `entry`='12678';
UPDATE `creature_names` SET `killcredit1`='28764' WHERE `entry`='28576';
UPDATE `creature_names` SET `killcredit1`='28764' WHERE `entry`='28577';
UPDATE `creature_names` SET `killcredit1`='28764' WHERE `entry`='28660';
UPDATE `creature_names` SET `killcredit1`='28764' WHERE `entry`='28662';

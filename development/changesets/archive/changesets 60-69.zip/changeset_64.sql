UPDATE db_version SET revision = 11, changeset = 64 WHERE db_name LIKE 'WhyDB';

-- update arcemu flags for spirit healers
UPDATE `creature_proto` SET `npcflags`='16384' WHERE (`entry`='6491');

-- fully reworked graveyards

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for graveyards
-- ----------------------------
DROP TABLE IF EXISTS `graveyards`;
CREATE TABLE `graveyards` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `zoneid` int(10) unsigned NOT NULL default '0',
  `adjacentzoneid` int(10) unsigned NOT NULL default '0',
  `mapid` int(10) unsigned NOT NULL default '0',
  `faction` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2001 DEFAULT CHARSET=latin1 COMMENT='Graveyard System';

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `graveyards` VALUES ('1', '-9115', '423', '96', '0', '12', '1519', '0', '0', 'Stormwind');
INSERT INTO `graveyards` VALUES ('2', '-9194.31', '-2313.26', '88.8265', '0', '44', '0', '0', '3', 'Redridge Mountains');
INSERT INTO `graveyards` VALUES ('3', '-10774.3', '-1189.67', '33.1494', '0', '10', '42', '0', '0', 'Duskwood, Darkshire');
INSERT INTO `graveyards` VALUES ('4', '-10546.9', '1197.24', '31.7263', '0', '40', '108', '0', '3', 'Westfall, Sentinel Hill');
INSERT INTO `graveyards` VALUES ('5', '-5687', '-515', '398', '0', '1', '1537', '0', '3', 'Dun Morogh');
INSERT INTO `graveyards` VALUES ('6', '-5351.23', '-2881.58', '340.942', '0', '38', '144', '0', '0', 'Loch Modan, Thelsamar');
INSERT INTO `graveyards` VALUES ('7', '-3289.12', '-2435.99', '18.5966', '0', '11', '0', '0', '3', 'Wetlands, Crossroads');
INSERT INTO `graveyards` VALUES ('8', '-6289.91', '-3493.11', '251.483', '0', '3', '0', '0', '3', 'Badlands, Graveyard NE ');
INSERT INTO `graveyards` VALUES ('10', '-592.601', '-2523.49', '91.788', '0', '17', '380', '1', '1', 'The Barrens, The Crossroads');
INSERT INTO `graveyards` VALUES ('31', '-448.311', '2512.65', '93.0773', '0', '405', '2405', '1', '3', 'Desolace, Ethel Rethor');
INSERT INTO `graveyards` VALUES ('32', '233.458', '-4793.73', '10.1881', '0', '14', '1637', '1', '3', 'Durotar, Razor Hill');
INSERT INTO `graveyards` VALUES ('33', '1357.1', '-4412.01', '28.3841', '0', '14', '1637', '1', '3', 'Durotar, Orgrimmar');
INSERT INTO `graveyards` VALUES ('34', '-2944.56', '-153.215', '65.786', '0', '215', '220', '1', '1', 'Mulgore, Red Cloud Mesa');
INSERT INTO `graveyards` VALUES ('35', '6739.19', '209.993', '23.2846', '0', '148', '442', '1', '0', 'Darkshore, Auberdine');
INSERT INTO `graveyards` VALUES ('36', '-11110.4', '-1833.24', '71.8642', '0', '41', '2563', '0', '3', 'Deadwind Pass, Morgan\'s Plot');
INSERT INTO `graveyards` VALUES ('39', '-4656', '-1765', '-41', '0', '400', '0', '1', '3', 'Thousand Needles, The Great Lift');
INSERT INTO `graveyards` VALUES ('49', '-661.528', '-485.309', '385.888', '0', '268', '0', '37', '1', 'Plains of Snow - Horde Start');
INSERT INTO `graveyards` VALUES ('70', '-6432.26', '-278.292', '3.79411', '0', '1377', '3077', '1', '3', 'Silithus, Valor\'s Rest');
INSERT INTO `graveyards` VALUES ('89', '-2175.19', '-342.027', '-5.51232', '0', '215', '222', '1', '1', 'Mulgore, Bloodhoof Village');
INSERT INTO `graveyards` VALUES ('90', '10054.3', '2117.12', '1329.63', '0', '1657', '1657', '1', '0', 'Teldrassil, Darnassus');
INSERT INTO `graveyards` VALUES ('91', '9701.25', '945.62', '1291.36', '0', '141', '186', '1', '3', 'Teldrassil, Dolanaar');
INSERT INTO `graveyards` VALUES ('92', '2633.41', '-629.735', '107.581', '0', '331', '415', '1', '0', 'Ashenvale, Astranaar');
INSERT INTO `graveyards` VALUES ('93', '10384.8', '811.531', '1317.54', '0', '141', '256', '1', '3', 'Teldrassil, Aldrassil');
INSERT INTO `graveyards` VALUES ('94', '1882.94', '1629.11', '94.4175', '0', '85', '154', '0', '1', 'Tirisfal Glades, Deathknell');
INSERT INTO `graveyards` VALUES ('96', '1822.61', '214.674', '60.1402', '0', '85', '1497', '0', '1', 'Tirisfal Glades, Undercity');
INSERT INTO `graveyards` VALUES ('97', '516.194', '1589.81', '127.545', '0', '130', '228', '0', '3', 'Silverpine Forest, The Sepulcher');
INSERT INTO `graveyards` VALUES ('98', '-18.6777', '-981.171', '55.8377', '0', '267', '272', '0', '1', 'Hillsbrad Foothills, Tarren Mill');
INSERT INTO `graveyards` VALUES ('99', '-1307.66', '-3192.15', '37.7853', '0', '45', '0', '0', '3', 'Arathi Highlands, Eastern Road');
INSERT INTO `graveyards` VALUES ('100', '-6164.23', '336.321', '399.793', '0', '1', '77', '0', '0', 'Dun Morogh, Anvilmar');
INSERT INTO `graveyards` VALUES ('101', '-5680.04', '-518.92', '396.274', '0', '1', '131', '0', '3', 'Dun Morogh, Kharanos');
INSERT INTO `graveyards` VALUES ('102', '-5049.45', '-809.697', '495.127', '0', '1', '1537', '0', '0', 'Dun Morogh, Ironforge');
INSERT INTO `graveyards` VALUES ('103', '-6805', '-2287.19', '280.752', '0', '3', '340', '0', '1', 'Badlands, Kargath');
INSERT INTO `graveyards` VALUES ('104', '-9403.25', '-2037.69', '58.3687', '0', '44', '69', '0', '3', 'Redridge Mountains, Lakeshire');
INSERT INTO `graveyards` VALUES ('105', '-8935.33', '-188.646', '80.4165', '0', '12', '9', '0', '0', 'Elwynn Forest, Northshire');
INSERT INTO `graveyards` VALUES ('106', '-9339.46', '171.408', '61.5618', '0', '12', '1519', '0', '3', 'Elwynn Forest, Goldshire');
INSERT INTO `graveyards` VALUES ('107', '-9151.98', '410.944', '92.6966', '0', '12', '1519', '0', '0', 'Elwynn Forest, Stormwind');
INSERT INTO `graveyards` VALUES ('108', '-10567.8', '-3377.2', '22.2532', '0', '8', '75', '0', '1', 'Swamp of Sorrows, Stonard');
INSERT INTO `graveyards` VALUES ('109', '-14285', '288.447', '32.332', '0', '33', '35', '0', '3', 'Stranglethorn Vale, Booty Bay');
INSERT INTO `graveyards` VALUES ('129', '8706', '965', '13.27', '0', '141', '702', '1', '3', 'Teldrassil, Rut\'theran Village');
INSERT INTO `graveyards` VALUES ('149', '-732.799', '-592.502', '22.663', '0', '267', '2369', '0', '0', 'Hillsbrad Foothills, Southshore');
INSERT INTO `graveyards` VALUES ('169', '-157.409', '31.2063', '77.0506', '0', '2597', '3301', '30', '3', 'Alterac Valley, Snowfall Graveyard (Mid)');
INSERT INTO `graveyards` VALUES ('189', '-3525.71', '-4315.46', '6.99561', '0', '15', '513', '1', '0', 'Dustwallow Marsh, Theramore Isle');
INSERT INTO `graveyards` VALUES ('209', '-7190.95', '-3944.65', '9.22739', '0', '440', '976', '1', '3', 'Tanaris, Gadgetzan');
INSERT INTO `graveyards` VALUES ('229', '-2517.75', '-1972.64', '91.7838', '0', '17', '378', '1', '1', 'The Barrens, Camp Taurajo');
INSERT INTO `graveyards` VALUES ('249', '-1081.4', '-3478.68', '63.6066', '0', '17', '392', '1', '3', 'The Barrens, Ratchet');
INSERT INTO `graveyards` VALUES ('269', '-448.189', '-1027.86', '430.724', '0', '268', '0', '37', '0', 'Plains of Snow - Alliance Start');
INSERT INTO `graveyards` VALUES ('289', '2348.67', '492.027', '33.3665', '0', '85', '1497', '0', '1', 'Tirisfal Glades, Brill');
INSERT INTO `graveyards` VALUES ('309', '-4596.4', '3229.43', '8.99376', '0', '357', '1116', '1', '0', 'Feralas, Feathermoon Stronghold');
INSERT INTO `graveyards` VALUES ('310', '-4439.97', '370.153', '51.3566', '0', '357', '1099', '1', '1', 'Feralas, Camp Mojache');
INSERT INTO `graveyards` VALUES ('329', '-5530.28', '-3459.28', '-45.7444', '0', '400', '439', '1', '3', 'Thousand Needles, Shimmering Flats');
INSERT INTO `graveyards` VALUES ('349', '323.513', '-2227.2', '137.617', '0', '47', '348', '0', '0', 'The Hinterlands, Aerie Peak');
INSERT INTO `graveyards` VALUES ('369', '2681.06', '-4009.75', '107.849', '0', '16', '3137', '1', '3', 'Azshara, Talrendis Point');
INSERT INTO `graveyards` VALUES ('370', '-10846.6', '-2949.49', '13.2272', '0', '4', '1437', '0', '3', 'Blasted Lands, Dreadmaul Hold');
INSERT INTO `graveyards` VALUES ('389', '-11542.6', '-228.637', '27.8427', '0', '33', '0', '0', '3', 'Stranglethorn Vale, Northern Stranglethorn');
INSERT INTO `graveyards` VALUES ('409', '898.261', '434.53', '65.7279', '0', '406', '1076', '1', '3', 'Stonetalon Mountains, Webwinder Path');
INSERT INTO `graveyards` VALUES ('429', '2604.52', '-543.39', '88.9996', '0', '85', '1497', '0', '3', 'Tirisfal Glades, Faol\'s Rest');
INSERT INTO `graveyards` VALUES ('449', '3806.54', '-1600.29', '218.831', '0', '361', '2478', '1', '3', 'Felwood, Morlos\'Aran');
INSERT INTO `graveyards` VALUES ('450', '-7205.56', '-2436.67', '-218.161', '0', '490', '1942', '1', '3', 'Un\'Goro Crater, The Marshlands');
INSERT INTO `graveyards` VALUES ('469', '4291.28', '96.9557', '43.0753', '0', '148', '2077', '1', '3', 'Darkshore, Twilight Vale');
INSERT INTO `graveyards` VALUES ('489', '-3347.72', '-856.713', '1.05955', '0', '11', '298', '0', '3', 'Wetlands, Baradin Bay');
INSERT INTO `graveyards` VALUES ('509', '908.323', '-1520.29', '55.0372', '0', '28', '3197', '0', '3', 'Western Plaguelands, Chillwind Camp');
INSERT INTO `graveyards` VALUES ('510', '2055.74', '-5020.95', '74.8656', '0', '139', '4363', '0', '3', 'Eastern Plaguelands, Pestilent Scar');
INSERT INTO `graveyards` VALUES ('511', '6875.76', '-4661.54', '701.094', '0', '618', '2255', '1', '3', 'Winterspring, Everlook');
INSERT INTO `graveyards` VALUES ('512', '2421.72', '-2953.62', '123.473', '0', '331', '2637', '1', '3', 'Ashenvale, Kargathia');
INSERT INTO `graveyards` VALUES ('529', '16310.3', '16268.9', '69.4444', '0', '22', '0', '451', '3', 'Programmer Isle');
INSERT INTO `graveyards` VALUES ('549', '16223.8', '16278.6', '20.8913', '0', '22', '0', '451', '3', 'Programmer Isle');
INSERT INTO `graveyards` VALUES ('569', '1750.34', '-669.79', '44.5698', '0', '28', '0', '0', '3', 'Western Plaguelands, Bulwark');
INSERT INTO `graveyards` VALUES ('589', '16310.3', '16268.9', '69.4444', '0', '876', '0', '1', '3', 'GM Island');
INSERT INTO `graveyards` VALUES ('609', '2942.76', '-6037.13', '5.16996', '0', '16', '1231', '1', '3', 'Azshara, Southridge Beach');
INSERT INTO `graveyards` VALUES ('610', '-1437.67', '-610.089', '51.1619', '0', '2597', '0', '30', '1', 'Alterac Valley, Horde Safe');
INSERT INTO `graveyards` VALUES ('611', '873.002', '-491.284', '96.5419', '0', '2597', '0', '30', '0', 'Alterac Valley, Alliance Safe');
INSERT INTO `graveyards` VALUES ('629', '908.323', '-1520.29', '55.0372', '0', '876', '0', '0', '3', 'TEST for GM Client Only - Do Not Bug');
INSERT INTO `graveyards` VALUES ('630', '4788.78', '-6845', '89.7901', '0', '16', '1219', '1', '3', 'Azshara, Legash Encampment');
INSERT INTO `graveyards` VALUES ('631', '-3127.69', '-3046.94', '33.8313', '0', '15', '496', '1', '1', 'Dustwallow Marsh, Brackenwall Village');
INSERT INTO `graveyards` VALUES ('633', '7426', '-2809', '464', '0', '493', '0', '1', '3', 'Moonglade');
INSERT INTO `graveyards` VALUES ('634', '1392', '-3701', '77', '0', '139', '2262', '0', '3', 'Eastern Plaguelands, Darrowshire');
INSERT INTO `graveyards` VALUES ('635', '5935.47', '-1217.75', '383.202', '0', '361', '1767', '1', '3', 'Felwood, Irontree Woods');
INSERT INTO `graveyards` VALUES ('636', '-6450.61', '-1113.51', '308.022', '0', '51', '1446', '0', '3', 'Searing Gorge, Thorium Point');
INSERT INTO `graveyards` VALUES ('649', '-778', '-4985', '19', '0', '14', '367', '1', '1', 'Durotar, Sen\'jin Village');
INSERT INTO `graveyards` VALUES ('669', '16614.8', '16663', '21.3422', '0', '22', '0', '451', '3', 'Programmer Isle, Bucklers Cemetery 2');
INSERT INTO `graveyards` VALUES ('670', '16620.7', '16622.7', '21.3382', '0', '22', '0', '451', '3', 'Programmer Isle, Bucklers Cemetery 1');
INSERT INTO `graveyards` VALUES ('671', '16619.5', '16577.5', '43.9018', '0', '22', '0', '451', '3', 'Programmer Isle, Bucklers Cemetery 3');
INSERT INTO `graveyards` VALUES ('689', '676', '-374', '30', '0', '2597', '3303', '30', '3', 'Alterac Valley, Stormpike Graveyard (Hi)');
INSERT INTO `graveyards` VALUES ('690', '-1090.48', '-253.309', '57.6724', '0', '2597', '3297', '30', '3', 'Alterac Valley, Frostwolf Graveyard (Lo)');
INSERT INTO `graveyards` VALUES ('709', '-634.635', '-4296.03', '40.5254', '0', '14', '363', '1', '1', 'Durotar, Valley of Trials');
INSERT INTO `graveyards` VALUES ('729', '73.4178', '-496.433', '48.7319', '0', '2597', '0', '30', '0', 'Alterac Valley, PvP Alliance Choke Graveyard (A-choke)');
INSERT INTO `graveyards` VALUES ('749', '-531.218', '-405.231', '49.5514', '0', '2597', '0', '30', '1', 'Alterac Valley, PvP Horde Choke Graveyard (H-choke)');
INSERT INTO `graveyards` VALUES ('750', '-1496.07', '-333.338', '101.135', '0', '2597', '0', '30', '3', 'Alterac Valley, Frostwolf Relief Hut (H-base)');
INSERT INTO `graveyards` VALUES ('751', '643', '44', '69.7402', '0', '2597', '0', '30', '3', 'Alterac Valley, Stormpike Aid Station (A-base)');
INSERT INTO `graveyards` VALUES ('769', '1523.81', '1481.76', '352.008', '0', '3277', '0', '489', '0', 'Warsong Gulch - Alliance Enter Loc');
INSERT INTO `graveyards` VALUES ('770', '933.331', '1433.72', '345.536', '0', '3277', '0', '489', '1', 'Warsong Gulch - Horde Enter Loc');
INSERT INTO `graveyards` VALUES ('771', '1415.33', '1554.79', '343.156', '0', '3277', '0', '489', '0', 'Warsong Gulch - Alliance Rez Loc');
INSERT INTO `graveyards` VALUES ('772', '1029.14', '1387.49', '340.836', '0', '3277', '0', '489', '1', 'Warsong Gulch - Horde Rez Loc');
INSERT INTO `graveyards` VALUES ('789', '-291', '-4374', '107', '0', '47', '307', '0', '3', 'The Hinterlands, The Overlook Cliffs');
INSERT INTO `graveyards` VALUES ('809', '1035.27', '-2104.28', '122.945', '0', '3277', '0', '1', '1', 'Warsong Gulch - Horde Exit Loc');
INSERT INTO `graveyards` VALUES ('810', '1459.17', '-1858.67', '124.762', '0', '3277', '0', '1', '0', 'Warsong Gulch - Alliance Exit Loc');
INSERT INTO `graveyards` VALUES ('829', '101.144', '-184.934', '127.344', '0', '2597', '0', '0', '0', 'Alterac Valley, Alliance Exit');
INSERT INTO `graveyards` VALUES ('830', '536.495', '-1085.72', '106.27', '0', '2597', '0', '0', '1', 'Alterac Valley, Horde Exit');
INSERT INTO `graveyards` VALUES ('849', '-4590.41', '1632.08', '93.9738', '0', '357', '2577', '1', '3', 'Feralas, Dire Maul');
INSERT INTO `graveyards` VALUES ('850', '1177.78', '-4464.24', '21.3539', '0', '14', '1637', '1', '1', 'Durotar, Northern Durotar');
INSERT INTO `graveyards` VALUES ('851', '-981.917', '-74.6465', '20.1265', '0', '215', '1638', '1', '1', 'Mulgore, Thunder Bluff');
INSERT INTO `graveyards` VALUES ('852', '-5165.52', '-874.664', '507.177', '0', '1', '1537', '0', '0', 'Dun Morogh, Gates of Ironforge');
INSERT INTO `graveyards` VALUES ('853', '1780.11', '221.761', '59.6169', '0', '85', '153', '0', '3', 'Tirisfal Glades, Ruins of Lordaeron');
INSERT INTO `graveyards` VALUES ('854', '-9552.46', '-1374.05', '51.2332', '0', '12', '1519', '0', '3', 'Elwynn Forest, Eastvale Logging Camp');
INSERT INTO `graveyards` VALUES ('869', '1236.89', '-2411.99', '60.68', '0', '28', '2298', '0', '3', 'Western Plaguelands, Caer Darrow');
INSERT INTO `graveyards` VALUES ('889', '684.014', '681.22', '-12.9159', '0', '3358', '0', '529', '1', 'Arathi Basin - Horde Entrance');
INSERT INTO `graveyards` VALUES ('890', '1313.9', '1310.74', '-9.01043', '0', '3358', '0', '529', '0', 'Arathi Basin - Alliance Entrance');
INSERT INTO `graveyards` VALUES ('891', '-831.881', '-3518.52', '72.4831', '0', '3358', '0', '0', '1', 'Arathi Basin - Horde Exit');
INSERT INTO `graveyards` VALUES ('892', '-1215.59', '-2531.75', '21.6734', '0', '3358', '0', '0', '0', 'Arathi Basin - Alliance Exit');
INSERT INTO `graveyards` VALUES ('893', '834.726', '784.979', '-57.0819', '0', '3358', '0', '529', '1', 'Arathi Basin - Graveyard, H-Mid (Farm)');
INSERT INTO `graveyards` VALUES ('894', '1016.59', '955.185', '-42.8287', '0', '3358', '0', '529', '3', 'Arathi Basin - Graveyard, Mid (Blacksmith)');
INSERT INTO `graveyards` VALUES ('895', '1201.87', '1163.13', '-56.286', '0', '3358', '0', '529', '0', 'Arathi Basin - Graveyard, A-Mid (Stables)');
INSERT INTO `graveyards` VALUES ('896', '1211.52', '781.557', '-82.7095', '0', '3358', '0', '529', '3', 'Arathi Basin - Graveyard, ALT-N (Gold Mine)');
INSERT INTO `graveyards` VALUES ('897', '772.756', '1213.11', '15.7974', '0', '3358', '0', '529', '3', 'Arathi Basin - Graveyard, ALT-S (Lumber Mill)');
INSERT INTO `graveyards` VALUES ('898', '1354.7', '1270.27', '-11.1291', '0', '3358', '0', '529', '0', 'Arathi Basin - Graveyard, A-Base (Trollbane Hall)');
INSERT INTO `graveyards` VALUES ('899', '713.71', '638.364', '-10.5999', '0', '3358', '0', '529', '1', 'Arathi Basin - Graveyard, H-Base (Defiler\'s Den)');
INSERT INTO `graveyards` VALUES ('909', '2647.55', '-4014.39', '105.938', '0', '139', '2624', '0', '3', 'Eastern Plaguelands, Blackwood Lake');
INSERT INTO `graveyards` VALUES ('910', '-6831.32', '891.437', '33.8663', '0', '1377', '3425', '1', '3', 'Silithus, Cenarion Hold');
INSERT INTO `graveyards` VALUES ('911', '-10606.8', '294.048', '31.8007', '0', '10', '94', '0', '3', 'Duskwood, Ravenhill');
INSERT INTO `graveyards` VALUES ('912', '10458.5', '-6364.61', '39.7907', '0', '3430', '3431', '530', '1', 'Eversong Woods, Sunstrider Isle');
INSERT INTO `graveyards` VALUES ('913', '-7991.57', '1557.8', '4.97419', '0', '1377', '2737', '1', '3', 'Silithus, Scarab Wall (AQ Only)');
INSERT INTO `graveyards` VALUES ('914', '8936.56', '-7439.9', '82.0856', '0', '3430', '147', '530', '1', 'Eversong Woods, Farstrider Lodge GY');
INSERT INTO `graveyards` VALUES ('915', '7694.18', '-6730.11', '48.2907', '0', '3433', '3488', '530', '1', 'Ghostlands, Tranquillien');
INSERT INTO `graveyards` VALUES ('916', '7015.23', '-7300', '45.4247', '0', '3433', '0', '530', '3', 'Ghostlands, Sanctum');
INSERT INTO `graveyards` VALUES ('917', '6730.49', '-7936.89', '170.099', '0', '3433', '3508', '530', '3', 'Ghostlands, Amani Pass');
INSERT INTO `graveyards` VALUES ('918', '-4123.14', '-13660.1', '74.6', '0', '3524', '3526', '530', '3', 'Azuremyst Isle, Ammen Vale');
INSERT INTO `graveyards` VALUES ('919', '158.06', '2562.73', '75.7812', '0', '3483', '3536', '530', '1', 'Hellfire Peninsula, Thrallmar');
INSERT INTO `graveyards` VALUES ('920', '-803.012', '2702.59', '106.758', '0', '3483', '3538', '530', '0', 'Hellfire Peninsula, Honor Hold');
INSERT INTO `graveyards` VALUES ('921', '9407', '-6847.67', '16', '0', '3487', '3487', '530', '1', 'Eversong Woods, Silvermoon City');
INSERT INTO `graveyards` VALUES ('922', '8709.46', '-6671.76', '70.336', '0', '3430', '3462', '530', '1', 'Eversong Woods, Fairbreeze GY');
INSERT INTO `graveyards` VALUES ('923', '-4312.78', '-12441', '17.1903', '0', '3524', '3557', '530', '3', 'Azuremyst, Azure Watch GY');
INSERT INTO `graveyards` VALUES ('924', '-3324.31', '-12089.9', '28.2748', '0', '3524', '3572', '530', '3', 'Azuremyst, Stillpine GY');
INSERT INTO `graveyards` VALUES ('925', '-2020.59', '-11983.5', '33.248', '0', '3525', '3584', '530', '3', 'Bloodmyst, Blood Watch GY');
INSERT INTO `graveyards` VALUES ('926', '-1754.21', '-11067.3', '76.3423', '0', '3525', '1136', '530', '3', 'Bloodmyst, Wilderness GY');
INSERT INTO `graveyards` VALUES ('927', '1978.47', '-3655.89', '119.795', '0', '139', '0', '0', '3', 'Eastern Plaguelands, Graveyard CG Tower');
INSERT INTO `graveyards` VALUES ('928', '335.886', '7625.12', '22.7486', '0', '3521', '3645', '530', '1', 'Zangarmarsh, Zabra\'jin GY');
INSERT INTO `graveyards` VALUES ('929', '4027.6', '2972.78', '12.0723', '0', '3698', '0', '559', '3', 'Nagrand Arena, Team 1 Start');
INSERT INTO `graveyards` VALUES ('930', '-2495.87', '6802.26', '21.3714', '0', '3518', '0', '530', '3', 'Nagrand, SE Graveyard');
INSERT INTO `graveyards` VALUES ('931', '16423', '16237', '71', '0', '22', '0', '451', '3', 'Programmer Isle');
INSERT INTO `graveyards` VALUES ('932', '16223.8', '16278.6', '20.8913', '0', '22', '0', '451', '3', 'Programmer Isle');
INSERT INTO `graveyards` VALUES ('933', '181.475', '4361.58', '116.885', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Temple');
INSERT INTO `graveyards` VALUES ('934', '-695.875', '4118.21', '64.4865', '0', '3483', '3554', '530', '1', 'Hellfire Peninsula, Falcon Watch');
INSERT INTO `graveyards` VALUES ('935', '742.628', '2887.71', '8.90098', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('936', '4085.45', '2866.83', '12.4005', '0', '3698', '0', '559', '3', 'Nagrand Arena, Team 2 Start');
INSERT INTO `graveyards` VALUES ('937', '4055.85', '2921.78', '50.3394', '0', '3537', '0', '559', '3', 'Reuse');
INSERT INTO `graveyards` VALUES ('938', '101.144', '-184.934', '127.344', '0', '2597', '0', '0', '0', 'Alterac Valley, Alliance Exit');
INSERT INTO `graveyards` VALUES ('939', '6292.66', '288.579', '4.95929', '0', '3702', '0', '562', '3', 'Blade\'s Edge Arena, Team 1');
INSERT INTO `graveyards` VALUES ('940', '6184.98', '236.011', '4.97687', '0', '3702', '0', '562', '3', 'Blade\'s Edge Arena, Team 2');
INSERT INTO `graveyards` VALUES ('941', '540.31', '3932.88', '188.932', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Test Corpse Location');
INSERT INTO `graveyards` VALUES ('942', '540.98', '3144.23', '8.45675', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('943', '582.864', '2954.06', '4.56392', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('944', '742.628', '2887.71', '8.90098', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('945', '1148.44', '1798.14', '116.296', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('946', '851.694', '1688.06', '89.7566', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('947', '608.097', '1778.63', '104.436', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('948', '354.618', '1952.75', '23.7654', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('949', '107.712', '1841.23', '21.8838', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('950', '274.599', '1674.63', '-5.7761', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('951', '60.881', '1542.69', '17.0833', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('952', '-92.8317', '1350.91', '-12.2025', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 012');
INSERT INTO `graveyards` VALUES ('953', '134.528', '1230.39', '2.39736', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 013');
INSERT INTO `graveyards` VALUES ('954', '298.666', '1225.23', '-1.17948', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 014');
INSERT INTO `graveyards` VALUES ('955', '386.682', '1044.78', '26.8734', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 015');
INSERT INTO `graveyards` VALUES ('956', '337.84', '853.218', '13.8851', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 016');
INSERT INTO `graveyards` VALUES ('957', '60.3844', '725.155', '14.5849', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 017');
INSERT INTO `graveyards` VALUES ('958', '-213.512', '730.684', '-0.830688', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 018');
INSERT INTO `graveyards` VALUES ('959', '-570.327', '675.785', '-0.703824', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 019');
INSERT INTO `graveyards` VALUES ('960', '-958.584', '803.907', '2.53478', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 020');
INSERT INTO `graveyards` VALUES ('961', '-827.569', '1194.34', '16.2846', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 021');
INSERT INTO `graveyards` VALUES ('962', '-465.075', '1272.1', '12.3895', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 022');
INSERT INTO `graveyards` VALUES ('963', '-668.975', '1516.19', '17.9959', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 023');
INSERT INTO `graveyards` VALUES ('964', '-1278.37', '1381.71', '9.10488', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 024');
INSERT INTO `graveyards` VALUES ('965', '-1306.28', '2478.4', '56.8094', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 025');
INSERT INTO `graveyards` VALUES ('966', '-1497.4', '2657.17', '-53.1746', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 026');
INSERT INTO `graveyards` VALUES ('967', '-1445.7', '3050.23', '-16.8279', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 027');
INSERT INTO `graveyards` VALUES ('968', '-1510.36', '3281.81', '-16.8644', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Corpse Location 028');
INSERT INTO `graveyards` VALUES ('969', '248.339', '7084.93', '36.4931', '0', '3521', '0', '530', '3', 'Zangarmarsh, PvP GY');
INSERT INTO `graveyards` VALUES ('970', '211.315', '6200.03', '22.2988', '0', '3521', '3644', '530', '0', 'Zangarmarsh, Telredor GY');
INSERT INTO `graveyards` VALUES ('971', '6238.93', '262.963', '0.889519', '0', '3702', '0', '562', '3', 'Blades Edge - PvP - Arena Graveyard');
INSERT INTO `graveyards` VALUES ('972', '1286.73', '7883.12', '10.2222', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('973', '-212.452', '5579.67', '22.178', '0', '3521', '3565', '530', '3', 'Zangarmarsh, Cenarion GY');
INSERT INTO `graveyards` VALUES ('974', '1011.16', '5039.57', '-26.825', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('975', '781.713', '4987.82', '-12.3656', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('976', '1001.9', '5714.57', '-9.30326', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('977', '1394.98', '7756.5', '12.2897', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('978', '1412.41', '8430.12', '-4.67992', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('979', '1398.58', '7763.03', '8.54554', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('980', '1317.5', '8135.39', '-2.85692', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('981', '1706.28', '8407.81', '-24.7731', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('982', '1348.12', '8677.57', '6.86939', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('983', '1838.93', '8496.51', '-19.0251', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('984', '1347.02', '8679.23', '6.67159', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 012');
INSERT INTO `graveyards` VALUES ('985', '1104.4', '8781.98', '-10.8889', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 013');
INSERT INTO `graveyards` VALUES ('986', '747.447', '8702.9', '6.10944', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 014');
INSERT INTO `graveyards` VALUES ('987', '381.31', '9113.74', '-4.27206', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 016');
INSERT INTO `graveyards` VALUES ('988', '702.758', '8927.53', '-2.82061', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 015');
INSERT INTO `graveyards` VALUES ('989', '223.55', '9132.74', '-11.746', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 017');
INSERT INTO `graveyards` VALUES ('990', '32.157', '9120.4', '-17.2552', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 018');
INSERT INTO `graveyards` VALUES ('991', '-160.425', '9053.54', '5.14203', '0', '3521', '0', '530', '3', 'Zangarmarsh, Corpse Location 019');
INSERT INTO `graveyards` VALUES ('992', '-1066.97', '8066.54', '-39.2593', '0', '3518', '3627', '530', '3', 'Nagrand, Northwind Cleft');
INSERT INTO `graveyards` VALUES ('993', '-1654.37', '7938.99', '-46.235', '0', '3518', '3628', '530', '3', 'Nagrand, Halaa GY');
INSERT INTO `graveyards` VALUES ('994', '-1793.42', '4931.61', '-22.2095', '0', '3519', '3703', '530', '3', 'Terokkar Forest, Shattrath GY');
INSERT INTO `graveyards` VALUES ('995', '-2540.15', '3866.65', '10.0769', '0', '3519', '0', '530', '3', 'Terokkar Forest, Wilderness GY');
INSERT INTO `graveyards` VALUES ('996', '1463.22', '16470.1', '66.4858', '0', '22', '0', '451', '3', 'Test - Programmer');
INSERT INTO `graveyards` VALUES ('997', '66.2969', '60.125', '6.44392', '0', '22', '0', '451', '3', 'Test - Programmer 001');
INSERT INTO `graveyards` VALUES ('998', '4055.5', '2919.66', '13.6112', '0', '3518', '0', '559', '3', 'Nagrand - PvP - Arena Graveyard');
INSERT INTO `graveyards` VALUES ('999', '-697.573', '8881.73', '185.45', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('1000', '-999.506', '9045.62', '91.5906', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('1001', '-1933.72', '9343.67', '74.7306', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('1002', '-2153.3', '9323.71', '52.4346', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('1003', '-2619.46', '8953.7', '-11.5455', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('1004', '-2799.85', '8785.75', '-42.4943', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('1005', '-2984.12', '8700.11', '-53.1578', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('1006', '-2989.35', '8445.13', '-36.2434', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('1007', '-3122.56', '8079.49', '-49.1307', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('1008', '-3155.75', '7316.31', '-25.8604', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('1009', '-3244.7', '7079.02', '-49.572', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('1010', '-2987.35', '7045.47', '-54.3837', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 012');
INSERT INTO `graveyards` VALUES ('1011', '-2962.33', '6796.88', '-51.2624', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 013');
INSERT INTO `graveyards` VALUES ('1012', '-3045.37', '6508.57', '99.6549', '0', '3518', '0', '530', '3', 'Nagrand, Corpse Location 014');
INSERT INTO `graveyards` VALUES ('1013', '-3379.58', '6206.48', '-3.66373', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('1014', '-3621.98', '6225.18', '-18.8211', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('1015', '-3898.57', '6147.65', '-37.0799', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('1016', '-3844.34', '5931.41', '-25.0505', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('1017', '-3801.34', '5618.75', '-26.9166', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('1018', '-3910.99', '5404.07', '-35.67', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('1019', '-3886.29', '5149.57', '-59.6891', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('1020', '-3990.14', '4869.48', '-107.634', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('1021', '-3904.3', '4591.4', '-45.9821', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('1022', '-4024.3', '4421.72', '-50.0018', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('1023', '-3965.06', '4128.62', '0.276609', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('1024', '-2415.76', '1811.62', '-1.16446', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('1025', '-2319.13', '1749.94', '-13.3446', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('1026', '-2447.42', '1612.81', '-27.2319', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('1027', '-2650.24', '1666.66', '10.0941', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('1028', '-4151.09', '3425.82', '293.05', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 016');
INSERT INTO `graveyards` VALUES ('1029', '-2648.27', '3020.65', '-13.2128', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 017');
INSERT INTO `graveyards` VALUES ('1030', '-2375.42', '2848.08', '-69.8786', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 018');
INSERT INTO `graveyards` VALUES ('1031', '-2205.61', '2968.3', '-69.0715', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 019');
INSERT INTO `graveyards` VALUES ('1032', '-2098.93', '3116.51', '-51.3105', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 020');
INSERT INTO `graveyards` VALUES ('1033', '-2047.74', '3278.56', '-61.8309', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 021');
INSERT INTO `graveyards` VALUES ('1034', '-2059', '3560.39', '-74.5024', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 022');
INSERT INTO `graveyards` VALUES ('1035', '-1876.5', '3700.5', '-19.7418', '0', '3519', '0', '530', '3', 'Terokkar Forest, Corpse Location 023');
INSERT INTO `graveyards` VALUES ('1036', '0', '0', '0', '0', '3537', '0', '530', '3', 'Reuse');
INSERT INTO `graveyards` VALUES ('1037', '-1289.79', '9166.72', '218.081', '0', '3518', '0', '530', '3', 'Nagrand, Portal Plateau');
INSERT INTO `graveyards` VALUES ('1038', '-856.214', '6600.06', '173.753', '0', '3518', '3636', '530', '3', 'Nagrand, Elemental Plateau');
INSERT INTO `graveyards` VALUES ('1039', '-2033.53', '8479.53', '-0.312287', '0', '3518', '0', '530', '3', 'Nagrand, SW Graveyard');
INSERT INTO `graveyards` VALUES ('1040', '700.091', '2207.99', '288.518', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Throne of Kil\'Jaedan');
INSERT INTO `graveyards` VALUES ('1041', '-249.765', '1023.32', '54.3254', '0', '3483', '0', '530', '3', 'Hellfire Peninsula, Dark Portal');
INSERT INTO `graveyards` VALUES ('1042', '-3562.41', '4666.44', '-21.9864', '0', '3519', '3697', '530', '3', 'Terokkar Forest, Bone Wastes GY');
INSERT INTO `graveyards` VALUES ('1043', '874.911', '7284.72', '23.0167', '0', '3521', '3766', '530', '1', 'Zangarmarsh, Harborage GY');
INSERT INTO `graveyards` VALUES ('1044', '337.125', '8616.87', '24.1563', '0', '3521', '3649', '530', '3', 'Zangarmarsh, Sporeggar GY');
INSERT INTO `graveyards` VALUES ('1045', '4363.88', '3093.74', '132.97', '0', '3523', '3738', '530', '3', 'Netherstorm, Stormspire GY');
INSERT INTO `graveyards` VALUES ('1046', '3032.44', '3594.28', '145.818', '0', '3523', '3712', '530', '3', 'Netherstorm, Area 52 GY');
INSERT INTO `graveyards` VALUES ('1047', '-2999.23', '2439.06', '62.3126', '0', '3520', '3744', '530', '1', 'Shadowmoon Valley, Shadowmoon Village GY');
INSERT INTO `graveyards` VALUES ('1048', '-4022.99', '2048.58', '96.8944', '0', '3520', '3745', '530', '0', 'Shadowmoon Valley, Wildhammer GY');
INSERT INTO `graveyards` VALUES ('1049', '1955.9', '6768.81', '164.061', '0', '3522', '3772', '530', '0', 'Blade\'s Edge, Sylvanaar GY');
INSERT INTO `graveyards` VALUES ('1050', '2218.9', '6017.35', '135.921', '0', '3522', '3769', '530', '1', 'Blade\'s Edge, Thunderlord GY');
INSERT INTO `graveyards` VALUES ('1051', '-3942.59', '3686.29', '286.76', '0', '3519', '3679', '530', '3', 'Terokkar Forest, Skettis GY');
INSERT INTO `graveyards` VALUES ('1052', '-2652.66', '1484.21', '23.2433', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('1053', '-2477.69', '1386.24', '47.2643', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('1054', '-2459.08', '1277.57', '33.3696', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('1055', '-2464.28', '1074.65', '33.7003', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('1056', '-2597.45', '1040.72', '40.0066', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('1057', '-2753.67', '966.146', '-3.37364', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('1058', '-2721.16', '711.034', '-21.3014', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('1059', '-2752.54', '509.309', '-25.6439', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 012');
INSERT INTO `graveyards` VALUES ('1060', '-3004.49', '482.051', '-15.3962', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 013');
INSERT INTO `graveyards` VALUES ('1061', '-2997.38', '207.579', '3.1666', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 014');
INSERT INTO `graveyards` VALUES ('1062', '-4084.62', '120.513', '63.0947', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 015');
INSERT INTO `graveyards` VALUES ('1063', '-4231.62', '58.6267', '7.60376', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 016');
INSERT INTO `graveyards` VALUES ('1064', '-4445.81', '224.844', '93.5421', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 017');
INSERT INTO `graveyards` VALUES ('1065', '-4507.6', '553.553', '124.258', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 018');
INSERT INTO `graveyards` VALUES ('1066', '-4445.43', '863.558', '6.45198', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 019');
INSERT INTO `graveyards` VALUES ('1067', '-4791.52', '1082.18', '-8.86698', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 020');
INSERT INTO `graveyards` VALUES ('1068', '-4618.17', '1850.61', '153.439', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 021');
INSERT INTO `graveyards` VALUES ('1069', '-4568.14', '2023.8', '90.0628', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 022');
INSERT INTO `graveyards` VALUES ('1070', '-4541.32', '2281.76', '17.7953', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 023');
INSERT INTO `graveyards` VALUES ('1071', '-4408.89', '2328.78', '31.213', '0', '3520', '0', '530', '3', 'Shadowmoon, Corpse Location 024');
INSERT INTO `graveyards` VALUES ('1072', '1933', '7389.18', '364.888', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 000');
INSERT INTO `graveyards` VALUES ('1073', '2356.31', '7345.09', '363.309', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 001');
INSERT INTO `graveyards` VALUES ('1074', '2818.31', '7269.72', '364.234', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 002');
INSERT INTO `graveyards` VALUES ('1075', '3199.99', '7264.96', '146.66', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 003');
INSERT INTO `graveyards` VALUES ('1076', '3432.89', '7312.38', '138.648', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 004');
INSERT INTO `graveyards` VALUES ('1077', '3753.24', '7118.03', '141.142', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 005');
INSERT INTO `graveyards` VALUES ('1078', '3797.19', '6900.24', '142.429', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 006');
INSERT INTO `graveyards` VALUES ('1079', '3839.15', '6586.81', '135.094', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 007');
INSERT INTO `graveyards` VALUES ('1080', '3482.78', '6487.13', '134.426', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 008');
INSERT INTO `graveyards` VALUES ('1081', '3656.61', '6208.11', '272.701', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 009');
INSERT INTO `graveyards` VALUES ('1082', '3995.33', '6092.06', '262.343', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 010');
INSERT INTO `graveyards` VALUES ('1083', '4095.11', '5811.89', '259.762', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 011');
INSERT INTO `graveyards` VALUES ('1084', '4153.55', '5508.92', '272.112', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 012');
INSERT INTO `graveyards` VALUES ('1085', '4120.71', '5214.15', '264.988', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 013');
INSERT INTO `graveyards` VALUES ('1086', '4086.35', '4849.9', '267.429', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 014');
INSERT INTO `graveyards` VALUES ('1087', '3926.2', '4825.28', '264.982', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 015');
INSERT INTO `graveyards` VALUES ('1088', '3731.12', '4738.45', '240.943', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 016');
INSERT INTO `graveyards` VALUES ('1089', '3455.31', '4468.35', '154.243', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 017');
INSERT INTO `graveyards` VALUES ('1090', '3323.6', '4503.88', '152.405', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 018');
INSERT INTO `graveyards` VALUES ('1091', '2877.52', '4738.91', '278.725', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 019');
INSERT INTO `graveyards` VALUES ('1092', '2653', '5100.26', '275.459', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 020');
INSERT INTO `graveyards` VALUES ('1093', '2344.62', '5072.5', '268.165', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 021');
INSERT INTO `graveyards` VALUES ('1094', '2251.08', '4907.94', '140.958', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 022');
INSERT INTO `graveyards` VALUES ('1095', '2274.35', '4725.43', '159.451', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 023');
INSERT INTO `graveyards` VALUES ('1096', '2102.66', '4685.08', '139.953', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 024');
INSERT INTO `graveyards` VALUES ('1097', '1914.58', '4677.85', '133.28', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 025');
INSERT INTO `graveyards` VALUES ('1098', '1771.94', '4585.16', '144.923', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 026');
INSERT INTO `graveyards` VALUES ('1099', '1621.04', '4563.14', '137.265', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 027');
INSERT INTO `graveyards` VALUES ('1100', '1606.36', '4792.58', '138.085', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 028');
INSERT INTO `graveyards` VALUES ('1101', '1596.31', '4948.65', '169.669', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 029');
INSERT INTO `graveyards` VALUES ('1102', '1616.9', '5077.05', '174.761', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 030');
INSERT INTO `graveyards` VALUES ('1103', '2523.69', '1596.6', '1269.35', '0', '3523', '0', '566', '0', 'Netherstorm BG - Graveyard (Alliance Start)');
INSERT INTO `graveyards` VALUES ('1104', '1807.74', '1539.42', '1267.63', '0', '3523', '0', '566', '1', 'Netherstorm BG - Graveyard (Horde Start)');
INSERT INTO `graveyards` VALUES ('1105', '2013.06', '1677.24', '1182.13', '0', '3523', '0', '566', '3', 'Netherstorm BG - Graveyard (Felreaver)');
INSERT INTO `graveyards` VALUES ('1106', '2012.4', '1455.41', '1172.2', '0', '3523', '0', '566', '3', 'Netherstorm BG - Graveyard (BE Tower)');
INSERT INTO `graveyards` VALUES ('1107', '2351.79', '1455.4', '1185.33', '0', '3523', '0', '566', '3', 'Netherstorm BG - Graveyard (Draenei Tower)');
INSERT INTO `graveyards` VALUES ('1108', '2355.3', '1683.71', '1173.15', '0', '3523', '0', '566', '3', 'Netherstorm BG - Graveyard (Human Tower)');
INSERT INTO `graveyards` VALUES ('1109', '2626.9', '1457.85', '1225.54', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 000');
INSERT INTO `graveyards` VALUES ('1110', '2603.99', '1695.96', '1229.46', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 001');
INSERT INTO `graveyards` VALUES ('1111', '2495.96', '1402.39', '1204.59', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 002');
INSERT INTO `graveyards` VALUES ('1112', '2541.25', '1787.24', '1187.98', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 003');
INSERT INTO `graveyards` VALUES ('1113', '2353.73', '1336.66', '1192.14', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 004');
INSERT INTO `graveyards` VALUES ('1114', '2368.35', '1800.79', '1166.33', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 005');
INSERT INTO `graveyards` VALUES ('1115', '2253.47', '1298.66', '1188.84', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 006');
INSERT INTO `graveyards` VALUES ('1116', '2227.6', '1819.58', '1151.61', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 007');
INSERT INTO `graveyards` VALUES ('1117', '2047.89', '1324.84', '1170.77', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 008');
INSERT INTO `graveyards` VALUES ('1118', '2057.31', '1848.26', '1192.27', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 009');
INSERT INTO `graveyards` VALUES ('1119', '1914.77', '1381.5', '1175.39', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 010');
INSERT INTO `graveyards` VALUES ('1120', '1918.94', '1766.3', '1194.12', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 011');
INSERT INTO `graveyards` VALUES ('1121', '1796.22', '1341.52', '1188.57', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 012');
INSERT INTO `graveyards` VALUES ('1122', '1808.19', '1726.82', '1206.02', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 013');
INSERT INTO `graveyards` VALUES ('1123', '1724.51', '1405.74', '1208.55', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 014');
INSERT INTO `graveyards` VALUES ('1124', '1692.78', '1672.57', '1225.53', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 015');
INSERT INTO `graveyards` VALUES ('1125', '2121.79', '1670.5', '1169.27', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 016');
INSERT INTO `graveyards` VALUES ('1126', '2111.42', '1441.82', '1163.87', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 017');
INSERT INTO `graveyards` VALUES ('1127', '2213.18', '1469.54', '1175.01', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 018');
INSERT INTO `graveyards` VALUES ('1128', '2226.6', '1692.81', '1161.85', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 019');
INSERT INTO `graveyards` VALUES ('1129', '2174.9', '1594.51', '1126.51', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 020');
INSERT INTO `graveyards` VALUES ('1130', '2173.64', '1534.45', '1129.24', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 021');
INSERT INTO `graveyards` VALUES ('1131', '2213.83', '1328.19', '1178.46', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 022');
INSERT INTO `graveyards` VALUES ('1132', '2113.42', '1326.88', '1153.99', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 023');
INSERT INTO `graveyards` VALUES ('1133', '2117.21', '1807.68', '1171.55', '0', '3523', '0', '566', '3', 'Netherstorm BG - Corpse Catcher 024');
INSERT INTO `graveyards` VALUES ('1134', '3491.41', '4127.39', '119.837', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 000');
INSERT INTO `graveyards` VALUES ('1135', '3578.56', '3957.1', '117.999', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 001');
INSERT INTO `graveyards` VALUES ('1136', '3586.96', '3717.31', '115.593', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 002');
INSERT INTO `graveyards` VALUES ('1137', '3640.77', '3522.84', '104.122', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 003');
INSERT INTO `graveyards` VALUES ('1138', '3520.2', '3511.7', '125.437', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 004');
INSERT INTO `graveyards` VALUES ('1139', '3399.31', '3400.41', '101.826', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 005');
INSERT INTO `graveyards` VALUES ('1140', '3271.49', '3366.92', '105.214', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 006');
INSERT INTO `graveyards` VALUES ('1141', '3188.37', '3257.08', '88.973', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 007');
INSERT INTO `graveyards` VALUES ('1142', '3022.79', '3163.7', '118.336', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 008');
INSERT INTO `graveyards` VALUES ('1143', '2943.66', '3056.64', '112.724', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 009');
INSERT INTO `graveyards` VALUES ('1144', '2846.52', '2955.54', '113.508', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 010');
INSERT INTO `graveyards` VALUES ('1145', '2815.3', '2830.89', '76.0171', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 011');
INSERT INTO `graveyards` VALUES ('1146', '2695.05', '2940.24', '94.9833', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 012');
INSERT INTO `graveyards` VALUES ('1147', '2570.5', '3135.96', '107.749', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 013');
INSERT INTO `graveyards` VALUES ('1148', '2511.98', '3275.15', '99.749', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 014');
INSERT INTO `graveyards` VALUES ('1149', '2449.93', '3377.49', '115.303', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 015');
INSERT INTO `graveyards` VALUES ('1150', '2519.66', '3538.7', '120.574', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 016');
INSERT INTO `graveyards` VALUES ('1151', '2479.84', '3695.68', '106.209', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 017');
INSERT INTO `graveyards` VALUES ('1152', '2433.44', '3835.28', '94.9401', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 018');
INSERT INTO `graveyards` VALUES ('1153', '2403.43', '3995.29', '99.2667', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 019');
INSERT INTO `graveyards` VALUES ('1154', '2477.41', '4151.27', '113.695', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 020');
INSERT INTO `graveyards` VALUES ('1155', '2535.26', '4396.42', '103.322', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 021');
INSERT INTO `graveyards` VALUES ('1156', '2710.52', '4440.32', '105.852', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 022');
INSERT INTO `graveyards` VALUES ('1157', '2916.15', '4444.49', '111.442', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 023');
INSERT INTO `graveyards` VALUES ('1158', '3069.1', '4357.14', '119.069', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 024');
INSERT INTO `graveyards` VALUES ('1159', '3091.8', '4146.84', '126.162', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 025');
INSERT INTO `graveyards` VALUES ('1160', '3221.17', '4069.1', '103.294', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 026');
INSERT INTO `graveyards` VALUES ('1161', '3355.79', '4149.28', '137.783', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 027');
INSERT INTO `graveyards` VALUES ('1162', '3980.61', '4262.21', '130.059', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 028');
INSERT INTO `graveyards` VALUES ('1163', '3802.7', '4204.43', '108.911', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 029');
INSERT INTO `graveyards` VALUES ('1164', '3766.71', '4008.23', '116.788', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 030');
INSERT INTO `graveyards` VALUES ('1165', '3796.27', '3772.19', '100.545', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 031');
INSERT INTO `graveyards` VALUES ('1166', '4049.61', '3692.78', '101.573', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 032');
INSERT INTO `graveyards` VALUES ('1167', '4152.53', '3886.21', '121.304', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 033');
INSERT INTO `graveyards` VALUES ('1168', '4235.16', '4080.62', '95.3675', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 034');
INSERT INTO `graveyards` VALUES ('1169', '4169.83', '4209.06', '118.711', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 035');
INSERT INTO `graveyards` VALUES ('1170', '3836.08', '3477.26', '75.5263', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 036');
INSERT INTO `graveyards` VALUES ('1171', '3994.95', '3538.27', '122.008', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 037');
INSERT INTO `graveyards` VALUES ('1172', '4211.4', '3632', '124.109', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 038');
INSERT INTO `graveyards` VALUES ('1173', '4395.24', '3708.62', '96.616', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 039');
INSERT INTO `graveyards` VALUES ('1174', '4580.69', '3584', '94.0002', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 040');
INSERT INTO `graveyards` VALUES ('1175', '4793.19', '3527.37', '102.164', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 041');
INSERT INTO `graveyards` VALUES ('1176', '4903.71', '3323.86', '101.089', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 042');
INSERT INTO `graveyards` VALUES ('1177', '4945.87', '3110.83', '98.2189', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 043');
INSERT INTO `graveyards` VALUES ('1178', '5156.75', '2974.21', '75.555', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 044');
INSERT INTO `graveyards` VALUES ('1179', '5204.7', '2868.11', '54.3042', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 045');
INSERT INTO `graveyards` VALUES ('1180', '5019.97', '2798.73', '52.0894', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 046');
INSERT INTO `graveyards` VALUES ('1181', '4885.18', '2663.13', '85.2405', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 047');
INSERT INTO `graveyards` VALUES ('1182', '4853.17', '2354.02', '101.279', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 048');
INSERT INTO `graveyards` VALUES ('1183', '4680.81', '2287.48', '129.446', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 049');
INSERT INTO `graveyards` VALUES ('1184', '4522.44', '2280.28', '136.924', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 050');
INSERT INTO `graveyards` VALUES ('1185', '4436.57', '2485.48', '90.3712', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 051');
INSERT INTO `graveyards` VALUES ('1186', '4448.3', '2658.15', '111.356', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 052');
INSERT INTO `graveyards` VALUES ('1187', '4285.06', '2837.04', '100.8', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 053');
INSERT INTO `graveyards` VALUES ('1188', '4136.62', '2699.33', '101.025', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 054');
INSERT INTO `graveyards` VALUES ('1189', '3975.24', '2807.44', '115.88', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 055');
INSERT INTO `graveyards` VALUES ('1190', '3931.79', '3020.67', '104.802', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 056');
INSERT INTO `graveyards` VALUES ('1191', '3895.88', '3257.64', '120.552', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 057');
INSERT INTO `graveyards` VALUES ('1192', '3629.36', '3095.11', '112.238', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 058');
INSERT INTO `graveyards` VALUES ('1193', '3476.45', '3293.56', '94.8662', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 059');
INSERT INTO `graveyards` VALUES ('1194', '3348.41', '3172.06', '91.6889', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 060');
INSERT INTO `graveyards` VALUES ('1195', '3216.28', '2992.53', '124.764', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 061');
INSERT INTO `graveyards` VALUES ('1196', '3022.81', '2892.91', '90.2431', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 062');
INSERT INTO `graveyards` VALUES ('1197', '2860.47', '2735.28', '86.18', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 063');
INSERT INTO `graveyards` VALUES ('1198', '2863.8', '2537.41', '105.193', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 064');
INSERT INTO `graveyards` VALUES ('1199', '2856.08', '2297.04', '98.8159', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 065');
INSERT INTO `graveyards` VALUES ('1200', '2834.86', '2040.24', '92.6892', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 066');
INSERT INTO `graveyards` VALUES ('1201', '2868.81', '1848.69', '96.8612', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 067');
INSERT INTO `graveyards` VALUES ('1202', '2895.75', '1708.09', '105.79', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 068');
INSERT INTO `graveyards` VALUES ('1203', '3110.67', '1624.43', '112.817', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 069');
INSERT INTO `graveyards` VALUES ('1204', '3276.02', '1726.59', '101.628', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 070');
INSERT INTO `graveyards` VALUES ('1205', '3332.26', '1986.97', '94.5339', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 071');
INSERT INTO `graveyards` VALUES ('1206', '3315.85', '2185.52', '108.392', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 072');
INSERT INTO `graveyards` VALUES ('1207', '3384.58', '2376.22', '73.5116', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 073');
INSERT INTO `graveyards` VALUES ('1208', '3492.84', '2570.84', '138.484', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 074');
INSERT INTO `graveyards` VALUES ('1209', '3590.41', '2677.08', '134.967', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 075');
INSERT INTO `graveyards` VALUES ('1210', '3740.94', '2696.99', '112.495', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 076');
INSERT INTO `graveyards` VALUES ('1211', '3737.85', '2894.69', '100.461', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 077');
INSERT INTO `graveyards` VALUES ('1212', '3862.95', '2554.46', '80.6212', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 078');
INSERT INTO `graveyards` VALUES ('1213', '3648.26', '2414.61', '75.8989', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 079');
INSERT INTO `graveyards` VALUES ('1214', '3546.97', '2219.76', '92.1654', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 080');
INSERT INTO `graveyards` VALUES ('1215', '3550.01', '2002.35', '92.2836', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 081');
INSERT INTO `graveyards` VALUES ('1216', '3509.69', '1762.49', '75.3824', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 082');
INSERT INTO `graveyards` VALUES ('1217', '3645.26', '1712.66', '106.519', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 083');
INSERT INTO `graveyards` VALUES ('1218', '3681.18', '1558.56', '103.064', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 084');
INSERT INTO `graveyards` VALUES ('1219', '3775.55', '1437.54', '-152.872', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 085');
INSERT INTO `graveyards` VALUES ('1220', '3969.01', '1336.41', '-143.469', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 086');
INSERT INTO `graveyards` VALUES ('1221', '4166.45', '1329.15', '-149.744', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 087');
INSERT INTO `graveyards` VALUES ('1222', '4199.54', '1484.24', '-127.523', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 088');
INSERT INTO `graveyards` VALUES ('1223', '4258.28', '1672.84', '113.502', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 089');
INSERT INTO `graveyards` VALUES ('1224', '4362.23', '1927.16', '95.6414', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 090');
INSERT INTO `graveyards` VALUES ('1225', '4347.15', '2143.36', '116.927', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 091');
INSERT INTO `graveyards` VALUES ('1226', '4246.96', '2450.75', '91.2951', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 092');
INSERT INTO `graveyards` VALUES ('1227', '4117.15', '2332.29', '103.107', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 093');
INSERT INTO `graveyards` VALUES ('1228', '3975.8', '2437.47', '114.278', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 094');
INSERT INTO `graveyards` VALUES ('1229', '2501.34', '1983.39', '84.3397', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 095');
INSERT INTO `graveyards` VALUES ('1230', '2573.35', '2127.1', '98.8223', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 096');
INSERT INTO `graveyards` VALUES ('1231', '2648.16', '2353.63', '93.2833', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 097');
INSERT INTO `graveyards` VALUES ('1232', '2659.25', '2547.14', '110.084', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 098');
INSERT INTO `graveyards` VALUES ('1233', '2587.89', '2711.6', '110.037', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 099');
INSERT INTO `graveyards` VALUES ('1234', '2473.63', '2964.98', '106.742', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 100');
INSERT INTO `graveyards` VALUES ('1235', '2209.18', '2901.68', '93.6635', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 101');
INSERT INTO `graveyards` VALUES ('1236', '2164.32', '2667.39', '78.4479', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 102');
INSERT INTO `graveyards` VALUES ('1237', '2078.21', '2405.5', '65.8779', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 103');
INSERT INTO `graveyards` VALUES ('1238', '2079.82', '2227.04', '67.6551', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 104');
INSERT INTO `graveyards` VALUES ('1239', '2240.18', '2067.8', '61.7495', '0', '3523', '0', '530', '3', 'Netherstorm - Corpse Catcher 105');
INSERT INTO `graveyards` VALUES ('1240', '552.188', '1995.15', '103.702', '0', '3483', '0', '530', '0', 'Hellfire Peninsula, Force Camps (Alliance)');
INSERT INTO `graveyards` VALUES ('1241', '3065', '5426.42', '148.39', '0', '3522', '3951', '530', '3', 'Blade\'s Edge, Evergrove GY');
INSERT INTO `graveyards` VALUES ('1242', '3872.66', '5514.41', '271.977', '0', '3522', '0', '530', '3', 'Blade\'s Edge, North Ridge GY');
INSERT INTO `graveyards` VALUES ('1243', '2296.35', '7023.23', '364.117', '0', '3522', '0', '530', '3', 'Blade\'s Edge, West Ridge GY');
INSERT INTO `graveyards` VALUES ('1244', '2312.27', '5083.93', '272.449', '0', '3522', '0', '530', '3', 'Blade\'s Edge, East Ridge GY');
INSERT INTO `graveyards` VALUES ('1245', '0', '0', '0', '0', '3523', '0', '566', '0', 'zzOLDNetherstorm BG - Graveyard (Alliance Default)');
INSERT INTO `graveyards` VALUES ('1246', '101.144', '-184.934', '127.344', '0', '2597', '0', '0', '0', 'Alterac Valley, Alliance Exit');
INSERT INTO `graveyards` VALUES ('1247', '2980.19', '1869.82', '143.607', '0', '3523', '3724', '530', '3', 'Netherstorm, Cosmowrench GY');
INSERT INTO `graveyards` VALUES ('1248', '-1272.42', '2436.85', '64.0972', '0', '3483', '3812', '530', '1', 'Hellfire Peninsula, Spinebreaker GY');
INSERT INTO `graveyards` VALUES ('1249', '-8159.51', '-4628.7', '-124.747', '0', '440', '2300', '1', '3', 'Tanaris, CoT');
INSERT INTO `graveyards` VALUES ('1250', '-3134.54', '719.484', '-20.6363', '0', '3520', '0', '530', '3', 'Shadowmoon Valley, Altar GY');
INSERT INTO `graveyards` VALUES ('1251', '-4117.03', '1058.26', '31.5656', '0', '3520', '3938', '530', '3', 'Shadowmoon Valley, Sanctum GY');
INSERT INTO `graveyards` VALUES ('1252', '2362.67', '2327.41', '106.18', '0', '3523', '3732', '530', '3', 'Netherstorm, Kirin\'Var GY');
INSERT INTO `graveyards` VALUES ('1253', '2011.39', '5575.79', '262.717', '0', '3522', '3918', '530', '0', 'Blade\'s Edge, Toshley GY');
INSERT INTO `graveyards` VALUES ('1254', '3522.84', '6821.62', '140.879', '0', '3522', '3830', '530', '3', 'Blade\'s Edge, Raven Wood GY');
INSERT INTO `graveyards` VALUES ('1255', '3447.31', '4803.82', '260.213', '0', '3522', '0', '530', '3', 'Blade\'s Edge, NE Ridge GY');
INSERT INTO `graveyards` VALUES ('1256', '-382.911', '1117.42', '84.3704', '0', '130', '0', '0', '3', 'Silverpine Forest, South GY');
INSERT INTO `graveyards` VALUES ('1257', '-1148.08', '5897.62', '188.337', '0', '3519', '0', '530', '3', 'Terokkar Forest, Ogre GY');
INSERT INTO `graveyards` VALUES ('1258', '1277.87', '1744.9', '32.5', '0', '3968', '0', '572', '3', 'Lordaeron, PVP - Team 1 Start');
INSERT INTO `graveyards` VALUES ('1259', '1295.13', '1586.44', '32.5', '0', '3968', '0', '572', '3', 'Lordaeron, PVP - Team 2 Start');
INSERT INTO `graveyards` VALUES ('1260', '1285.81', '1667.9', '39.9576', '0', '3968', '0', '572', '3', 'Lordaeron, PVP - Graveyard');
INSERT INTO `graveyards` VALUES ('1261', '-3524.27', '619.528', '4.66533', '0', '3959', '0', '530', '0', 'Black Temple, Alliance GY');
INSERT INTO `graveyards` VALUES ('1262', '-3624.93', '600.007', '11.669', '0', '3959', '0', '530', '1', 'Black Temple, Horde GY');
INSERT INTO `graveyards` VALUES ('1263', '3621.87', '6519.53', '124.339', '0', '3522', '0', '530', '3', 'Blade\'s Edge, Corpse Location 031');
INSERT INTO `graveyards` VALUES ('1264', '-4032.4', '-3414.03', '38.5236', '0', '15', '4049', '1', '3', 'Dustwallow Marsh, Tabetha\'s');
INSERT INTO `graveyards` VALUES ('1265', '-4632.79', '-3129.43', '34.9423', '0', '15', '4010', '1', '3', 'Dustwallow Marsh, Mudsprocket');
INSERT INTO `graveyards` VALUES ('1266', '1958.13', '-3682.22', '171.91', '0', '495', '0', '571', '3', 'Howling Fjord, Northwest GY');
INSERT INTO `graveyards` VALUES ('1267', '728.266', '-2992.27', '24.9835', '0', '495', '0', '571', '3', 'Howling Fjord, Tuskarr GY');
INSERT INTO `graveyards` VALUES ('1268', '117.023', '-3698.8', '0.683407', '0', '495', '0', '571', '3', 'Howling Fjord, Island GY');
INSERT INTO `graveyards` VALUES ('1269', '1191.77', '-4115.08', '149.689', '0', '495', '0', '571', '3', 'Howling Fjord, Central GY');
INSERT INTO `graveyards` VALUES ('1270', '2243.12', '-4650.64', '218.961', '0', '495', '0', '571', '3', 'Howling Fjord, North GY');
INSERT INTO `graveyards` VALUES ('1271', '1923.72', '-5986.35', '9.05279', '0', '495', '0', '571', '3', 'Howling Fjord, Vengance GY');
INSERT INTO `graveyards` VALUES ('1272', '717.778', '-5878.41', '287.001', '0', '495', '0', '571', '3', 'Howling Fjord, Southeast GY');
INSERT INTO `graveyards` VALUES ('1273', '205.003', '-5944.01', '7.37471', '0', '495', '0', '571', '3', 'Howling Fjord, South Beach GY');
INSERT INTO `graveyards` VALUES ('1274', '57.9178', '-4649.08', '283.569', '0', '495', '0', '571', '3', 'Howling Fjord, South GY');
INSERT INTO `graveyards` VALUES ('1275', '668.024', '-4931.68', '3.90933', '0', '495', '0', '571', '3', 'Howling Fjord, Valgarde GY');
INSERT INTO `graveyards` VALUES ('1276', '1812.21', '-5613.43', '220.535', '0', '495', '0', '571', '3', 'Howling Fjord, Northeast GY');
INSERT INTO `graveyards` VALUES ('1277', '-7351.04', '-1315.89', '-261.603', '0', '490', '0', '1', '3', 'Un\'Goro Crater, Central GY');
INSERT INTO `graveyards` VALUES ('1278', '-6160.06', '-1142.43', '-217.769', '0', '490', '541', '1', '3', 'Un\'Goro Crater, Marshal\'s GY');
INSERT INTO `graveyards` VALUES ('1279', '475.685', '1469.87', '9.63075', '0', '406', '465', '1', '3', 'Stonetalon Mountains, Charred Vale');
INSERT INTO `graveyards` VALUES ('1280', '2729.91', '1286.64', '292.467', '0', '406', '467', '1', '3', 'Stonetalon Mountains, Peak GY');
INSERT INTO `graveyards` VALUES ('1281', '-7754.16', '-4971.9', '5.91349', '0', '440', '0', '1', '3', 'Tanaris, Pirate GY');
INSERT INTO `graveyards` VALUES ('1282', '-8591.8', '-3629.76', '13.5564', '0', '440', '0', '1', '3', 'Tanaris, Central GY');
INSERT INTO `graveyards` VALUES ('1283', '5633.33', '-4759.59', '777.713', '0', '618', '0', '1', '3', 'Winterspring, South GY');
INSERT INTO `graveyards` VALUES ('1284', '6499.59', '-2384.34', '589.849', '0', '618', '0', '1', '3', 'Winterspring, West GY');
INSERT INTO `graveyards` VALUES ('1285', '5537.46', '2904.91', '517.664', '0', '4197', '4575', '571', '3', 'Wintergrasp, Fortress (East)');
INSERT INTO `graveyards` VALUES ('1286', '1839.77', '-2149.68', '67.4935', '0', '28', '0', '0', '3', 'Western Plaguelands, Central GY');
INSERT INTO `graveyards` VALUES ('1287', '-6867.31', '-1539.84', '241.815', '0', '51', '0', '0', '3', 'Searing Gorge, SE GY');
INSERT INTO `graveyards` VALUES ('1288', '-7100.9', '-3488.39', '241.925', '0', '3', '0', '0', '3', 'Badlands, South GY');
INSERT INTO `graveyards` VALUES ('1289', '-3973.53', '-2014.49', '96.362', '0', '17', '0', '1', '3', 'The Barrens, South GY');
INSERT INTO `graveyards` VALUES ('1290', '3041.21', '4314.9', '29.0761', '0', '3537', '0', '571', '3', 'Borean Tundra, Tuskar GY');
INSERT INTO `graveyards` VALUES ('1291', '-1424.37', '4359.58', '241.566', '0', '3519', '4078', '530', '3', 'Terokkar Forest, Razorthorn Rise GY');
INSERT INTO `graveyards` VALUES ('1292', '12851.8', '-6854.8', '11.8612', '0', '4080', '4085', '530', '3', 'Isle of Quel\'Danas, Staging Area GY');
INSERT INTO `graveyards` VALUES ('1293', '12851.8', '-6854.8', '11.8612', '0', '4080', '4085', '530', '3', 'Isle of Quel\'Danas, Staging Area GY');
INSERT INTO `graveyards` VALUES ('1294', '12851.8', '-6854.8', '110.861', '0', '4080', '4085', '530', '3', 'Isle of Quel\'Danas, Staging Area GY');
INSERT INTO `graveyards` VALUES ('1295', '-10425.3', '7329.17', '313.967', '0', '4019', '0', '451', '3', 'Development Land, Theresa\'s Test Land GY');
INSERT INTO `graveyards` VALUES ('1296', '-10431.2', '7377.98', '313.967', '0', '4019', '0', '451', '3', 'Development Land, Theresa\'s Test Land 2 GY');
INSERT INTO `graveyards` VALUES ('1297', '-10414.7', '7414.45', '312.957', '0', '4019', '0', '451', '3', 'Development Land, Theresa\'s Test land 3 GY');
INSERT INTO `graveyards` VALUES ('1298', '-2433.64', '4660.97', '160.883', '0', '3519', '3692', '530', '3', 'Terokkar Forest, Lake Jorune GY');
INSERT INTO `graveyards` VALUES ('1299', '0', '0', '0', '0', '3523', '0', '566', '0', 'zzOLDNetherstorm BG - Graveyard (Alliance Default)');
INSERT INTO `graveyards` VALUES ('1300', '3100.18', '-1983.4', '83.3072', '0', '394', '4004', '571', '3', 'Grizzly Hills, Vileprey GY');
INSERT INTO `graveyards` VALUES ('1301', '3534.13', '-2882.06', '204.625', '0', '394', '4204', '571', '3', 'Grizzly Hills, Amberpine GY');
INSERT INTO `graveyards` VALUES ('1302', '4352.78', '-4247.99', '162.318', '0', '394', '4159', '571', '3', 'Grizzly Hills, Westfall GY');
INSERT INTO `graveyards` VALUES ('1303', '4117.91', '-4816.41', '76.0073', '0', '394', '0', '571', '3', 'Grizzly Hills, Eastern GY');
INSERT INTO `graveyards` VALUES ('1304', '3967.28', '-2316.64', '213.873', '0', '394', '0', '571', '3', 'Grizzly Hills, Northwestern GY');
INSERT INTO `graveyards` VALUES ('1305', '2933.64', '-2836.78', '73.6939', '0', '394', '0', '571', '3', 'Grizzly Hills, Southwestern GY');
INSERT INTO `graveyards` VALUES ('1306', '4323.39', '-3606.85', '248', '0', '394', '0', '571', '3', 'Grizzly Hills, Central GY');
INSERT INTO `graveyards` VALUES ('1307', '4604.76', '-976.65', '169.54', '0', '65', '0', '571', '3', 'Dragonblight, Northeastern GY');
INSERT INTO `graveyards` VALUES ('1308', '3667.91', '-1044.36', '130.562', '0', '65', '4177', '571', '3', 'Dragonblight, Wintergarde GY');
INSERT INTO `graveyards` VALUES ('1309', '3218.74', '-700.367', '167.482', '0', '65', '0', '571', '3', 'Dragonblight, Forsaken East GY');
INSERT INTO `graveyards` VALUES ('1310', '3843.01', '1425.52', '90.6411', '0', '65', '4165', '571', '3', 'Dragonblight, Agmar\'s Hammer GY');
INSERT INTO `graveyards` VALUES ('1311', '3498.38', '2100.42', '69.5025', '0', '65', '4158', '571', '3', 'Dragonblight, Star\'s Rest GY');
INSERT INTO `graveyards` VALUES ('1312', '2772.18', '1042.4', '25.045', '0', '65', '4152', '571', '3', 'Dragonblight, Moa\'ki Harbor GY');
INSERT INTO `graveyards` VALUES ('1313', '3599.17', '2846.07', '70.9523', '0', '65', '0', '571', '3', 'Dragonblight, Borean Border GY');
INSERT INTO `graveyards` VALUES ('1314', '3538.17', '275.51', '45.6119', '0', '65', '4161', '571', '3', 'Dragonblight, Wyrmrest GY');
INSERT INTO `graveyards` VALUES ('1315', '4812.89', '1022.49', '144.814', '0', '65', '0', '571', '1', 'Dragonblight, Wrathgate Horde GY');
INSERT INTO `graveyards` VALUES ('1316', '4466.17', '1257.02', '140.79', '0', '65', '0', '571', '0', 'Dragonblight, Wrathgate Alliance GY');
INSERT INTO `graveyards` VALUES ('1317', '2842', '5973.16', '114.196', '0', '3537', '4129', '571', '3', 'Borean Tundra, Warsong Hold GY');
INSERT INTO `graveyards` VALUES ('1318', '2007.96', '5936.55', '37.4033', '0', '3537', '4028', '571', '3', 'Borean Tundra, Riplash GY');
INSERT INTO `graveyards` VALUES ('1319', '3621.88', '6805.54', '171.706', '0', '3537', '4024', '571', '3', 'Borean Tundra, Coldarra GY');
INSERT INTO `graveyards` VALUES ('1320', '3559.93', '5818.79', '128.939', '0', '3537', '4023', '571', '3', 'Borean Tundra, Amber Ledge GY');
INSERT INTO `graveyards` VALUES ('1321', '4223.44', '5335.88', '30.6522', '0', '3537', '4108', '571', '3', 'Borean Tundra, Fizzcrank GY');
INSERT INTO `graveyards` VALUES ('1322', '4514.81', '5661.56', '82.0308', '0', '3537', '4122', '571', '3', 'Borean Tundra, Bor\'Gorok GY');
INSERT INTO `graveyards` VALUES ('1323', '3041.14', '3843.49', '3.75779', '0', '3537', '4114', '571', '3', 'Borean Tundra, Death\'s Stand GY');
INSERT INTO `graveyards` VALUES ('1324', '3576.16', '4087.61', '22.3312', '0', '3537', '4037', '571', '3', 'Borean Tundra, Taunka\'le GY');
INSERT INTO `graveyards` VALUES ('1325', '2842.96', '6655.17', '36.4127', '0', '3537', '4027', '571', '3', 'Borean Tundra, Coast of Echoes GY');
INSERT INTO `graveyards` VALUES ('1326', '2478.59', '5289.41', '32.3838', '0', '3537', '4032', '571', '3', 'Borean Tundra, Valiance Keep GY');
INSERT INTO `graveyards` VALUES ('1327', '791.432', '-419.449', '136.572', '0', '2597', '0', '0', '3', 'Alterac Valley - DO NOT EDIT');
INSERT INTO `graveyards` VALUES ('1328', '5537.57', '2905.04', '517.724', '0', '4197', '0', '571', '3', 'Wintergrasp, Fortress (West)');
INSERT INTO `graveyards` VALUES ('1329', '5104.35', '2302.23', '368.485', '0', '4197', '0', '571', '3', 'Wintergrasp, Siege Factory (Defense NE)');
INSERT INTO `graveyards` VALUES ('1330', '5101.04', '3461.45', '368.485', '0', '4197', '0', '571', '3', 'Wintergrasp, Siege Factory (Defense NW)');
INSERT INTO `graveyards` VALUES ('1331', '5031.51', '3710.43', '372.364', '0', '4197', '0', '571', '1', 'Wintergrasp, Horde Starting Area');
INSERT INTO `graveyards` VALUES ('1332', '5140.35', '2182.01', '390.751', '0', '4197', '0', '571', '0', 'Wintergrasp, Alliance Starting Area');
INSERT INTO `graveyards` VALUES ('1333', '4317.97', '2407.42', '392.619', '0', '4197', '0', '571', '3', 'Wintergrasp, Siege Factory (SE)');
INSERT INTO `graveyards` VALUES ('1334', '4335.81', '3234.56', '390.251', '0', '4197', '0', '571', '3', 'Wintergrasp, Siege Factory (SW)');
INSERT INTO `graveyards` VALUES ('1336', '4826.36', '5467.17', '-54.7747', '0', '3711', '0', '571', '3', 'Sholazar Basin, South GY');
INSERT INTO `graveyards` VALUES ('1337', '1335.47', '-4785.18', '188.077', '0', '495', '0', '571', '3', 'Howling Fjord, Utgarde GY');
INSERT INTO `graveyards` VALUES ('1341', '5620.52', '5840.97', '-63.4727', '0', '3711', '4284', '571', '3', 'Sholazar Basin, Nesingwary GY');
INSERT INTO `graveyards` VALUES ('1342', '5538.26', '4851.61', '-196.979', '0', '3711', '0', '571', '3', 'Sholazar Basin, Central GY');
INSERT INTO `graveyards` VALUES ('1343', '6246.95', '5164.34', '-83.2031', '0', '3711', '0', '571', '3', 'Sholazar Basin, Northwest GY');
INSERT INTO `graveyards` VALUES ('1344', '6274.77', '4409.44', '-68.901', '0', '3711', '0', '571', '3', 'Sholazar Basin, Northeast GY');
INSERT INTO `graveyards` VALUES ('1345', '5519.07', '3593.28', '-14.2186', '0', '3711', '0', '571', '3', 'Sholazar Basin, East GY');
INSERT INTO `graveyards` VALUES ('1346', '1388.8', '203.355', '32.1527', '0', '4384', '0', '607', '3', 'Northrend BG - Controlled - South');
INSERT INTO `graveyards` VALUES ('1347', '1396.06', '-288.037', '32.0815', '0', '4384', '0', '607', '3', 'Northrend BG - Controlled - South West');
INSERT INTO `graveyards` VALUES ('1348', '1122.28', '4.41618', '68.9358', '0', '4384', '0', '607', '3', 'Northrend BG - Controlled - Central');
INSERT INTO `graveyards` VALUES ('1349', '964.595', '-189.784', '90.6605', '0', '4384', '0', '607', '3', 'Northrend BG - Defender - Final');
INSERT INTO `graveyards` VALUES ('1350', '1457.19', '-53.7133', '5.18109', '0', '4384', '0', '607', '3', 'Northrend BG - Offense - Beach');
INSERT INTO `graveyards` VALUES ('1351', '1618.81', '31.2829', '8.34708', '0', '4384', '0', '607', '3', 'Northrend BG - Offense - Boat');
INSERT INTO `graveyards` VALUES ('1352', '5703.97', '-2467.94', '287.55', '0', '66', '0', '571', '3', 'Zul\'Drak, Western GY');
INSERT INTO `graveyards` VALUES ('1353', '5557.91', '-1615.61', '242.247', '0', '66', '0', '571', '3', 'Zul\'Drak, Northwestern GY');
INSERT INTO `graveyards` VALUES ('1354', '5244.65', '-2133.33', '244.753', '0', '66', '0', '571', '3', 'Zul\'Drak, Southwestern GY');
INSERT INTO `graveyards` VALUES ('1355', '4939.81', '-2958.49', '289.535', '0', '66', '0', '571', '3', 'Zul\'Drak, Southern GY');
INSERT INTO `graveyards` VALUES ('1356', '5798.52', '-3286.55', '363.379', '0', '66', '0', '571', '3', 'Zul\'Drak, Central GY');
INSERT INTO `graveyards` VALUES ('1357', '5522.76', '-4101.73', '364.358', '0', '66', '0', '571', '3', 'Zul\'Drak, Southeastern GY');
INSERT INTO `graveyards` VALUES ('1358', '6618.71', '-4795.52', '450.522', '0', '4416', '0', '571', '3', 'Zul\'Drak, Gun\'Drak GY');
INSERT INTO `graveyards` VALUES ('1359', '5849.21', '763.311', '641.053', '0', '4395', '0', '571', '3', 'Crystalsong Forest, Dalaran GY');
INSERT INTO `graveyards` VALUES ('1360', '2364.42', '-5771.32', '151.367', '0', '4298', '4281', '609', '3', 'Ebon Hold GY - Chapter I');
INSERT INTO `graveyards` VALUES ('1361', '1292.51', '792.054', '9.33863', '0', '4378', '0', '617', '3', 'Dalaran Arena - PvP Graveyard');
INSERT INTO `graveyards` VALUES ('1362', '1235.88', '771.076', '15.496', '0', '4378', '0', '617', '3', 'Dalaran Arena - Team 1 Spawn');
INSERT INTO `graveyards` VALUES ('1363', '1347.43', '813.004', '15.5246', '0', '4378', '0', '617', '3', 'Dalaran Arena - Team 2 Spawn');
INSERT INTO `graveyards` VALUES ('1364', '763.562', '-273.999', '3.55343', '0', '4406', '0', '618', '3', 'Orgrimmar Arena - Team 1 Spawn');
INSERT INTO `graveyards` VALUES ('1365', '763.934', '-295.01', '3.5588', '0', '4406', '0', '618', '3', 'Orgrimmar Arena - Team 2 Spawn');
INSERT INTO `graveyards` VALUES ('1366', '762.909', '-284.281', '28.2767', '0', '4406', '0', '618', '3', 'Orgrimmar Arena - Graveyard');
INSERT INTO `graveyards` VALUES ('1367', '1623.7', '-94.8278', '12.3511', '0', '0', '0', '607', '0', 'Sands of Ulduran - Alliance Spawn');
INSERT INTO `graveyards` VALUES ('1368', '1617.17', '67.1251', '8.05813', '0', '0', '0', '607', '1', 'Sands of Ulduran - Horde Spawn');
INSERT INTO `graveyards` VALUES ('1369', '2366.63', '-5774.42', '151.543', '0', '139', '4281', '0', '3', 'Eastern Plaguelands, Ebon Hold GY');
INSERT INTO `graveyards` VALUES ('1370', '1886.78', '-5784.59', '102.861', '0', '4298', '4281', '609', '3', 'Ebon Hold GY - Chapter II/III');
INSERT INTO `graveyards` VALUES ('1371', '2116.19', '-5286.94', '81.2151', '0', '4298', '4281', '609', '3', 'Ebon Hold GY - Chapter IV');
INSERT INTO `graveyards` VALUES ('1372', '-6115.09', '-1339.45', '-179.578', '0', '490', '4382', '1', '3', 'Un\'Goro Crater, Shaper\'s Terrace');
INSERT INTO `graveyards` VALUES ('1373', '-3769.47', '-4883.16', '5.5167', '0', '15', '513', '1', '3', 'Dustwallow Marsh, Theramore Safe');
INSERT INTO `graveyards` VALUES ('1374', '1362.55', '-5394.17', '-28.372', '0', '1637', '0', '1', '3', 'Durotar, Orgrimmar Safe');
INSERT INTO `graveyards` VALUES ('1375', '-8290.62', '1403.52', '4.7304', '0', '12', '1519', '0', '0', 'Stormwind City, Stormwind Safe');
INSERT INTO `graveyards` VALUES ('1376', '1103.08', '-4977.5', '32.3225', '0', '495', '0', '571', '3', 'Howling Fjord, Utgarde 2 GY');
INSERT INTO `graveyards` VALUES ('1377', '981.536', '1309.67', '45.9405', '0', '214', '0', '0', '3', 'The Great Sea - Safe Point Tirisfal');
INSERT INTO `graveyards` VALUES ('1378', '1342.17', '-5527.75', '10.0886', '0', '1637', '0', '1', '3', 'Durotar, Orgrimmar Safe 2');
INSERT INTO `graveyards` VALUES ('1379', '6351.79', '5643.56', '70.5419', '0', '3711', '4392', '571', '3', 'Sholazar Basin, Stormwright GY');
INSERT INTO `graveyards` VALUES ('1380', '5041.85', '-642.724', '225.207', '0', '2817', '0', '571', '0', 'Crystalsong Forest, Alliance GY');
INSERT INTO `graveyards` VALUES ('1381', '6070.45', '85.9704', '369.616', '0', '210', '4501', '571', '3', 'Icecrown, Argent Vanguard');
INSERT INTO `graveyards` VALUES ('1383', '7080.44', '-141.224', '783.232', '0', '67', '4424', '571', '3', 'Storm Peaks, Valkyrion GY');
INSERT INTO `graveyards` VALUES ('1384', '9021.61', '-1166.62', '1058.8', '0', '67', '4445', '571', '3', 'Storm Peaks, Ulduar GY');
INSERT INTO `graveyards` VALUES ('1385', '7915.03', '-2453.76', '1137.96', '0', '67', '0', '571', '3', 'Storm Peaks, Temple East GY');
INSERT INTO `graveyards` VALUES ('1387', '8105.5', '-996.581', '936.71', '0', '67', '0', '571', '3', 'Storm Peaks, Temple West GY');
INSERT INTO `graveyards` VALUES ('1388', '7463.99', '-3320.57', '897.75', '0', '67', '4439', '571', '3', 'Storm Peaks, Frostfield GY');
INSERT INTO `graveyards` VALUES ('1391', '5882.89', '666.806', '169.508', '0', '2817', '0', '571', '3', 'Crystalsong Forest, West GY');
INSERT INTO `graveyards` VALUES ('1392', '5597.15', '-595.531', '190.997', '0', '2817', '0', '571', '1', 'Crystalsong Forest, Horde GY');
INSERT INTO `graveyards` VALUES ('1393', '3421.2', '-1280.93', '125.973', '0', '3456', '0', '571', '3', 'Dragonblight, Naxxramas GY');
INSERT INTO `graveyards` VALUES ('1394', '3793.73', '2064.34', '93.6512', '0', '65', '4163', '571', '3', 'Dragonblight, Icemist GY');
INSERT INTO `graveyards` VALUES ('1395', '8188.08', '2859.48', '604.076', '0', '210', '4523', '571', '3', 'Icecrown Glacier, Quarry GY');
INSERT INTO `graveyards` VALUES ('1396', '7233.66', '2159.7', '564.704', '0', '210', '4523', '571', '3', 'Icecrown Glacier, Vrykul Central GY');
INSERT INTO `graveyards` VALUES ('1397', '7886.05', '718.776', '519.196', '0', '210', '4523', '571', '3', 'Icecrown Glacier, Northeast Ice GY');
INSERT INTO `graveyards` VALUES ('1398', '4421.3', '-1981.25', '158.166', '0', '4196', '4210', '571', '3', 'Grizzly Hills, Drak\'tharon GY');
INSERT INTO `graveyards` VALUES ('1399', '1232.39', '-65.7293', '70.0843', '0', '4384', '0', '607', '3', 'Northrend BG - Defender Start');
INSERT INTO `graveyards` VALUES ('1400', '7825.23', '-2023.12', '1225.4', '0', '67', '4446', '571', '3', 'Storm Peaks, Temple of the Makers GY');
INSERT INTO `graveyards` VALUES ('1401', '8387.58', '-214.278', '839.446', '0', '67', '4436', '571', '3', 'Storm Peaks, Snowdrift GY');
INSERT INTO `graveyards` VALUES ('1402', '6947', '-545.408', '914.927', '0', '67', '4430', '571', '3', 'Storm Peaks, Temple of Storms GY');
INSERT INTO `graveyards` VALUES ('1403', '6422.35', '-1184.35', '446.533', '0', '67', '4418', '571', '3', 'Storm Peaks, K3 GY');
INSERT INTO `graveyards` VALUES ('1404', '5036.33', '4494.32', '-93.329', '0', '3711', '4292', '571', '3', 'Sholazar Basin, Frenzyheart GY');
INSERT INTO `graveyards` VALUES ('1405', '2359.22', '-5661.06', '382.262', '0', '139', '0', '0', '3', 'Eastern Plaguelands: Acherus');
INSERT INTO `graveyards` VALUES ('1407', '7149.75', '3691.58', '817.852', '0', '210', '4523', '571', '3', 'Icecrown Glacier, Jotunheim GY');
INSERT INTO `graveyards` VALUES ('1408', '7092.46', '-1440.91', '922.636', '0', '67', '4432', '571', '3', 'Storm Peaks, Foot Steppes GY');
INSERT INTO `graveyards` VALUES ('1409', '1773.33', '768.808', '55.6853', '0', '85', '1497', '0', '0', 'Undercity - Alliance - Wrath Gate');
INSERT INTO `graveyards` VALUES ('1411', '794.763', '-422.394', '135.767', '0', '36', '0', '0', '3', 'Alterac Mountains - Central GY');
INSERT INTO `graveyards` VALUES ('1416', '7766.53', '-4100.77', '697.134', '0', '618', '0', '1', '3', 'Winterspring, Wintersaber GY');
INSERT INTO `graveyards` VALUES ('1417', '6619.88', '-3542.4', '681.873', '0', '618', '0', '1', '3', 'Winterspring, Crossroad GY');
INSERT INTO `graveyards` VALUES ('1418', '4460.24', '-4287.7', '917.647', '0', '618', '0', '1', '3', 'Winterspring, Darkwhisper GY');
INSERT INTO `graveyards` VALUES ('1419', '4320.15', '-5574.72', '121.979', '0', '16', '1225', '1', '3', 'Azshara, Ursolan');
INSERT INTO `graveyards` VALUES ('1420', '3203.82', '-4947.18', '157.752', '0', '16', '1233', '1', '3', 'Azshara, Forlorn Ridge');
INSERT INTO `graveyards` VALUES ('1421', '-1439.21', '1972.74', '85.7449', '0', '405', '597', '1', '1', 'Desolace, Ghost Walker Post');
INSERT INTO `graveyards` VALUES ('1422', '-1783.51', '2857.27', '56.6694', '0', '405', '598', '1', '3', 'Desolace, Sar\'theris Strand');
INSERT INTO `graveyards` VALUES ('1423', '-1967.22', '1723.91', '61.6668', '0', '405', '602', '1', '3', 'Desolace, Mannoroc Coven');
INSERT INTO `graveyards` VALUES ('1424', '-1553.23', '981.849', '90.2898', '0', '405', '604', '1', '3', 'Desolace, Magram Village');
INSERT INTO `graveyards` VALUES ('1425', '-481.844', '1221.74', '97.3062', '0', '405', '0', '1', '3', 'Desolace, Roadside');
INSERT INTO `graveyards` VALUES ('1426', '2928.99', '380.251', '91.6667', '0', '331', '416', '1', '3', 'Ashenvale, Shrine of Aessina');
INSERT INTO `graveyards` VALUES ('1427', '2291.3', '-1731.71', '118.359', '0', '331', '2457', '1', '3', 'Ashenvale, Nightsong');
INSERT INTO `graveyards` VALUES ('1428', '1284.34', '-298.896', '5.50894', '0', '406', '461', '1', '3', 'Stonetalon Mountains, Windshear Crag');
INSERT INTO `graveyards` VALUES ('1429', '1698.13', '1043.75', '148.291', '0', '406', '464', '1', '3', 'Stonetalon Mountains, Mirkfallon');
INSERT INTO `graveyards` VALUES ('1430', '161.386', '-1693.86', '93.5516', '0', '17', '386', '1', '3', 'The Barrens, Forgotten Pools');
INSERT INTO `graveyards` VALUES ('1431', '790.062', '-2541.63', '91.6667', '0', '17', '0', '1', '3', 'The Barrens, North GY');
INSERT INTO `graveyards` VALUES ('1432', '-1887.99', '-3055.97', '91.6667', '0', '17', '1697', '1', '3', 'The Barrens, Raptor Grounds');
INSERT INTO `graveyards` VALUES ('1433', '-1480.13', '-2143.87', '92.8206', '0', '17', '0', '1', '3', 'The Barrens, Central GY');
INSERT INTO `graveyards` VALUES ('1434', '271.838', '-3313.76', '56.0266', '0', '17', '0', '1', '3', 'The Barrens, East GY');
INSERT INTO `graveyards` VALUES ('1435', '-2725.16', '-1115.49', '20.148', '0', '215', '225', '1', '3', 'Mulgore, Southeast GY');
INSERT INTO `graveyards` VALUES ('1436', '-1171.5', '-1129.94', '27.8667', '0', '215', '225', '1', '3', 'Mulgore, Red Rocks');
INSERT INTO `graveyards` VALUES ('1437', '-5361.55', '-2363.09', '-37.392', '0', '400', '484', '1', '1', 'Thousand Needles, Freewind Post');
INSERT INTO `graveyards` VALUES ('1438', '-6115.81', '-3849.17', '-58.7501', '0', '400', '2240', '1', '3', 'Thousand Needles, Mirage Raceway');
INSERT INTO `graveyards` VALUES ('1439', '-9044.9', '-2721.88', '37.3756', '0', '440', '0', '1', '3', 'Tanaris, Southwest GY');
INSERT INTO `graveyards` VALUES ('1440', '-7753.64', '-3009.76', '42.0979', '0', '440', '1939', '1', '3', 'Tanaris, Abyssal Sands');
INSERT INTO `graveyards` VALUES ('1441', '-5526.86', '1450.52', '23.8921', '0', '357', '2522', '1', '3', 'Feralas, Ruins of Isildien');
INSERT INTO `graveyards` VALUES ('1442', '-4336.89', '-383.392', '36.5298', '0', '357', '1137', '1', '3', 'Feralas, Lower Wilds');
INSERT INTO `graveyards` VALUES ('1443', '-3332.47', '2276.89', '27.5594', '0', '357', '1119', '1', '3', 'Feralas, Twin Colossals');
INSERT INTO `graveyards` VALUES ('1444', '-7967.79', '784.502', '-1.01432', '0', '1377', '2744', '1', '3', 'Silithus, Hive\'Regal');
INSERT INTO `graveyards` VALUES ('1445', '-7051.92', '1290.27', '5.88543', '0', '1377', '2739', '1', '3', 'Silithus, Twilight Base Camp');
INSERT INTO `graveyards` VALUES ('1446', '-1343.26', '-2046.73', '70.6733', '0', '45', '324', '0', '3', 'Arathi Highlands, Stromgarde');
INSERT INTO `graveyards` VALUES ('1447', '-898.726', '-1473.56', '58.0803', '0', '267', '1057', '0', '3', 'Hillsbrad Foothills, Thoradin\'s Wall');
INSERT INTO `graveyards` VALUES ('1448', '3118.51', '-4804', '101.631', '0', '139', '2272', '0', '3', 'Eastern Plaguelands, Northdale');
INSERT INTO `graveyards` VALUES ('1449', '3339.8', '-3229.78', '142.813', '0', '139', '2279', '0', '3', 'Eastern Plaguelands, Stratholme');
INSERT INTO `graveyards` VALUES ('1450', '2208.66', '-2923.06', '107.93', '0', '139', '0', '0', '3', 'Eastern Plaguelands, West GY');
INSERT INTO `graveyards` VALUES ('1451', '2663.41', '-1725.17', '123.889', '0', '28', '190', '0', '3', 'Western Plaguelands, Hearthglen');
INSERT INTO `graveyards` VALUES ('1452', '-577.414', '118.942', '53.746', '0', '267', '286', '0', '3', 'Hillsbrad Foothills, Hillsbrad Fields');
INSERT INTO `graveyards` VALUES ('1453', '581.797', '-3827.57', '119.915', '0', '47', '356', '0', '3', 'The Hinterlands, Seradane');
INSERT INTO `graveyards` VALUES ('1454', '-192.387', '-3043.9', '120.136', '0', '47', '353', '0', '3', 'The Hinterlands, Shadra\'Alor');
INSERT INTO `graveyards` VALUES ('1455', '-2953.3', '-1758.1', '9.41316', '0', '11', '1024', '0', '3', 'Wetlands, Sundown Marsh');
INSERT INTO `graveyards` VALUES ('1456', '-3979.8', '-2848.51', '12.4631', '0', '11', '0', '0', '3', 'Wetlands, South Road');
INSERT INTO `graveyards` VALUES ('1457', '-3343.1', '-3424.86', '64.4794', '0', '11', '1017', '0', '3', 'Wetlands, Raptor Ridge');
INSERT INTO `graveyards` VALUES ('1458', '-13325.5', '153.601', '17.6299', '0', '33', '1741', '0', '3', 'Stranglethorn Vale, Gurubashi Arena');
INSERT INTO `graveyards` VALUES ('1459', '-12547.2', '-586.239', '39.5295', '0', '33', '0', '0', '3', 'Stranglethorn Vale, Central GY');
INSERT INTO `graveyards` VALUES ('1460', '-12001.2', '429.749', '2.9454', '0', '33', '301', '0', '3', 'Stranglethorn Vale, Savage Coast');
INSERT INTO `graveyards` VALUES ('1461', '-10839.2', '-480.764', '42.4602', '0', '10', '0', '0', '3', 'Duskwood, Central GY');
INSERT INTO `graveyards` VALUES ('1462', '-11218.7', '1711.25', '39.0291', '0', '40', '920', '0', '3', 'Westfall, Dagger Hills');
INSERT INTO `graveyards` VALUES ('1463', '-9980.25', '1758.08', '37.0801', '0', '40', '2', '0', '3', 'Westfall, Longshore');
INSERT INTO `graveyards` VALUES ('1464', '-11806.6', '-2962.69', '7.6522', '0', '4', '72', '0', '3', 'Blasted Lands, Dark Portal');
INSERT INTO `graveyards` VALUES ('1465', '-10320.1', '-4121.21', '22.355', '0', '8', '74', '0', '3', 'Swamp of Sorrows, Pool of Tears');
INSERT INTO `graveyards` VALUES ('1466', '-10347.2', '-2585.03', '23.5991', '0', '8', '1780', '0', '3', 'Swamp of Sorrows, Splinterspear');
INSERT INTO `graveyards` VALUES ('1467', '-9473', '-3009.03', '134.825', '0', '44', '70', '0', '3', 'Redridge Mountains, Stonewatch');
INSERT INTO `graveyards` VALUES ('1468', '-9564.74', '-605.882', '58.4409', '0', '12', '91', '0', '3', 'Elwynn Forest, Tower of Azora');
INSERT INTO `graveyards` VALUES ('1469', '-7923.56', '-1353.23', '134.079', '0', '46', '254', '0', '3', 'Burning Steppes, Blackrock Mountain');
INSERT INTO `graveyards` VALUES ('1470', '-7987.49', '-2370.21', '123.923', '0', '46', '0', '0', '3', 'Burning Steppes, East GY');
INSERT INTO `graveyards` VALUES ('1471', '-5382.65', '36.6651', '395.442', '0', '1', '211', '0', '3', 'Dun Morogh, Iceflow Lake');
INSERT INTO `graveyards` VALUES ('1472', '-5475.18', '-1845.84', '399.786', '0', '1', '0', '0', '3', 'Dun Morogh, East Road');
INSERT INTO `graveyards` VALUES ('1473', '-5329.98', '-3779.33', '310.214', '0', '38', '556', '0', '3', 'Loch Modan, The Loch');
INSERT INTO `graveyards` VALUES ('1474', '5463.84', '2840.68', '418.675', '0', '4197', '0', '571', '3', 'Wintergrasp, Fortress Graveyard (Indoors)');




-- vendor no need templates anymore
DELETE FROM vendors where entry in (6374,6373,6328,5750,15494,16267,12807,12776,6382,5749,6027,5815,5753,23535,5520,16649,6376);

-- no need the npcs spawned 
DELETE FROM creature_spawns where entry in (6374,6373,6328,5750,15494,16267,12807,12776,6382,5749,6027,5815,5753,23535,5520,16649,6376);

-- Npcs flags changing gossip them
UPDATE creature_proto SET npcflags = "1"  where entry in (6374,6373,6328,5750,15494,16267,12807,12776,6382,5749,6027,5815,5753,23535,5520,16649,6376);

-- Flags correction for only (no quest or vendor) Jewelcrafting Trainer
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='15501');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19775');


-- Gems bag correction
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42142');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='36766');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42143');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42153');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42146');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42152');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42148');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42158');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42150');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42144');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='36767');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42155');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42151');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42145');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42149');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42156');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42154');
UPDATE `items` SET `bagfamily`='512' WHERE (`entry`='42157');


-- Flags correction for only (no quest or vendor) Skinning Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='1292');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18755');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18777');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19180');

-- Flags correction for only (no quest or vendor) Herbalism Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='1458');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4614');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5502');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16736');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16763');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18748');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18776');

-- Flags correction for only (no quest or vendor) Engineering Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='1676');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='1702');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='8738');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16726');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19576');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='21493'); -- wowheadno template

-- Flags correction for only (no quest or vendor) Alchemy Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='2132');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4611');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5499');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16723');

-- Flags correction for only (no quest or vendor) First Aid Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='2327');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='2329');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='3181');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4591');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5759');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16272');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16662');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16731');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19184');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19478');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='22477');

-- Flags correction for only (no quest or vendor) Mining Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='3137');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4598');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5513');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16752');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18747');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='18779');

-- Flags correction for only (no quest or vendor) Fishing Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='3179');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5493');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16774'); -- wowhead no template
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16780');

-- Flags correction for only (no quest or vendor) Leatherworking Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='3549');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4588');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5564');

-- Flags correction for only (no quest or vendor) Cooking Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4552');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5482');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16719');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19185');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19185');

-- Flags correction for only (no quest or vendor) Enchanting Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='4616');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='5695');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='16725');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19252');

-- Flags correction for only (no quest or vendor) Blacksmithing Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='7232');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='19341');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='20124');
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='20125');

-- Flags correction for only (no quest or vendor) Tailoring Trainer (81 to 16)
UPDATE `creature_proto` SET `npcflags`='16' WHERE (`entry`='9584');


-- elevator and transporter flags
UPDATE gameobject_spawns SET flags=40 WHERE entry IN (149046,
149045,
152614,
188514,
189991,
191276,
191277,
188136,
191278,
191329,
188428,
192588,
192717,
188515,
188517,
188516,
190587,
188360,
186452,
190118,
190119,
186452,
190119,
190118,
186452,
190119,
190118,
186452,
190119,
190118,
186759,
186762,
186758,
186760,
186761,
186452,
190119,
190118,
186963,
186962,
186953,
186961,
186960,
186964);


-- respawn at bt it is not blizzlike
UPDATE creature_proto SET respawntime = "0" WHERE entry IN ("22884","22877","22875","22876","22873","22881","22878","22883","23028","22963","23030","22960","23330","22954","22853","23337","22869","23339","2885","22849","22848","22844","22845","22879","22880","23018","22946","23147","22945","22882","23047","23049","22953","23172","23232","23236","23237","23235","23196","23399","23401","23223","23222","22939","22955","22965","22959","22956","22964","22962","22957","23402","23397","23400","23403","23394","22856");

-- respawn at swp it is not blizzlike
UPDATE creature_proto SET respawntime = "0" WHERE entry IN ("25363","25367","25368","25369","25370","25371","25372","25507","25508","25509","25588","25591","25592","25593","25595","25597","25599","25851","25867","24850","24882","25038","25165","25166","25741","25840","25315","25001");

-- respawn at deadmines are not blizzlike :P
UPDATE `creature_proto` SET `respawntime`='0' WHERE (`entry`='636');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='3450');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='1729'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='598'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='634');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='657');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='1732'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='4416');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='4417'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='1725');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='4418'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='1731'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='622');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='3947'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='641'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='2520'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='647'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='645');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='639');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='1763'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='3586'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='646');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='644'); 
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='643');
UPDATE `creature_proto` SET `respawntime`='0'WHERE (`entry`='642');
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 *    _|          _|  _|    _|  _|      _|  _|_|_|    _|_|_|    
 *    _|          _|  _|    _|    _|  _|    _|    _|  _|    _|  
 *    _|    _|    _|  _|_|_|_|      _|      _|    _|  _|_|_|    
 *      _|  _|  _|    _|    _|      _|      _|    _|  _|    _|  
 *        _|  _|      _|    _|      _|      _|_|_|    _|_|_|    
 * 
 * Added some GO loots for quests in Howling Fjord tnx to gcanoca.
 * GO spawns for Milly's Harvest Quest tnx to AliaErenel.
 * Questfix `The Affray` tnx to AliaErenel.
 * Corrected many item damages tnx to sghost, this will be a temp. fix, soon we will update all items with sniffed content.
 * Spawned commander Hobb tnx to xnemesis
 * Fixed Ruul Onestone his HP tnx to xnemesis
 * Correction to AQ reputation tnx to xnemesis
 * Fixed `uncatalogued species` quest tnx to xnemesis
 * Mycah's Botanical Bag requires UNKNOWN - correction to faction req tnx to xnemesis
 * Spawned Sai'kkal the Elder tnx to xnemesis
 * Spawned Ana'thek the Cruel tnx to xnemesis
 * Few loot/drop fixes tnx to xnemesis
 * Correct Clintar Dreamwalker's position (He was in the wrong cave) tnx to xnemesis
 * Dreadsteed of Xoroth requires all 3 quest chains to be completed tnx to xnemesis
 * Corrected faction of Ripfang Lynx's tnx to xnemesis
 * Correction of bytes for Bashana Runetotem tnx to xnemesis
 * Fixed NPC: Dimensional Ripper tnx to xnemesis
 * Fixed NPC: Ultrasafe transporter tnx to xnemesis
 * Fixed some reputation issues with syndicate and ravenholdt tnx to xnemesis
 * 
 * Added 3.0.8 Quest Starter/Finishers
 * Added 3.0.8 Vendor Templates..
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

DELETE FROM creature_quest_starter WHERE quest='13556' AND id='33025'; REPLACE INTO creature_quest_starter SET quest='13556', id='33025';
DELETE FROM creature_quest_finisher WHERE quest='13556' AND id='33025'; 
REPLACE INTO creature_quest_finisher SET quest='13556', id='33025';
DELETE FROM vendors WHERE entry='33018';
REPLACE INTO vendors SET entry='33018', item='35952', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='8948', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='28399', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='33452', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='33445', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='8766', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='33444', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='27860', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='33443', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='35947', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='29453', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='35954', amount='5', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33018', item='27859', amount='5', max_amount='-1', extended_cost='0';
DELETE FROM vendors WHERE entry='33019';
REPLACE INTO vendors SET entry='33019', item='44571', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='40042', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='44573', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='44575', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='44570', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='40035', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='44574', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33019', item='40036', amount='1', max_amount='-1', extended_cost='0';
DELETE FROM vendors WHERE entry='33026';
REPLACE INTO vendors SET entry='33026', item='2723', amount='0', max_amount='0', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='40042', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='2594', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='2593', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='40035', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='2595', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='2596', amount='1', max_amount='-1', extended_cost='0';
REPLACE INTO vendors SET entry='33026', item='40036', amount='1', max_amount='-1', extended_cost='0';
UPDATE `loot_creatures` set `percentchance`='100' WHERE `itemid`='12283';
UPDATE `loot_creatures` set `percentchance`='100' WHERE `itemid`='20025';
UPDATE `loot_creatures` SET `percentchance`='100' WHERE `itemid`='10420';
REPLACE INTO `item_quest_association` VALUES('31372', '10804', '8');
REPLACE INTO `item_quest_association` VALUES('31373', '10804', '8');
UPDATE `loot_gameobjects` SET `percentchance`='1.9' WHERE `itemid`='21150';
UPDATE `loot_gameobjects` SET `percentchance`='1.6' WHERE `itemid`='21228';
UPDATE `creature_spawns` SET `faction`='14' WHERE `entry`='20671';
UPDATE `creature_spawns` SET `bytes2`='4097' WHERE `entry`='9087';
UPDATE `creature_proto` SET `npcflags`='17' WHERE `entry`='14742';
UPDATE `creature_proto` SET `npcflags`='17' WHERE `entry`='14743';
UPDATE `reputation_creature_onkill` SET `rep_limit`='20999' WHERE `faction_change_alliance`='471' AND `rep_limit`='21000';
UPDATE `reputation_creature_onkill` SET `rep_limit`='20999' WHERE `faction_change_alliance`='472' AND `rep_limit`='21000';
UPDATE `reputation_creature_onkill` SET `rep_limit`='20999' WHERE `faction_change_alliance`='473' AND `rep_limit`='21000';
REPLACE INTO `trainer_defs` VALUES ('14743', '0', '0', '0', '0', '0', '0', '0', 'Ever wanted to rip apart a dimension $N?','14744','14745');
REPLACE INTO `trainer_spells` VALUES ('14743', '0', '23489', '34908', '20219', '202', '260', '', '0', '1');
REPLACE INTO `npc_text` VALUES ('14744', '1', 'Greetings fellow gnomish engineer.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0');
REPLACE INTO `npc_text` VALUES ('14745', '1', 'You are no gnomish engineer. I don\'t have time for your kind.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0');
REPLACE INTO `trainer_defs` VALUES ('14742','0', '0','0', '0', '0', '0', '0', 'Ever wanted to rip apart a dimension $N?', '14742', '14743');
REPLACE INTO `npc_text` VALUES ('14742', '1', 'Greetings fellow goblin engineer.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0');
REPLACE INTO `npc_text` VALUES ('14743', '1', 'You are no goblin engineer. I don\'t have time for your kind.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0');
REPLACE INTO `trainer_spells` VALUES ('14742', '0', '23486', '34908', '20222', '202', '260', '', '0', '1');
UPDATE `creature_spawns` SET `position_x`='7459.67', `position_y`='-3122.18', `position_z`='438.28', `orientation`='0.90' WHERE `entry`='22834';
REPLACE INTO `creature_spawns` VALUES ('', '1059', '0', '-13083.2', '-606.34', '54.7776', '5.61996', '0', '4634', '30', '32768', '16777472', '0', '4097', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
UPDATE `creature_proto` SET `money`='13' WHERE `entry`='15274';
UPDATE `items` SET `socket_bonus`='0', `GemProperties`='902' WHERE `entry`='35316';
UPDATE `creature_proto` set `money`='2567' WHERE `entry`='3255';
UPDATE `items` SET `requiredfaction`='970' WHERE `entry`='38229';
REPLACE INTO `creature_spawns` VALUES ('', '22932', '530', '2389.34', '7179.57', '366.458', '1.81774', '0', '21140', '35', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
UPDATE `reputation_instance_onkill` SET `mob_rep_reward`='10', `boss_rep_reward`='100' WHERE `mapid`='531';
UPDATE `quests` SET `ReceiveItemId1`='0' WHERE `entry`='9875';
UPDATE `items` SET `spellid_1`='19886', `spellid_2`='483', `spelltrigger_2`='6' WHERE `entry`='16072';
UPDATE `loot_creatures` SET `percentchance`='100' WHERE `itemid`='32567';
UPDATE creature_proto SET minhealth=3540, maxhealth=3540 WHERE entry=2602;
UPDATE `quests` SET `RequiredQuest1` = '7564', `RequiredQuest2` = '7629', `RequiredQuest3` = '7630' WHERE `quests`.`entry`=7631;
REPLACE INTO creature_spawns VALUES('', '23434', '530', '-4098.37', '1118.43', '42.7215', '5.35816', '0', '0', '21505', '1876', '656', '0', '9000', '512', '0', '2562', '0', '0', '1', '0', '0', '0' , '0');
UPDATE `creature_proto` SET `npcflags`='147' WHERE `entry`='18802';
delete from loot_gameobjects where entryid in (186885, 186640, 186679, 186950, 187027, 186325, 33084, 186618, 33488, 186632, 186886, 186828, 186955, 186684,186954, 187026, 186938, 187022, 186390, 186662, 186607, 186831, 186830, 186832, 187238, 186591, 186616, 186619, 186397, 187381, 187032, 187033, 187023, 186912, 186427, 186404, 186468, 186587);
REPLACE INTO loot_gameobjects values ('', 186885, 34069, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186640, 33545, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186679, 33620, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186950, 34131, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187027, 34225, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186325, 33084, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186618, 33488, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186632, 33541, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186886, 34070, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186828, 34031, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186955, 34134, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186684, 34133, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186954, 34224, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187026, 34224, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186938, 34102, 100, 0, 1,3,0);
REPLACE INTO loot_gameobjects values ('', 187022, 34222, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186390, 33099, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186662, 33635, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186607, 33485, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186831, 34040, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186830, 34042, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186832, 34041, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187238, 34468, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186591, 33348, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186616, 33487, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186619, 33487, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186397, 33109, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187381, 34239, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187032, 34237, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187033, 34236, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 187023, 34223, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186912, 34081, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186427, 33123, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186404, 33187, 100, 0, 1,1,0);
REPLACE INTO loot_gameobjects values ('', 186468, 33188, 100, 0, 1,1,0), ('', 186468, 33187, 0.1, 0, 1, 1,0);
REPLACE INTO loot_gameobjects values ('', 186587, 33355, 100, 0, 1,1,0);
delete from item_quest_association where item in (34069, 33545, 33620, 34131, 34225, 33084, 33488, 33541, 34070, 34031, 34134, 34133, 34224, 34224, 34102, 34222, 33099, 33635, 33485, 34040, 34042, 34041, 34468, 33348, 33487, 33487, 33109, 34239, 34237, 34236, 34223, 34081, 33123, 33187, 33188, 33187, 33355);
REPLACE INTO item_quest_association values (34069, 11434, 1);
REPLACE INTO item_quest_association values (33545, 11300, 1);
REPLACE INTO item_quest_association values (33620, 11328, 1);
REPLACE INTO item_quest_association values (34131, 11475, 1);
REPLACE INTO item_quest_association values (34225, 11504, 1);
REPLACE INTO item_quest_association values (33084, 11154, 15);
REPLACE INTO item_quest_association values (33488, 11290, 1);
REPLACE INTO item_quest_association values (33541, 11298, 5);
REPLACE INTO item_quest_association values (34070, 11434, 1);
REPLACE INTO item_quest_association values (34031, 11420, 1);
REPLACE INTO item_quest_association values (34134, 11483, 1);
REPLACE INTO item_quest_association values (34133, 11483, 1);
REPLACE INTO item_quest_association values (34224, 11504, 1);
REPLACE INTO item_quest_association values (34224, 11504, 1);
REPLACE INTO item_quest_association values (34222, 11504, 1);
REPLACE INTO item_quest_association values (33099, 11167, 10);
REPLACE INTO item_quest_association values (33635, 11333, 1);
REPLACE INTO item_quest_association values (33485, 11289, 1);
REPLACE INTO item_quest_association values (34040, 11423, 1);
REPLACE INTO item_quest_association values (34042, 11423, 1);
REPLACE INTO item_quest_association values (34041, 11423, 1);
REPLACE INTO item_quest_association values (34468, 11529, 1);
REPLACE INTO item_quest_association values (33348, 11269, 10);
REPLACE INTO item_quest_association values (33487, 11292, 8);
REPLACE INTO item_quest_association values (33109, 11286, 10);
REPLACE INTO item_quest_association values (34239, 11567, 1);
REPLACE INTO item_quest_association values (34237, 11512, 1);
REPLACE INTO item_quest_association values (34236, 11511, 1);
REPLACE INTO item_quest_association values (34223, 11504, 1);
REPLACE INTO item_quest_association values (34081, 11443, 1);
REPLACE INTO item_quest_association values (33123, 11190, 10);
REPLACE INTO item_quest_association values (33187, 11218, 18);
REPLACE INTO item_quest_association values (33188, 11218, 6);
REPLACE INTO item_quest_association values (33355, 11277, 10);
REPLACE INTO item_quest_association values (33348, 11271, 10);
REPLACE INTO item_quest_association values (33485, 11288,1);
REPLACE INTO item_quest_association values (33488, 11291,1);
REPLACE INTO item_quest_association values (33620, 11327,1);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9070.42, -394.701, 73.8516, 4.11548, 1.06652e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9069.89, -393.932, 73.0095, 4.05657, 1.06651e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9071.43, -394.359, 72.8923, 4.00945, 1.0665e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9070.44, -395.589, 72.9033, 4.61656, 1.06667e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9039.19, -354.92, 74.0832, 3.78718, 1.06646e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9034.88, -347.487, 73.9379, 3.80211, 1.06646e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9034.91, -331.185, 73.4829, 4.1304, 1.06653e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9032.68, -320.363, 73.6029, 0.690361, 1.06571e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9045.73, -315.498, 73.5024, 0.86786, 1.06579e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9047.58, -322.221, 73.4545, 0.730416, 1.06573e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9048.04, -330.772, 73.452, 0.884354, 1.0658e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9043.74, -338.209, 73.4551, 0.774398, 1.06575e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9057.95, -340.061, 73.4519, 0.794818, 1.06576e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9058.88, -348.131, 73.4515, 0.834088, 1.06578e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9074.88, -357.234, 73.4515, 0.991953, 1.06585e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9094.25, -347.19, 73.4515, 3.2327, 1.0664e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO gameobject_spawns (`id`, `Entry`, `map`, `position_x`, `position_y`, `position_z`, `Facing`, `orientation1`, `orientation2`, `orientation3`, `orientation4`, `State`, `Flags`, `Faction`, `Scale`, `stateNpcLink`) VALUES (0, 161557, 0, -9082.21, -337.552, 73.4508, 2.28237, 1.06631e+009, 0, 0, 0, 769, 0, 0, 1, 0);

REPLACE INTO quests (`entry`, `ZoneId`, `sort`, `flags`, `MinLevel`, `questlevel`, `Type`, `RequiredRaces`, `RequiredClass`, `RequiredTradeskill`, `RequiredTradeskillValue`, `RequiredRepFaction`, `RequiredRepValue`, `LimitTime`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `srcItem`, `SrcItemCount`, `Title`, `Details`, `Objectives`, `CompletionText`, `IncompleteText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqKillMobOrGOId1`, `ReqKillMobOrGOId2`, `ReqKillMobOrGOId3`, `ReqKillMobOrGOId4`, `ReqKillMobOrGOCount1`, `ReqKillMobOrGOCount2`, `ReqKillMobOrGOCount3`, `ReqKillMobOrGOCount4`, `ReqCastSpellId1`, `ReqCastSpellId2`, `ReqCastSpellId3`, `ReqCastSpellId4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepFaction6`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewRepValue6`, `RewRepLimit`, `RewMoney`, `RewXP`, `RewSpell`, `CastSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `RewardMoneyAtMaxLevel`, `ExploreTrigger1`, `ExploreTrigger2`, `ExploreTrigger3`, `ExploreTrigger4`, `RequiredOneOfQuest`, `RequiredQuest1`, `RequiredQuest2`, `RequiredQuest3`, `RequiredQuest4`, `RemoveQuests`, `ReceiveItemId1`, `ReceiveItemId2`, `ReceiveItemId3`, `ReceiveItemId4`, `ReceiveItemCount1`, `ReceiveItemCount2`, `ReceiveItemCount3`, `ReceiveItemCount4`, `IsRepeatable`, `bonushonor`, `rewardtitleid`, `rewardtalents`, `suggestedplayers`) VALUES (1719, 0, 81, 5, 30, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1718, 0, 0, 0, 'The Affray', 'If you want to learn from me, then you must first pass The Affray.  It is a challenge we on Fray Island like to offer rising warriors who think they\'re tough, and if you can pass this test then I\'ll know you are.$B$BTo begin, walk into the middle of that crowd yonder and step on the grate.  That\'ll tell Twiggy Flathead you\'re ready, and he\'ll send challengers against you.$B$BBeat all the challengers and he\'ll call out Big Will.  Kill Big Will, and return to me in the time we allow.', 'Kill Big Will, then speak to Klannoc Macleod on Fray Island.', 'Well done, $N.  You have passed The Affray!$b$bYou are a worthy $C, and I am honored to teach you...', '', 'Step on the grate to begin the Affray', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 6238, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2450, 0, 8616, 0, 0, 0, 0, 1020, 0, 0, 0, 0, '0', 1718, 0, 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

